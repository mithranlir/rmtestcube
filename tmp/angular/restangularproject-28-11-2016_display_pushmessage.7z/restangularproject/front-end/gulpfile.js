var gulp = require('gulp');
var browserify = require('browserify');
var source = require('vinyl-source-stream');
var jshint = require('gulp-jshint');
var browserSync = require('browser-sync').create();
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');
var del = require('del');

var flags = {
    asModule: false
};

var environments = require('gulp-environments');
var development = environments.development;
var production = environments.production; // ex : var configFile = production() ? "./path/prod.js" : "./path/dev.js";

var httpProxy = require('http-proxy');


gulp.task('asModule', function () {
    flags.asModule = true;
})

/** lint and css tasks **/

gulp.task('lint', function() {
  gulp.src('./src/app/**/*.js')
    .pipe(jshint())
    .pipe(jshint.reporter('default'));
});

gulp.task('css', function() {
    return gulp.src(
        [
            './src/assets/**/*.css',
            './node_modules/angular-material/**/*.css',
            './node_modules/ag-grid/dist/styles/*.css'
        ])
        .pipe(concat('style.css'))
        .pipe(gulp.dest('./public/'));
});

/** tasks used to build for local app running **/

gulp.task('vendor', function(){
    return gulp.src([
        './src/assets/**/*.js'
        ])
        .pipe(uglify())
        .pipe(concat('vendor.min.js'))
        .pipe(gulp.dest('./public/'));
});

gulp.task('browserify', function() {

    console.log('flags.asModule=' + flags.asModule);

    // Grabs the app.js file
    browserify([
            flags.asModule ? './src/app/extModuleApp.js' : './src/app/app.js'
        ])
        // bundles it and creates a file called main.js
        .bundle()
        .pipe(source('main.js'))
        .pipe(gulp.dest('./public/'));
});

gulp.task('copy', ['browserify', 'vendor'], function() {
    return gulp.src(['./src/**/*.html'])
        .pipe(gulp.dest('./public'))
        .pipe(browserSync.stream());
});

gulp.task('build',['lint', 'copy', 'css']);

/** tasks used to build app as module **/

gulp.task('cssForModule', function() {
    return gulp.src(
        [
            './src/assets/**/*.css',
            './node_modules/angular-material/**/*.css',
            './node_modules/ag-grid/dist/styles/*.css'
        ])
        .pipe(concat('style.css'))
        .pipe(gulp.dest('./tmp_module/'));
});

gulp.task('initForModule', function() {
    del([ './tmp_module/' ]);
});

gulp.task('scriptsForModule', function(){
    return gulp.src(['./src/**/*.js'])
        .pipe(uglify())
        .pipe(gulp.dest('./tmp_module/'));
});

gulp.task('copyForModule', function() {
    return gulp.src(['./src/**/*.html', '!./src/index.html'])
        .pipe(gulp.dest('./tmp_module'));
});

gulp.task('prepareBuildModule', function() {
    return gulp.src(['./conf/petra-air-grid/*.*'])
        .pipe(gulp.dest('./tmp_module'));
});

gulp.task('buildModule',['initForModule', 'lint', 'copyForModule', 'scriptsForModule', 'prepareBuildModule', 'cssForModule']);

gulp.task('cleanLocalDeployedModule', function() {
    del([ './node_modules/petra-air-grid/' ]);
});

gulp.task('deployLocalModule', ['cleanLocalDeployedModule', 'buildModule' ], function() {
    return gulp.src(['./tmp_module/**/*.*'])
        .pipe(gulp.dest('./node_modules/petra-air-grid'));
});

/** proxy config when running app with local server **/

var localServerUrl = 'http://localhost:8080/';

var proxy = httpProxy.createProxyServer({
    target: localServerUrl
});

var startsWith = function(value, str) {
    return value.substring( 0, str.length ) === str;
}

var endsWith = function(value, str) {
    return value.substring( value.length - str.length, value.length ) === str;
}

var proxyMiddleware = function(req, res, next) {
    if(req.url == '/' || startsWith(req.url, '/app/')) {
        console.log("no proxy for " + req.url);
        next();
    }
    else if(req.url == '/style.css' || req.url == '/vendor.min.js' || req.url == '/main.js') {
        console.log("no proxy for " + req.url);
        next();
    }
    else {
        console.log("proxy for " + req.url);
        proxy.web(req, res);
    }
};

/** run localhost:3000 with file sync **/

gulp.task('browser-sync', ['build'], function() {
    browserSync.init({
        server: {
            baseDir: "./public",
            middleware: proxyMiddleware
        },
        browser:"firefox"
    });
});

gulp.task('default', ['browser-sync'], function(){
    gulp.watch("./src/**/*.*", ["build"]);
    gulp.watch("./public/**/*.*").on('change', browserSync.reload);
})

/** run localhost:3000 with file sync **/

gulp.task('browser-sync-module', ['deployLocalModule'], function() {
    browserSync.init({
        server: {
            baseDir: "./public",
            middleware: proxyMiddleware
        },
        browser:"firefox"
    });
});

gulp.task('defaultModule', ['browser-sync-module'], function(){
    gulp.watch("./src/**/*.*", ["buildModule"]);
    gulp.watch("./public/**/*.*").on('change', browserSync.reload);
})





