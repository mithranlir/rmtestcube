
require('angular');
require('angular-ui-router');
require('angular-aria');
require('angular-animate');
require('angular-material');
require('angular-resource');
require('angular-base64');
require('ng-stomp');

var agGrid = require('ag-grid');
agGrid.initialiseAgGridWithAngular1(angular);

require('./components/petra-air-grid/petra-air-grid.js');
