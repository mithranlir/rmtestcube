angular.module('myApp.extractdata', ['agGrid', 'ngResource'])
	.controller('extractDataCtrl',['$scope', '$resource', function($scope,  $resource) {

		this.welcomeText = 'Extract Data';

		var columnDefs = [
			{ headerName: "gop", field: "gop" },
			{ headerName: "indicator", field: "indicator" },
			{ headerName: "ytd", field: "ytd" }
		];

		$scope.gridOptions = {
			columnDefs: columnDefs,
			rowData: []
		};

		$resource('/extractdata/list', {}).get({}, function(result){
			$scope.gridOptions.api.setRowData(angular.copy(result.rows));
		});
	}]);
