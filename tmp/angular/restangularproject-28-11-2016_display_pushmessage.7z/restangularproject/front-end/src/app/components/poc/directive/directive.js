angular.module('myApp.directive', ['agGrid', 'ngResource'])
    .controller('myController', function () {
        var vm = this;
        vm.testVar = "test var initiated";
    })
    .directive('testdirective', function() {
        return {
            restrict: 'A',
            scope: {
                companyId: '=companyId'
            },
            bindToController: true,
            controllerAs: "myCtrl",
            controller: 'myController',
            template: ' <div>testVar: {{myCtrl.testVar}}<br>companyId:{{myCtrl.companyId}}</div>'
        };
    });


