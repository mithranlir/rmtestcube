angular.module('myApp.pushmsg', ['ngStomp'])
	.controller('pushMsgCtrl', ['$stomp', '$scope', '$location', function ($stomp, $scope, $location) {

		console.log("pushMsgCtrl executed...");

		var path = $location.absUrl();
		var pathArray = path.split('/');
		var appContext = pathArray[3];
		if(appContext.startsWith('#')) {
			appContext = '';
		}
		else {
			appContext = '/' + appContext;
		}
		console.log('appContext=' + appContext);

		$scope.targetUserName = 'user1';

		$stomp.setDebug(function (args) {
			console.log(args);
		});

		$scope.connected = false;
		$scope.subscription = null;
		$scope.subscriptionPersonal = null;

		$scope.messageStack = [];

		var curScope = $scope;

		var addNewMessage = function(message) {
			curScope.messageStack.push(message);
		}

		var addNewMessageAndUpdate = function(message) {
			curScope.$apply(function () {
				addNewMessage(message);
			});
		}

		$scope.connectMe = function() {
			console.log("connectMe");
			var url = appContext + '/message-websocket';
			$stomp
				.connect(url, {}, function (error) {
					var msg = 'connect error :' + error;
					console.error(msg);
					addNewMessage(msg);
				})
				.then(function (frame) {
					if(angular.isDefined(frame) && angular.isDefined(frame.headers)) {
						$scope.currentUserName = frame.headers['user-name'];
					}
					else {
						$scope.currentUserName = 'unknown';
					}
					$scope.connected = true;
					var msg = 'connect done : current user is ' + $scope.currentUserName;
					console.log(msg);
					addNewMessage(msg);
				}, function(error){
					var msg = 'connect error :' + error;
					console.error(msg);
					addNewMessage(msg);
				});
		};


		$scope.subscribeMe = function() {
			var url = appContext + '/topic/messages';
			var messageStack = $scope.messageStack;
			$scope.subscription = $stomp.subscribe(url, function (payload, headers, res) {
				if(angular.isDefined(payload) && payload !== null) {
					var result = payload.content;
					var msg = "message received as subscriber : " + result;
					console.log(msg);
					addNewMessageAndUpdate(msg);
				}
				else {
					var msg = "message received as subscriber : payload is null";
					console.error(msg);
					addNewMessageAndUpdate(msg);
				}
			}, {});
			messageStack.push("subscribe done");
		};

		$scope.sendMsg = function() {
			console.log("sendMsg");
			var url = appContext + '/app/chat';
			var messageToSend = 'coucou';
			if($scope.connected) {
				$stomp.send(url, {
					content: messageToSend
				}, {
					priority: 9,
					custom: 42 // Custom Headers
				}).then(function () {
					var msg = "sendMsg done : " + messageToSend;
					console.log(msg);
					addNewMessage(msg);
				}, function (reason) {
					var msg = "sendMsg error : " + reason;
					console.error(msg);
					addNewMessage(msg);
				});
			}
		};

		$scope.unsubscribeMe = function() {
			console.log("unsubscribeMe");
			if($scope.subscription !== null) {
				$scope.subscription.unsubscribe();
				var msg = "unsubscribe done";
				console.log(msg);
				addNewMessage(msg);
			}
			else {
				var msg = "subscription is null...";
				console.error(msg);
				addNewMessage(msg);
			}
		};

		$scope.subscribeMePersonal = function() {
			console.log("subscribeMePersonal");
			var url = appContext + '/user/queue/personalwarning';
			var messageStack = $scope.messageStack;
			$scope.subscriptionPersonal = $stomp.subscribe(url, function (payload, headers, res) {
				if(angular.isDefined(payload) && payload !== null) {
					var result = payload.content;
					var msg = "personal message received as subscriber : " + result;
					console.log(msg);
					addNewMessageAndUpdate(msg);
				}
				else {
					var msg = "personal message received as subscriber : payload is null";
					console.error(msg);
					addNewMessageAndUpdate(msg);
				}
			}, {});
			messageStack.push("subscribe personal done");
		};

		$scope.sendMsgPersonal = function() {
			console.log("sendPersonalMsg");
			var targetUser = $scope.targetUserName;
			var url = appContext + '/user/' + targetUser + '/queue/personalwarning';
			console.log("url=" + url);
			if($scope.connected) {
				var messageToSend = 'coucou ' + targetUser + ' de la part de ' + $scope.currentUserName;
				$stomp.send(url, {
					content: messageToSend
				}, {
					priority: 9,
					custom: 42 // Custom Headers
				}).then(function () {
					var msg = "sendMsgPersonal to " + targetUser + " done : " + messageToSend;
					console.log(msg);
					addNewMessage(msg);
				}, function (reason) {
					var msg = "sendMsgPersonal to " + targetUser + " error :" + reason;
					console.error(msg);
					addNewMessage(msg);
				});
			}
		};

		$scope.unsubscribeMePersonal = function() {
			console.log("unsubscribeMePersonal");
			if($scope.subscriptionPersonal !== null) {
				$scope.subscriptionPersonal.unsubscribe();
				var msg = "unsubscribePersonal done";
				console.log(msg);
				addNewMessage(msg);
			}
			else {
				var msg = "subscriptionPersonal is null...";
				console.error(msg);
				addNewMessage(msg);
			}
		};

		$scope.disconnectMe = function() {
			console.log("disconnectMe");
			if($scope.connected) {
				$stomp.disconnect().then(function () {
					var msg = "disconnect done";
					console.log(msg);
					addNewMessage(msg);
				}, function (reason) {
					var msg = "error " + reason;
					console.error(msg);
					addNewMessage(msg);
				});
			}
		};
	}]);
