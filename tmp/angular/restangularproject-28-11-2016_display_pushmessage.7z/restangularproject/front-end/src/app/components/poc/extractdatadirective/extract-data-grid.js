angular.module('myApp.extractdatagrid', ['agGrid'])
	.directive('extractDataGrid', function() {
		return {
			restrict: 'A',
			scope: {
				loadData: "=loadData",
				gridOptions: "@gridOptions"
			},
			controller : ['$scope', '$attrs', function ($scope, $attrs) {
				console.log('dataGridCtrl');

				var columnDefs = [
					{ headerName: "gop", field: "gop" },
					{ headerName: "indicator", field: "indicator" },
					{ headerName: "ytd", field: "ytd" }
				];

				$scope[$scope.gridOptions] = {
					columnDefs: columnDefs,
					rowData: []
				};

				$scope.loadData.then(function(result) {
					//console.log("callback result=" + JSON.stringify(result));
					$scope[$scope.gridOptions].api.setRowData(angular.copy(result.rows));
				});

				console.log('dataGridCtrl END');
			}],
			template: function(tElem, tAttrs){
				var template = '<div ag-grid="' + tAttrs.gridOptions + '" class="ag-fresh" style="height: 200px;"/>';
				return template;
			}
		};
	});
