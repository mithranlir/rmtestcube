angular.module('myApp.petra-air-grid-local-example', ['ngResource',  'myApp.petra-air-grid'])
	.controller('exampleCtrl',['$scope', '$resource', function($scope,  $resource) {
		console.log('exampleCtrl');
		this.welcomeText = 'Extract Data';
		$scope.loadData = $resource('/extractdata/list', {}).get({}).$promise;
		console.log('exampleCtrl end');
	}]);
