package my.web.project.rest.websocket;

import my.web.project.dto.push.NotifMessage;
import my.web.project.dto.push.UserMessage;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.stereotype.Controller;

import java.security.Principal;

@Controller
public class PushMessageController {

    public static final String QUEUE_PERSONALWARNING = "/queue/personalwarning";

    public PushMessageController() {
        System.out.println("PushMessageController : constructor");
    }

    @MessageMapping("/chat")
    @SendTo("/topic/messages")
    public NotifMessage greeting(UserMessage message) throws Exception {
        System.out.println("PushMessageController : greeting");
        Thread.sleep(1000);
        return new NotifMessage("Hello, " + message.getContent() + "!");
    }

    @MessageMapping("/personalwarning")
    @SendToUser(QUEUE_PERSONALWARNING)
    public NotifMessage personalmessage(UserMessage message, Principal principal) throws Exception {
        System.out.println("PushMessageController : personalmessage" + principal);
        Thread.sleep(1000);
        return new NotifMessage("Personal : " + message.getContent() + "!");
    }
}
