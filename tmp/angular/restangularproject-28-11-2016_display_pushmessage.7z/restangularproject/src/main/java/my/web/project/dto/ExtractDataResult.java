package my.web.project.dto;

import java.util.ArrayList;
import java.util.List;

public class ExtractDataResult {
    private List<ExtractDataRow> rows;

    public ExtractDataResult() {
        rows = new ArrayList<>();
    }

    public List<ExtractDataRow> getRows() {
        return rows;
    }

    public void setRows(List<ExtractDataRow> rows) {
        this.rows = rows;
    }
}
