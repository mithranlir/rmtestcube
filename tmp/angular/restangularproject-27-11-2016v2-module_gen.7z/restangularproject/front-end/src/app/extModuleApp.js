
require('angular');
require('angular-ui-router');
require('angular-aria');
require('angular-animate');
require('angular-material');
require('angular-resource');
require('angular-base64');
require('ng-stomp');

var agGrid = require('ag-grid');
agGrid.initialiseAgGridWithAngular1(angular);

require('petra-air-grid');

require('./components/petra-air-grid-module-example/example.js');

var app = angular.module('myApp',
    [ 'ui.router', 'ngResource', 'myApp.petra-air-grid', 'myApp.petra-air-grid-module-example' ]);

app.config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/");
    $stateProvider
        .state('home', {
            url: "/",
            views : {
                "" : {
                    templateUrl:"app/components/petra-air-grid-module-example/example.html"
                }
            }
        });
});
