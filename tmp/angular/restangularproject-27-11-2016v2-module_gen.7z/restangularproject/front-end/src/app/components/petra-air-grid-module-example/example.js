angular.module('myApp.petra-air-grid-module-example', ['ngResource', 'myApp.petra-air-grid'])
	.controller('extractDataExtModuleCtrl',['$scope', '$resource', function($scope,  $resource) {
		console.log('extractDataExtModuleCtrl');
		this.welcomeText = 'Extract Data Ext Module';
		$scope.loadData = $resource('/extractdata/list', {}).get({}).$promise;
		console.log('extractDataExtModuleCtrl end');
	}]);
