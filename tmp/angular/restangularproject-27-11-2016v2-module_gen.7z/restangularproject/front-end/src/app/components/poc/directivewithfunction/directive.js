var myApp = angular.module('myApp.directivewithfunction',[]);
myApp.directive('editkeyvalue', function() {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            key: '@',
            value: '@',
            accept: "&"
        },
        template :
            '<div>' +
                '<label class="control-label">{{key}}</label>' +
                '<input type="text" ng-model="value" />'+
                'toto={{toto}}' +
                '<button type="submit" ng-click="save()">SAVE</button>' +
            '</div>',
        controller: function($scope, $element, $attrs, $location) {
            $scope.toto = 'aaaa';
            $scope.save= function() {
                console.log('from directive', $scope.key, $scope.value);
                $scope.accept();
            };
        }
    };
});


myApp.controller('MyController', function($scope, $window) {
    $scope.blabla = function(msg) {
        console.log('from controller', $scope.key, $scope.value);
        $window.alert('hello ' + msg);
    };
});