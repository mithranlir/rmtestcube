angular.module('myApp.extractdatadirective', ['ngResource', 'myApp.extractdatagrid'])
	.controller('extractDataUsingDirectiveCtrl',['$scope', '$resource', function($scope,  $resource) {
		console.log('extractDataUsingDirectiveCtrl');
		this.welcomeText = 'Extract Data';
		$scope.loadData = $resource('/extractdata/list', {}).get({}).$promise;
		console.log('extractDataUsingDirectiveCtrl end');
	}]);
