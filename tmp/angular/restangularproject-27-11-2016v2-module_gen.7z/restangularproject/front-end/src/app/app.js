

require('angular');
require('angular-ui-router');
require('angular-aria');
require('angular-animate');
require('angular-material');
require('angular-resource');
require('angular-base64');
require('ng-stomp');

var agGrid = require('ag-grid');
agGrid.initialiseAgGridWithAngular1(angular);

require('./components/poc/home/home.js');
require('./components/poc/about/about.js');
require('./components/poc/testauth/testauth.js');
require('./components/poc/extractdata/extractdata.js');
require('./components/poc/pushmsg/pushmsg.js');
require('./components/poc/extractdatadirective/extract-data-call-directive.js');
require('./components/poc/extractdatadirective/extract-data-grid.js');
require('./components/poc/directive/directive.js');
require('./components/poc/directivewithfunction/directive.js');

require('./components/petra-air-grid/petra-air-grid.js');
require('./components/petra-air-grid-local-example/example.js');

var app = angular.module('myApp', ['ui.router','ngMaterial','ngResource', 'myApp.home','myApp.about',
    'myApp.extractdata', 'myApp.testauth', 'myApp.pushmsg', 'myApp.extractdatadirective',
    'myApp.directive', 'myApp.directivewithfunction', 'myApp.petra-air-grid-local-example']);

app.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise("/");

    $stateProvider
        .state('home', {
            url: "/",
            views : {
                "" : {
                    templateUrl:"app/components/poc/home/home.html"
                },
                "header@home":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
        .state('about', {
            url: "/about",
            views : {
                "" : {
                    templateUrl:"app/components/poc/about/about.html"
                },
                "header@about":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
        .state('testauth', {
            url: "/testauth",
            views : {
                "" : {
                    templateUrl:"app/components/poc/testauth/testauth.html"
                },
                "header@testauth":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
        .state('extractdata', {
            url: "/extractdata",
            views : {
                "" : {
                    templateUrl:"app/components/poc/extractdata/extractdata.html"
                },
                "header@extractdata":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
        .state('pushmsg', {
            url: "/pushmsg",
            views : {
                "" : {
                    templateUrl:"app/components/poc/pushmsg/pushmsg.html"
                },
                "header@pushmsg":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
        .state('extractdatadirective', {
            url: "/extractdatadirective",
            views : {
                "" : {
                    templateUrl:"app/components/poc/extractdatadirective/extract-data-call-directive.html"
                },
                "header@extractdatadirective":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
        .state('directive', {
            url: "/directive",
            views : {
                "" : {
                    templateUrl:"app/components/poc/directive/directivecall.html"
                },
                "header@directive":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
        .state('directivewithfunction', {
            url: "/directivewithfunction",
            views : {
                "" : {
                    templateUrl:"app/components/poc/directivewithfunction/directivecall.html"
                },
                "header@directivewithfunction":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
        .state('petra-air-grid-local-example', {
            url: "/petra-air-grid-local-example",
            views : {
                "" : {
                    templateUrl:"app/components/petra-air-grid-local-example/example.html"
                },
                "header@petra-air-grid-local-example":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
    ;
});
