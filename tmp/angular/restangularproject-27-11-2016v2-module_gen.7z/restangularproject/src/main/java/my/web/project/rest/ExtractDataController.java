package my.web.project.rest;

import my.web.project.dto.ExtractDataResult;
import my.web.project.dto.ExtractDataRow;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/extractdata")
public class ExtractDataController {
    @RequestMapping(path = "/list", method=RequestMethod.GET)
    public @ResponseBody ExtractDataResult extractData() {
        System.out.println("extractData called");
        final ExtractDataResult result = new ExtractDataResult();
        result.getRows().add(new ExtractDataRow("gop1", "notion1", 10000.0));
        result.getRows().add(new ExtractDataRow("gop2", "notion1", 4000.0));
        result.getRows().add(new ExtractDataRow("gop3", "notion1", 6000.0));
        return result;
    }
}