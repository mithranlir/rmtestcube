package my.web.project.rest;

import my.web.project.service.PersonalServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/direct")
public class PersonalMessageController {

    @Autowired
    private PersonalServiceImpl personalServiceImpl;

    public PersonalMessageController() {
        System.out.println("PersonalMessageController : constructor");
    }

    @RequestMapping(path = "/personalmessage/{user}", method= RequestMethod.GET)
    public @ResponseBody String personalmessage(@PathVariable String user) throws Exception {
        System.out.println("PersonalMessageController.personalmessage : " + user);
        personalServiceImpl.notifyUser("WELCOME !!", user);
        return "OK";
    }
}
