package my.web.project.dto.push;

public class NotifMessage {

    private String content;

    public NotifMessage() {
    }

    public NotifMessage(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
