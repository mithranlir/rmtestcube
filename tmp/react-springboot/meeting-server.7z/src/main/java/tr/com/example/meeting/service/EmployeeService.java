package tr.com.example.meeting.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tr.com.example.meeting.domain.Employee;

import java.util.ArrayList;
import java.util.List;

/**
 * Employee service.
 * 
 * @author ali.cavac
 *
 */
@Service("employeeService")
public class EmployeeService {

    public List<Employee> list() {
        return FakeData.employees;
    }
    
    public Employee findById(Integer id) {
        return FakeData.employees.stream().filter(employee -> id.equals(employee.getId())).findFirst().get();
    }
 
    public Boolean saveEmployee(Employee employee) {
        employee.setId(FakeData.cptEmployeeId++);
        FakeData.employees.add(employee);
        return true;
    }
 
    public Boolean updateEmployee(Employee employee) {
        Employee entity = findById(employee.getId());
        if(entity != null){
            entity.setName(employee.getName());
            entity.setDepartmentId(employee.getDepartmentId());
            entity.setSalary(employee.getSalary());
            entity.setSurname(employee.getSurname());
            return true;
        }
        else{
            return false;
        }
    }
    
    public Boolean deleteById(Integer id) {
        return FakeData.employees.removeIf(employee -> id.equals(employee.getId()));

    }
}