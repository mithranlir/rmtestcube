package tr.com.example.meeting.service;

import org.springframework.stereotype.Service;
import tr.com.example.meeting.domain.Department;

import java.util.List;

@Service("departmentService")
public class DepartmentService {

    public List<Department> list() {
        return FakeData.departments;
    }    
    
    public Department findById(Integer id) {
        return FakeData.departments.stream().filter(department -> id.equals(department.getId())).findFirst().get();
    }
 
    public Boolean saveDepartment(Department department) {
        department.setId(FakeData.cptDepartmentId++);
        FakeData.departments.add(department);
        return true;
    }
 
    public Boolean updateDepartment(Department department) {
        Department entity = findById(department.getId());
        if(entity != null){
            entity.setName(department.getName());
            entity.setDescription(department.getDescription());
            entity.setEmployees(department.getEmployees());
            return true;
        }
        else{
            return false;
        }
    }
    
    public Boolean deleteById(Integer id) {
        return FakeData.departments.removeIf(meeting -> id.equals(meeting.getId()));
    }
}