package tr.com.example.meeting.service;

import tr.com.example.meeting.domain.Department;
import tr.com.example.meeting.domain.Employee;
import tr.com.example.meeting.domain.Meeting;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Romain on 11/01/2018.
 */
public class FakeData {

    public static int cptDepartmentId = 1;
    public static List<Department> departments = new ArrayList<>();

    public static int cptEmployeeId = 1;
    public static List<Employee> employees = new ArrayList<>();

    public static int cptMeetingId = 1;
    public static List<Meeting> meetings = new ArrayList<>();

    static {

        final Department d1 = new Department();
        d1.setName("dep1");
        d1.setDescription("desc1");
        d1.setId(cptDepartmentId++);
        d1.setEmployees(new ArrayList<>());
        departments.add(d1);

        final Department d2 = new Department();
        d2.setName("dep2");
        d2.setDescription("desc2");
        d2.setId(cptDepartmentId++);
        d2.setEmployees(new ArrayList<>());
        departments.add(d2);

        final Employee e1 = new Employee();
        e1.setId(cptEmployeeId++);
        e1.setSalary(100);
        e1.setSurname("nom1");
        e1.setName("nom1");
        employees.add(e1);

        final Employee e2 = new Employee();
        e2.setId(cptEmployeeId++);
        e2.setSalary(200);
        e2.setSurname("nom2");
        e2.setName("nom2");
        employees.add(e2);

        final Employee e3 = new Employee();
        e3.setId(cptEmployeeId++);
        e3.setSalary(300);
        e3.setSurname("nom3");
        e3.setName("nom3");
        employees.add(e3);

        final Meeting m1 = new Meeting();
        m1.setName("meeting1");
        m1.setDescription("meeting1");
        m1.setId(cptMeetingId++);
        m1.setDepartments(new ArrayList<>());
        meetings.add(m1);

        final Meeting m2 = new Meeting();
        m2.setName("meeting2");
        m2.setDescription("meeting2");
        m2.setDepartments(new ArrayList<>());
        m2.setId(cptMeetingId++);
        meetings.add(m2);

        d1.getEmployees().add(e1);
        d1.getEmployees().add(e3);
        e1.setDepartmentId(d1.getId());
        e3.setDepartmentId(d1.getId());
        m1.getDepartments().add(d1);

        d2.getEmployees().add(e2);
        e2.setDepartmentId(d2.getId());
        m2.getDepartments().add(d2);

    }
}
