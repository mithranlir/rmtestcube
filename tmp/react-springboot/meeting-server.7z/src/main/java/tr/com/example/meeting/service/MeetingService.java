package tr.com.example.meeting.service;

import org.springframework.stereotype.Service;
import tr.com.example.meeting.domain.Meeting;

import java.util.List;

@Service("meetingService")
public class MeetingService {

    public List<Meeting> list() {
        return FakeData.meetings;
    }

    public Meeting findById(Integer id) {
        return FakeData.meetings.stream().filter(meeting -> id.equals(meeting.getId())).findFirst().get();
    }

    public Boolean saveMeeting(Meeting meeting) {
        meeting.setId(FakeData.cptMeetingId++);
        FakeData.meetings.add(meeting);
        return true;
    }

    public Boolean updateMeeting(Meeting meeting) {
        Meeting entity = findById(meeting.getId());
        if(entity != null){
            entity.setName(meeting.getName());
            entity.setDescription(meeting.getDescription());
            entity.setDepartments(meeting.getDepartments());
            return true;
        }
        else{
            return false;
        }
    }

    public Boolean deleteById(Integer id) {
        return FakeData.meetings.removeIf(meeting -> id.equals(meeting.getId()));
    }
}