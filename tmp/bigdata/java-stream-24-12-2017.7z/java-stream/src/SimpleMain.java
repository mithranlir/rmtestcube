import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

import static java.util.stream.Collectors.toList;

public class SimpleMain {

    public static void main(String[] args) throws ExecutionException, InterruptedException {

        // longstream();
        // useCompletableFutureWithExecutor();

        // defaultForkJoinPool();
        customForkJoinPool();
    }

    private static void longstream() throws ExecutionException, InterruptedException {
        final long firstNum = 1;
        long lastNum = 1_000_000;

        final List<Long> aList = LongStream.rangeClosed(firstNum, lastNum).boxed()
                .collect(toList());

        final ForkJoinPool customThreadPool = new ForkJoinPool(4);
        long actualTotal = customThreadPool.submit(
                () -> aList.parallelStream().reduce(0L, Long::sum)).get();

        System.out.println("actualTotal=" + actualTotal);
        System.out.println("res=" + (lastNum + firstNum) * lastNum / 2);

    }

    public static class MyTask {
        final int val;
        public MyTask(int val) {
            this.val = val;
        }
        public Integer calculate() {
            System.out.println(Thread.currentThread().getThreadGroup().toString() + " : " +  Thread.currentThread().toString());
            return val * val;
        }
    }

    public static class NumValidator {
        public static Set<String> threadNames = new ConcurrentSkipListSet<>();

        public static boolean isValid(Integer val) {
            threadNames.add(Thread.currentThread().getName());
            return val % 10 == 0;
        }
    }

    public static void defaultForkJoinPool() throws ExecutionException, InterruptedException {

        final List<Integer> value = IntStream.range(1, 1_000_000).boxed()
                .parallel()
                .filter(NumValidator::isValid)

                .collect(Collectors.toList());


        System.out.println(NumValidator.threadNames);
    }

    public static void customForkJoinPool() throws ExecutionException, InterruptedException {
        final ForkJoinPool forkJoinPool = new ForkJoinPool(2);
        final List<Integer> value = forkJoinPool.submit(() ->
                        //parallel task here, for example
                        IntStream.range(1, 1_000_000).parallel()
                                .filter(NumValidator::isValid)
                                .boxed()
                                .collect(Collectors.toList())
        ).get();

        System.out.println(NumValidator.threadNames);
    }

    public static void useCompletableFutureWithExecutor() {

        final List<MyTask> tasks = new ArrayList<>();
        for(int i=0; i<1000; i++) {
            tasks.add(new MyTask(i));
        }

        final long start = System.nanoTime();
        final ExecutorService executor = Executors.newFixedThreadPool(Math.min(tasks.size(), 10));

        final List<CompletableFuture<Integer>> futures =
                tasks.stream()
                        .map(t -> CompletableFuture.supplyAsync(() -> t.calculate(), executor))
                        .collect(toList());

        final List<Integer> result =
                futures.stream()
                        .map(CompletableFuture::join)
                        .collect(toList());
        final long duration = (System.nanoTime() - start) / 1_000_000;
        System.out.printf("Processed %d tasks in %d millis\n", tasks.size(), duration);
        System.out.println(result);
    }

}
