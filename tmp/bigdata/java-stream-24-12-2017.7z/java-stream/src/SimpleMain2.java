import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import java.util.function.IntConsumer;
import java.util.stream.Collectors;

public class SimpleMain2 {

    private static class MyClass {
        private String value1;
        private int value2;
        private int value3;

        public MyClass(String value1, int value2) {
            this.value1 = value1;
            this.value2 = value2;
            this.value3 = 0;
        }

        public MyClass(String value1, int value2, int value3) {
            this.value1 = value1;
            this.value2 = value2;
            this.value3 = value3;
        }

        public String getValue1() {
            return value1;
        }

        public void setValue1(String value1) {
            this.value1 = value1;
        }

        public int getValue2() {
            return value2;
        }

        public void setValue2(int value2) {
            this.value2 = value2;
        }

        public int getValue3() {
            return value3;
        }

        public void setValue3(int value3) {
            this.value3 = value3;
        }

        @Override
        public String toString() {
            return "MyClass{" +
                    "value1='" + value1 + '\'' +
                    ", value2=" + value2 +
                    ", value3=" + value3 +
                    '}';
        }
    }


    private static class Averager implements IntConsumer
    {
        private int total = 0;
        private int count = 0;

        public double average() {
            return count > 0 ? ((double) total)/count : 0;
        }

        public void accept(int i) { total += i; count++; }
        public void combine(Averager other) {
            total += other.total;
            count += other.count;
        }
    }


    public static final void main(String... args) {

        // exampleFilter();
        // exampleReduce();
        // exampleCollector();
        // exampleGrouping();
        // exampleGroupingSumAndAverage();
        exampleGroupingParallel();
    }

    private static void exampleGroupingParallel() {

        final List<MyClass> list = new ArrayList<>();
        list.add(new MyClass("AAAA", 1));
        list.add(new MyClass("BBBB", 2));
        list.add(new MyClass("CCCC", 1));
        list.add(new MyClass("DDDD", 4));


        System.out.println("grouping parallel --> ");

        final Map<Integer, List<MyClass>> result = list.parallelStream()
                .collect(Collectors.groupingByConcurrent(MyClass::getValue2));

        result.entrySet().stream().forEach((v) -> {
            System.out.println("KEY=" + v.getKey());
            v.getValue().stream().map(MyClass::getValue1)
                    .forEach((n) -> System.out.println("NAME=" + n));
        });

        System.out.println("grouping2 parallel  --> ");

        final ConcurrentMap<Integer, List<String>> result2 = list.parallelStream()
                .collect(Collectors.groupingByConcurrent(
                                MyClass::getValue2,
                                Collectors.mapping(
                                        MyClass::getValue1,
                                        Collectors.toList()))
                );

        result2.entrySet().stream().forEach((v) -> {
            System.out.println("KEY=" + v.getKey());
            v.getValue().stream()
                    .forEach((n) -> System.out.println("NAME=" + n));
        });
    }

    private static void exampleGroupingSumAndAverage() {

        final List<MyClass> list = new ArrayList<>();
        list.add(new MyClass("AAAA", 1, 1));
        list.add(new MyClass("BBBB", 2, 1));
        list.add(new MyClass("CCCC", 1, 2));
        list.add(new MyClass("DDDD", 4, 2));

        System.out.println("grouping sum --> ");

        final Map<Integer, Integer> result = list.stream()
                .collect(Collectors.groupingBy(
                                MyClass::getValue3,
                                Collectors.reducing(
                                        0,
                                        MyClass::getValue2,
                                        Integer::sum
                                )
                       ));

        result.entrySet().stream().forEach((v) ->
            System.out.println("KEY=" + v.getKey() + " VALUE=" + v.getValue())
        );

        System.out.println("grouping average --> ");

        final Map<Integer, Double> result2 = list.stream()
                .collect(Collectors.groupingBy(
                        MyClass::getValue3,
                        Collectors.averagingInt(MyClass::getValue2)
                ));

        result2.entrySet().stream().forEach((v) ->
                        System.out.println("KEY=" + v.getKey() + " VALUE=" + v.getValue())
        );
    }

    private static void exampleGrouping() {

        final List<MyClass> list = new ArrayList<>();
        list.add(new MyClass("AAAA", 1));
        list.add(new MyClass("BBBB", 2));
        list.add(new MyClass("CCCC", 1));
        list.add(new MyClass("DDDD", 4));


        System.out.println("grouping --> ");

        final Map<Integer, List<MyClass>> result = list.stream()
                .collect(Collectors.groupingBy(MyClass::getValue2));

        result.entrySet().stream().forEach((v) -> {
            System.out.println("KEY=" + v.getKey());
            v.getValue().stream().map(MyClass::getValue1)
                    .forEach((n) -> System.out.println("NAME=" + n));
        });

        System.out.println("grouping2 --> ");

        final Map<Integer, List<String>> result2 = list.stream()
                .collect(Collectors.groupingBy(
                        MyClass::getValue2,
                        Collectors.mapping(
                                MyClass::getValue1,
                                Collectors.toList()))
                        );

        result2.entrySet().stream().forEach((v) -> {
            System.out.println("KEY=" + v.getKey());
            v.getValue().stream()
                    .forEach((n) -> System.out.println("NAME=" + n));
        });
    }


    private static void exampleCollector() {

        final List<MyClass> list = new ArrayList<>();
        list.add(new MyClass("AAAA", 1));
        list.add(new MyClass("BBBB", 2));
        list.add(new MyClass("CCCC", 3));
        list.add(new MyClass("DDDD", 4));

        System.out.println("collector --> ");

        Averager averageCollect = list.stream()
                .filter((i) -> i.getValue2() > 2)
                .map(MyClass::getValue2)
                .collect(Averager::new, Averager::accept, Averager::combine);

        System.out.println("Average value : " +
                    averageCollect.average());


        System.out.println("collector --> ");

        System.out.println("names=" + list.stream()
                .filter((i) -> i.getValue2() > 2)
                .map(MyClass::getValue1)
                .collect(Collectors.toList()));

    }


    private static void exampleReduce() {

        final List<MyClass> list = new ArrayList<>();
        list.add(new MyClass("AAAA", 1));
        list.add(new MyClass("BBBB", 2));
        list.add(new MyClass("CCCC", 3));
        list.add(new MyClass("DDDD", 4));

        System.out.println("avg --> ");
        System.out.println("sum=" + list.stream()
                .filter((i) -> i.getValue2() > 2)
                .mapToInt(MyClass::getValue2)
                .sum());
        System.out.println("");

        System.out.println("reduce --> ");
        System.out.println("reduce=" + list.stream()
                .filter((i) -> i.getValue2() > 2)
                .mapToInt(MyClass::getValue2)
                .reduce(0, (a, b) -> a + b));
        System.out.println("");
    }

    private static void exampleFilter() {

        final List<MyClass> list = new ArrayList<>();
        list.add(new MyClass("AAAA", 1));
        list.add(new MyClass("BBBB", 2));
        list.add(new MyClass("CCCC", 3));
        list.add(new MyClass("DDDD", 4));

        System.out.println("FILTER --> ");
        list.stream()
                .filter((i) -> i.getValue2() > 2)
                .forEach((i) -> System.out.println("OBJ=" + i));
        System.out.println("");

        System.out.println("FILTER MapToInt --> ");
        list.stream()
                .filter((i) -> i.getValue2() > 2)
                .mapToInt(MyClass::getValue2)
                .forEach((i) -> System.out.println("int=" + i));
        System.out.println("");

        System.out.println("FILTER MapToInt average --> ");
        System.out.println("average=" + list.stream()
                .filter((i) -> i.getValue2() > 2)
                .mapToInt(MyClass::getValue2)
                .average().getAsDouble());
        System.out.println("");
    }


}
