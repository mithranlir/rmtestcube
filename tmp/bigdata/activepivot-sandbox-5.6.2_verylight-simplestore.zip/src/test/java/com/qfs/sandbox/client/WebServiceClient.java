/*
 * (C) Quartet FS 2010-2015
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.client;

import static com.qfs.sandbox.cfg.security.impl.ASecurityConfig.ROLE_USER;
import static com.qfs.server.cfg.impl.ActivePivotServicesConfig.CONFIGURATION_SERVICE;
import static com.qfs.server.cfg.impl.ActivePivotServicesConfig.ID_GENERATOR_SERVICE;
import static com.qfs.server.cfg.impl.ActivePivotServicesConfig.LONG_POLLING_SERVICE;
import static com.qfs.server.cfg.impl.ActivePivotServicesConfig.QUERY_SERVICE;
import static com.qfs.server.cfg.impl.ActivePivotServicesConfig.STREAMING_SERVICE;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.quartetfs.biz.pivot.ILocation;
import com.quartetfs.biz.pivot.definitions.impl.CalculatedMemberDescription;
import com.quartetfs.biz.pivot.dto.CellDTO;
import com.quartetfs.biz.pivot.dto.CellSetDTO;
import com.quartetfs.biz.pivot.dto.DrillthroughResultDTO;
import com.quartetfs.biz.pivot.dto.DrillthroughRowDTO;
import com.quartetfs.biz.pivot.dto.HierarchyDTO;
import com.quartetfs.biz.pivot.dto.PermissionsMapDTO;
import com.quartetfs.biz.pivot.impl.Location;
import com.quartetfs.biz.pivot.impl.LocationUtil;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.query.impl.DrillthroughQuery;
import com.quartetfs.biz.pivot.query.impl.MDXQuery;
import com.quartetfs.biz.pivot.server.webservices.impl.WebServiceFactory;
import com.quartetfs.biz.pivot.webservices.IConfigurationService;
import com.quartetfs.biz.pivot.webservices.IQueriesService;
import com.quartetfs.biz.pivot.webservices.impl.JAXBDataBindingFactory;
import com.quartetfs.tech.streaming.IBulkedEvents;
import com.quartetfs.tech.streaming.IDomainEvent;
import com.quartetfs.tech.streaming.IIdGenerator;
import com.quartetfs.tech.streaming.ILongPollingService;
import com.quartetfs.tech.streaming.IStreamEvent;
import com.quartetfs.tech.streaming.IStreamProperties;
import com.quartetfs.tech.streaming.IStreamProperties.InitialState;
import com.quartetfs.tech.streaming.IStreamingService;
import com.quartetfs.tech.streaming.impl.StreamProperties;

/**
 *
 * A simple web service client to illustrate web service
 * consumption from a Java client.
 *
 * @author Quartet Financial Systems
 *
 */
public class WebServiceClient {

	/** Logger **/
	private static Logger logger = Logger.getLogger(WebServiceClient.class.getName());

	/** Base url for web services */
	static final String BASE_URL = "http://localhost:9090/webservices/";

	/** Publication domain */
	static final String PUBLICATION_DOMAIN = "test-domain";

	/** User name */
	static final String USER = "admin";

	/** User password */
	static final String PASSWORD = "admin";

	/**
	 * You can run this sample client once the Sandbox server has been started.
	 *
	 * @param args the arguments
	 * @throws Exception the exception
	 */
	public static void main(String[] args) throws Exception {
		// Create a JAXB data binding
		JAXBDataBindingFactory bindingFactory = new JAXBDataBindingFactory();

		// Create a JAX-WS service factories for the target services.
		WebServiceFactory<IQueriesService> queriesServiceFactory = new WebServiceFactory<>();
		queriesServiceFactory.setAddress(BASE_URL + QUERY_SERVICE);
		queriesServiceFactory.setServiceClass(IQueriesService.class);
		initFactory(queriesServiceFactory, bindingFactory);

		WebServiceFactory<IConfigurationService> configurationServiceFactory = new WebServiceFactory<>();
		configurationServiceFactory.setAddress(BASE_URL + CONFIGURATION_SERVICE);
		configurationServiceFactory.setServiceClass(IConfigurationService.class);
		initFactory(configurationServiceFactory, bindingFactory);

		WebServiceFactory<IStreamingService> streamingServiceFactory = new WebServiceFactory<>();
		streamingServiceFactory.setAddress(BASE_URL + STREAMING_SERVICE);
		streamingServiceFactory.setServiceClass(IStreamingService.class);
		initFactory(streamingServiceFactory, bindingFactory);

		WebServiceFactory<ILongPollingService> longPollingServiceFactory = new WebServiceFactory<>();
		longPollingServiceFactory.setAddress(BASE_URL + LONG_POLLING_SERVICE);
		longPollingServiceFactory.setServiceClass(ILongPollingService.class);
		initFactory(longPollingServiceFactory, bindingFactory);

		WebServiceFactory<IIdGenerator> idGeneratorServiceFactory = new WebServiceFactory<>();
		idGeneratorServiceFactory.setAddress(BASE_URL + ID_GENERATOR_SERVICE);
		idGeneratorServiceFactory.setServiceClass(IIdGenerator.class);
		initFactory(idGeneratorServiceFactory, bindingFactory);

		// Instantiate services using the factories
		IQueriesService queriesService = queriesServiceFactory.create();
		IConfigurationService configurationService = configurationServiceFactory.create();
		IStreamingService streamingService = streamingServiceFactory.create();
		ILongPollingService longPollingService = longPollingServiceFactory.create();
		IIdGenerator idGenerator = idGeneratorServiceFactory.create();

		// List hierarchies
		logger.log(Level.INFO, "Discovering hierarchies:");
		List<HierarchyDTO> hierarchies = queriesService.retrieveAllHierarchies("EquityDerivativesCube");
		for(HierarchyDTO hier : hierarchies) {
			logger.log(Level.INFO, "Discovered hierarchy: " + hier);
		}

		// Execute an (ad-hoc) MDX query
		String mdx = "SELECT NON EMPTY {DrilldownLevel({[Booking].[ALL].[AllMember]})} ON ROWS FROM [EquityDerivativesCube] WHERE ([Measures].[contributors.COUNT])";
		IMDXQuery mdxQuery = new MDXQuery(mdx);
		logger.log(Level.INFO, "Executing MDX query: " + mdx);
		CellSetDTO cellSet = queriesService.execute(mdxQuery);
		List<CellDTO> cells = cellSet.getCells();
		for(CellDTO cell : cells) {
			logger.log(Level.INFO, "Cell: " + cell);
		}

		// Execute an (ad-hoc) drillthrough query
		String locationString = "AllMember|AllMember|AllMember|AllMember\\EUR|AllMember|AllMember|AllMember|AllMember|AllMember|[*]|AllMember|AllMember";
		ILocation location = new Location(LocationUtil.stringToArrayLocation(locationString));
		DrillthroughQuery drillthroughQuery = new DrillthroughQuery();
		drillthroughQuery.setLocations(Arrays.asList(location));
		drillthroughQuery.setPivotId("EquityDerivativesCube");
		logger.log(Level.INFO, "Executing Drillthrough query: " + location);
		DrillthroughResultDTO result = queriesService.execute(drillthroughQuery);
		List<DrillthroughRowDTO> rows = result.getRows();
		logger.log(Level.INFO, "Drillthrough query returned " + rows.size() + " rows.");
		for(DrillthroughRowDTO row : rows) {
			logger.log(Level.INFO, "Row: " + row);
		}

		// Add a calculated member
		configurationService.createCalculatedMember("EquityDerivativesCube", new CalculatedMemberDescription(
				"[Measures].[test]",
				"1"), ROLE_USER, ROLE_USER);
		PermissionsMapDTO calculatedMembers = configurationService.getCalculatedMembers("EquityDerivativesCube");
		logger.log(Level.INFO, "calculatedMembers: " + calculatedMembers);
		configurationService.removeCalculatedMember("EquityDerivativesCube", "[Measures].[test]");

		// Initiate a (long polling based) communication channel
		String listenerId = idGenerator.generateListenerIds(1).get(0);
		longPollingService.addListener(PUBLICATION_DOMAIN, listenerId);
		new Thread(new Listener(longPollingService, listenerId)).start();

		// Subscribe a continuous mdx query, events will be received through the communication channel.
		List<String> ids = idGenerator.generateStreamIds(2);
		String mdxStreamId = ids.get(0);
		String drillthroughStreamId = ids.get(1);

		IStreamProperties mdxStreamProperties = new StreamProperties(
				mdxStreamId,
				mdxStreamId,
				PUBLICATION_DOMAIN,
				InitialState.STARTED,
				true);
		streamingService.createStream(mdxQuery, mdxStreamProperties);

		// Subscribe a continuous drillthrough query, events will be received through the communication channel.
		// Note that drillthrough events will be rare, because real-time updates are random will rarely
		// fall exactly in the drillthrough location (unless you configure a massive flow of trade updates).
		IStreamProperties drillthroughStreamProperties = new StreamProperties(
				drillthroughStreamId,
				drillthroughStreamId,
				PUBLICATION_DOMAIN,
				InitialState.STARTED,
				true);
		streamingService.createStream(drillthroughQuery, drillthroughStreamProperties);
	}

	protected static void initFactory(WebServiceFactory<?> factory, JAXBDataBindingFactory bindingFactory) throws Exception {
		factory.setDataBinding(bindingFactory.create());
		factory.setUsername(USER);
		factory.setPassword(PASSWORD);
		factory.setConnectionTimeout(5000);
		factory.setReceiveTimeout(30000);
		factory.setDisableChunking(true);
	}

	/**
	 *
	 * Listener agent, listens to 100 events and leaves.
	 *
	 * @author Quartet Financial Systems
	 *
	 */
	static class Listener implements Runnable {

		final ILongPollingService service;
		final String listenerId;

		Listener(ILongPollingService service, String listenerId) {
			this.service = service;
			this.listenerId = listenerId;
		}

		@Override
		public void run() {
			for(int iteration = 0; iteration < 100; iteration++) {
				IBulkedEvents events = service.listen(listenerId);
				if(events != null) {
					logger.log(Level.INFO, "Received events:");
					for(IDomainEvent domainEvent : events.getDomainEvents()) {
						for(IStreamEvent event : domainEvent.getEvents())
							logger.log(Level.INFO, event.toString());
					}
				} else
					logger.log(Level.INFO, "No events received.");
			}
		}
	}

}
