/*
 * (C) Quartet FS 2013-2015 ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY property of Quartet
 * Financial Systems Limited. Any unauthorized use, reproduction or transfer of this material is strictly prohibited
 * package com.qfs.sandbox.server;
 */
package com.qfs.sandbox.server;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.junit.Test;
import org.springframework.core.env.AbstractEnvironment;

import com.qfs.sandbox.cfg.content.impl.EmbeddedContentServiceConfig;
import com.qfs.sandbox.cfg.impl.ActivePivotServerConfig;

/**
 * Tests the launching of all servers embedded together and a CSV load.
 */
public class TestFullServer extends ATestActivePivotServer {

	/**
	 * Tests that the server can start and run, with CSV loading enabled.
	 *
	 * @throws Exception If the test fails.
	 */
	@Test
	public void testServerWithCSV() throws Exception {
		doTestServerWithCSV();
	}

	@Override
	protected Server createPivotServer(int port) {
		return ActivePivotServer.createServer(port);
	}

	@Override
	protected String getPivotServerClassName() {
		return ActivePivotServerConfig.class.getName();
	}

	@Override
	protected void addInitParameters(ServletContextHandler context) {
		context.setInitParameter(AbstractEnvironment.DEFAULT_PROFILES_PROPERTY_NAME,
				String.join(",",
						EmbeddedContentServiceConfig.SPRING_PROFILE));
	}

}
