/*
 * (C) Quartet FS 2011-2016
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.client;

import com.qfs.sandbox.server.ActivePivotServer;

/**
 *
 * Rest client that connects to the ActivePivot REST services
 * and exchange request and responses in JSon.
 *
 * @author Quartet FS
 *
 */
public class ActivePivotServerRestClient extends AActivePivotRestClient {

	/**
	 * Default constructor.
	 * <p>
	 *   This creates a client targetting detault sandbox server.
	 * </p>
	 */
	public ActivePivotServerRestClient() {
		this(ActivePivotServer.DEFAULT_PORT);
	}

	/**
	 * Full constructor.
	 * @param port server port
	 */
	public ActivePivotServerRestClient(final int port) {
		super(port);
	}

	/**
	 *
	 * Launch the client and perform a series of tests.
	 *
	 * @param args the parameters (unused)
	 * @throws Exception In case of failure.
	 */
	public static void main(String[] args) throws Exception {
		new ActivePivotServerRestClient().run();
	}
}
