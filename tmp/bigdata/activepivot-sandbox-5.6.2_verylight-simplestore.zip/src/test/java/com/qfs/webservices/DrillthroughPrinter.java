/*
 * (C) Quartet FS 2013
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.webservices;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;

/**
 * An utility class to print stuff related to the Drill-through, notably
 * {@link DrillthroughResult drill-through results}.
 *
 * @author Quartet FS
 */
public class DrillthroughPrinter {

	/**
	 * Prints a {@link DrillthroughResult} to the given stream.
	 *
	 * @param result The result to print
	 * @param stream The stream to which the result should be printed.
	 * @param maxLines The maximum number of lines to print. This does not takes
	 *        the header into account.
	 * @param columnSize The size of a column. Entries that are bigger than this
	 *        will be truncated.
	 */
	public static void printDrillthroughResult(final DrillthroughResult result,
			final OutputStream stream,
			final int maxLines,
			final int columnSize) {
		PrintWriter writer = new PrintWriter(stream);

		// Build up the printing format.
		final List<DrillthroughHeader> headers = result.getHeaders().getHeaders();
		final int nh = headers.size();
		final StringBuilder formatBuilder = new StringBuilder();
		for (int i = 0; i < nh; ++i) {
			formatBuilder.append("%-").append(columnSize).append("s");
			if (i != nh - 1) {
				formatBuilder.append(" | ");
			} else {
				formatBuilder.append("%n");
			}
		}

		final String format = formatBuilder.toString();

		// Print the headers.
		writer.printf(format, toStringArray(headers, columnSize));

		// Print the list of rows
		int cnt = 0;
		for (DrillthroughRow r : result.getRows().getRows()) {
			if (cnt > maxLines) {
				break;
			}
			writer.printf(format, toStringArray(r.getContent().getUnderlying().toArray(), columnSize));
			cnt++;
		}

		// Actually print.
		writer.flush();
	}

	/**
	 * Turns a list of {@link DrillthroughHeader} to an array of strings using
	 * their {@link DrillthroughHeader#getName()} function.
	 *
	 * @param objs
	 * @param maxSize The maximum size of each string. Bigger strings will be
	 *        truncated.
	 * @return an array of string
	 */
	protected static Object[] toStringArray(List<DrillthroughHeader> objs, int maxSize) {
		String[] res = new String[objs.size()];
		for (int i = 0; i < objs.size(); ++i) {
			res[i] = objs.get(i).getName();
			if (res[i].length() > maxSize) {
				res[i] = res[i].substring(0, maxSize);
			}
		}

		return res;
	}

	/**
	 * Turns an array of object to an array of strings using their
	 * {@link Object#toString()} function.
	 *
	 * @param objs
	 * @param maxSize The maximum size of each string. Bigger strings will be
	 *        truncated.
	 * @return an array of string
	 */
	protected static Object[] toStringArray(Object[] objs, int maxSize) {
		String[] res = new String[objs.length];
		for (int i = 0; i < objs.length; ++i) {
			if (objs[i] != null) {
				res[i] = objs[i].toString();
				if (res[i].length() > maxSize) {
					res[i] = res[i].substring(0, maxSize);
				}
			}
		}

		return res;
	}
}
