/*
 * (C) Quartet FS 2015
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.server;

import static com.qfs.server.cfg.content.impl.AContentServiceConfig.CALCULATED_MEMBER_ROLE_PROPERTY;
import static com.qfs.server.cfg.content.impl.AContentServiceConfig.KPI_ROLE_PROPERTY;
import static com.qfs.server.cfg.content.impl.AContentServiceConfig.REMOTE_API_URL_PROPERTY;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.Console;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.qfs.content.service.IContentService;
import com.qfs.content.service.impl.RemoteContentService;
import com.qfs.pivot.content.IActivePivotContentService;
import com.qfs.pivot.content.impl.ActivePivotContentService;
import com.qfs.pivot.content.impl.ActivePivotContentServiceUtil;
import com.qfs.rest.client.impl.ABasicAuthenticator;
import com.qfs.rest.client.impl.UserAuthenticator;
import com.qfs.server.cfg.i18n.impl.I18nConfig;
import com.qfs.util.impl.QfsArrays;
import com.qfs.util.impl.QfsProperties;
import com.quartetfs.fwk.IPair;
import com.quartetfs.fwk.QuartetRuntimeException;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.contributions.impl.ClasspathContributionProvider;
import com.quartetfs.fwk.impl.Pair;
import com.quartetfs.fwk.security.ISecurityDetails;
import com.quartetfs.fwk.security.ISecurityFacade;
import com.quartetfs.fwk.security.QuartetSecurityException;
import com.quartetfs.fwk.security.impl.SecurityDetails;

/**
 * Utility class to push the configuration from the file system into a remote content service or
 * directly into the database.
 * <p>
 * This utility class can easily be turned into an utility that can pull from the content service,
 * to keep the current repo up to data with the content server, by replacing the call to
 * <code>ActivePivotContentServiceUtil#push*</code> with calls to
 * <code>ActivePivotContentServiceUtil#pull*</code>
 *
 * @author Quartet FS
 */
public class PushToContentServer {

	/**
	 * The pivot properties containing the configuration of the content service. In a static
	 * variable to be accessible before bean initialization.
	 */
	protected static final Properties properties = QfsProperties.loadProperties("content.service.properties");

	/**
	 * @return the role allowed to add new calculated members as defined in the configuration
	 *         service
	 */
	protected static String getCalculatedMemberRole() {
		return properties.getProperty(CALCULATED_MEMBER_ROLE_PROPERTY);
	}

	/**
	 * @return the url of the remote content service as defined in the configuration service
	 */
	protected static String getRemoteContentServiceUrl() {
		return properties.getProperty(REMOTE_API_URL_PROPERTY);
	}

	/**
	 * @return the role allowed to add new KPIs as defined in the configuration service
	 */
	protected static String getKpiRole() {
		return properties.getProperty(KPI_ROLE_PROPERTY);
	}

	/**
	 * Run this main to push the descriptions and the role from the file system
	 * into the content server.
	 *
	 * @param args the arguments
	 * @throws InterruptedException the exception
	 * @throws InvocationTargetException the exception
	 */
	public static void main(String[] args) throws InterruptedException, InvocationTargetException {
		Registry.setContributionProvider(new ClasspathContributionProvider());

		IContentService cs = getContentService(
				getCredentialsFromCommandLineArguments(args),
				getRemoteContentServiceUrlFromCommandLineArguments(args)
		);
		final IActivePivotContentService apcs = new ActivePivotContentService(cs);

		final String calculatedMemberRole = getCalculatedMemberRole();
		if (null == calculatedMemberRole) {
			throw new QuartetRuntimeException(
					"The role allowed to create new calculated members was not defined. Please set the property "
							+ CALCULATED_MEMBER_ROLE_PROPERTY);
		}

		final String kpiRole = getKpiRole();
		if (null == kpiRole) {
			throw new QuartetRuntimeException(
					"The role allowed to create new kpis was not defined. Please set the property "
							+ KPI_ROLE_PROPERTY);
		}

		System.out.println("Updating content service");
		ActivePivotContentServiceUtil.initialize(apcs, calculatedMemberRole, kpiRole);
		I18nConfig.pushTranslations(apcs);

		System.out.println("Done");
	}

	/**
	 * Retrieves the content service.
	 *
	 * @return The content service.
	 */
	protected static IContentService getContentService(IPair<String, char[]> credentialsFromCommandLine, String remoteContentServiceUrlFromCommandLine) {
		final IPair<String, char[]> credentials = credentialsFromCommandLine == null ? getUsernamePassword() : credentialsFromCommandLine;
		final String username = credentials.getLeft();
		// WARNING: not secure, here password is kept in memory for all the life
		// of the program.
		final String password = String.valueOf(credentials.getRight());

		final ABasicAuthenticator contentServerAuthenticator = new UserAuthenticator(username, password);

		final String remoteContentServiceUrl = remoteContentServiceUrlFromCommandLine == null ? getRemoteContentServiceUrl() : remoteContentServiceUrlFromCommandLine;

		return new RemoteContentService(
				remoteContentServiceUrl,
				contentServerAuthenticator,
				contentServerAuthenticator);
	}

	/**
	 * Retrieve a CLI parameter from the command line arguments.
	 * @param args all the command line arguments.
	 * @param argName the name of the argument to retrieve, will be considered as a long-form argument and prefixed by '--'.
	 * @return the argument value or null if none was found.
	 */
	protected static String getArgument(String[] args, String argName) {
		int index = QfsArrays.indexOf(args, "--" + argName);
		if (index != -1 && args.length > index + 1) {
			return args[index + 1];
		}
		return null;
	}

	protected static String getRemoteContentServiceUrlFromCommandLineArguments(String[] args) {
		return getArgument(args, "url");
	}

	/**
	 * Retrieve a username/password pair from the command line argument if both "--username" and "--password"
	 * arguments are provided and are each followed by another argument.
	 *
	 * @param args the main program arguments.
	 * @return the credentials pair or null if the command line arguments did not contain all the required information.
	 */
	protected static IPair<String, char[]> getCredentialsFromCommandLineArguments(String[] args) {
		String userName = getArgument(args, "username");
		String password = getArgument(args, "password");
		if (userName != null && password != null) {
			return new Pair<>(userName, password.toCharArray());
		}
		return null;
	}

	/**
	 * Retrieve a username/password pair from, either the shell if
	 * available, or a swing UI.
	 *
	 * @return The username/password pair.
	 */
	protected static IPair<String, char[]> getUsernamePassword() {
		final IPair<String, char[]> result = new Pair<>();
		if (System.console() != null) {
			final Console console = System.console();
			System.out.println("Please enter the credentials");
			result.setLeft(console.readLine("username: "));
			result.setRight(console.readPassword("password: "));
			System.out.println();
		} else {
			// No console: use swing
			System.out.println("Please enter the credentials in the pop-up");

			final CountDownLatch latch = new CountDownLatch(1);
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {
					final JFrame frame = new JFrame("Content Server Credentials");
					frame.setMinimumSize(new Dimension(350, 0));
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setResizable(false);
					frame.setAutoRequestFocus(true);

					frame.addWindowListener(new WindowAdapter() {
						@Override
						public void windowClosing(WindowEvent e) {
							System.out.println("Nothing was pushed");
						}
					});

					final JPanel mainPanel = new JPanel();
					frame.add(mainPanel);
					mainPanel.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
					mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

					final JTextField username = new JTextField();
					final JPasswordField password = new JPasswordField();

					final int hGap = 10;
					final int vGap = 5;
					final JPanel uPane = new JPanel();
					uPane.setLayout(new BoxLayout(uPane, BoxLayout.X_AXIS));
					uPane.add(new JLabel("Username"));
					uPane.add(Box.createHorizontalStrut(hGap));
					uPane.add(username);

					final JPanel pPane = new JPanel();
					pPane.setLayout(new BoxLayout(pPane, BoxLayout.X_AXIS));
					pPane.add(new JLabel("Password"));
					pPane.add(Box.createHorizontalStrut(hGap));
					pPane.add(password);

					mainPanel.add(uPane);
					mainPanel.add(Box.createVerticalStrut(vGap));
					mainPanel.add(pPane);
					mainPanel.add(Box.createVerticalStrut(vGap));

					final JButton button = new JButton("OK");
					mainPanel.add(button);
					final ActionListener listener = new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (username.getText() == null || username.getText().isEmpty()) {
								JOptionPane.showMessageDialog(frame, "Please enter a username",
										null, JOptionPane.ERROR_MESSAGE);
								return;
							}

							result.setLeft(username.getText());
							result.setRight(password.getPassword());
							frame.setVisible(false);
							latch.countDown();
							frame.dispose();
						}
					};

					button.addActionListener(listener);
					// To catch Enter press
					password.addActionListener(listener);
					// To catch Enter press
					username.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							password.requestFocus();
						}
					});

					frame.pack();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				}
			});

			try {
				// Wait for the user
				latch.await();
			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			}
		}

		return result;
	}

	static class AdminFacade implements ISecurityFacade {
		@Override
		public ISecurityDetails snapshotSecurityDetails() throws QuartetSecurityException {
			// Only root should be able edit what will be pushed in the content service
			return new SecurityDetails(PushToContentServer.class.getSimpleName(),
					Collections.singleton(IContentService.ROLE_ROOT));
		}

		@Override
		public void setSecurityDetails(ISecurityDetails securityDetails)
				throws QuartetSecurityException {
			throw new UnsupportedOperationException();
		}

		@Override
		public void clearSecurityDetails() {
		}
	}

}
