/*
 * (C) Quartet FS 2013-2015 ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY property of Quartet
 * Financial Systems Limited. Any unauthorized use, reproduction or transfer of this material is strictly prohibited
 * package com.qfs.sandbox.server;
 */
package com.qfs.sandbox.server;

import com.quartetfs.biz.pivot.impl.ActivePivotManager;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.springframework.context.ApplicationContext;
import org.springframework.util.Assert;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import java.io.IOException;
import java.util.EventListener;

/**
 * @author QuartetFS
 */
public abstract class ATestActivePivotServer {

	/** The Servlet Context to retrieve beans during the test */
	protected ServletContextHandler context;

	protected static final int PORT = 9096;

	/**
	 * Tests that the server can start and run, with CSV loading enabled.
	 */
	protected void doTestServerWithCSV() throws Exception {
		System.setProperty("csvSource.enabled", "true");
		SandboxActivePivotTestUtils.loadSqlDrivers();

		Server server = createPivotServer(PORT);
		context = new ServletContextHandler(server, "/", ServletContextHandler.SESSIONS);
		configure();
		try {
			context.getServer().start();

			// If the data source bean is null or APmanager is null, then most likely an error occurred
			// during source initialization
			ActivePivotManager manager = (ActivePivotManager) context.getServletContext().getAttribute(
					"activePivotManager");

			Assert.notNull(manager, "activePivotManager is null");

		} finally {
			context.stop();
			server.stop();
		}
	}

	protected abstract Server createPivotServer(int port);

	protected void addInitParameters(ServletContextHandler context) {}

	protected ServletContextHandler configure() throws IOException {
		String configResource = getPivotServerClassName();
		context.setInitParameter(ContextLoader.CONTEXT_CLASS_PARAM, AnnotationConfigWebApplicationContext.class.getName());
		context.setInitParameter(ContextLoader.CONFIG_LOCATION_PARAM, configResource);
		addInitParameters(context);
		context.setClassLoader(Thread.currentThread().getContextClassLoader());

		// Set-up event listeners
		context.setEventListeners(new EventListener[] { new ContextLoaderListener() });

		return context;
	}

	protected abstract String getPivotServerClassName();

	protected ApplicationContext getApplicationContext() {
		if (context == null) {
			return null;
		}

		ServletContext servletContext = context.getServletHandler().getServletContext();
		return WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
	}

}
