/*
 * (C) Quartet FS 2014-2015
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.multiversion.impl;

import static org.junit.Assert.assertEquals;

import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import com.qfs.multiversion.IMultiVersion;
import com.qfs.multiversion.IVersionHistory;
import com.qfs.multiversion.IVersionProcedure;
import com.qfs.multiversion.impl.ATestVersionHistory.DummyVersion;

public class TestCustomEpochPolicy {

	IVersionHistory<DummyVersion> history;
	CustomEpochPolicy policy;

	@Test
	public void testA() {
		this.policy = new CustomEpochPolicy(10, 10, 31, Long.MAX_VALUE);
		this.history = new VersionHistory<TestVersionHistory.DummyVersion>(
				Mockito.mock(IMultiVersion.class),
				this.policy,
				null,
				null,
				null,
				null);

		for (int i = 0; i <= 5; i++) {
			commit(i, i);
		}

		Assert.assertThat(TestVersionHistory.getNotReleasedEpochs(history), Matchers.containsInAnyOrder(5L, 4L, 3L, 2L, 1L, 0L));

		for (int i = 6; i <= 100; i++) {
			commit(i, i);
		}
		//		print();
		Assert.assertThat(TestVersionHistory.getNotReleasedEpochs(history), Matchers.containsInAnyOrder(100L, 99L, 98L, 97L, 96L, 95L, 94L, 93L, 92L, 91L, 90L, 80L, 70L));
	}

	@Test
	public void testB() {
		this.policy = new CustomEpochPolicy(3, 5, 16, Long.MAX_VALUE);
		this.history = new VersionHistory<TestVersionHistory.DummyVersion>(
				Mockito.mock(IMultiVersion.class),
				this.policy,
				null,
				null,
				null,
				null);

		for (int i = 0; i <= 7; i++) {
			commit(i, i);
		}

		//		print();
		Assert.assertThat(TestVersionHistory.getNotReleasedEpochs(history), Matchers.containsInAnyOrder(7L, 6L, 5L, 0L));

		for (int i = 8; i <= 16; i++) {
			commit(i, i);
			//			print();
		}

		//		print();
		Assert.assertThat(TestVersionHistory.getNotReleasedEpochs(history), Matchers.containsInAnyOrder(16L, 15L, 14L, 10L, 5L));
	}

	@Test
	public void testC() {
		this.policy = new CustomEpochPolicy(3, 5, 16, Long.MAX_VALUE);
		this.history = new VersionHistory<TestVersionHistory.DummyVersion>(
				Mockito.mock(IMultiVersion.class),
				this.policy,
				null,
				null,
				null,
				null);

		for (int i = 0; i <= 7; i++) {
			commit(i, 2 * i);
		}

		//print();
		Assert.assertThat(TestVersionHistory.getNotReleasedEpochs(history), Matchers.containsInAnyOrder(7L, 6L, 3L, 0L));

		for (int i = 8; i <= 16; i++) {
			commit(i, 2 * i);
		}

		//print();
		Assert.assertThat(TestVersionHistory.getNotReleasedEpochs(history), Matchers.containsInAnyOrder(16L, 15L, 12L, 9L));
	}

	@Test
	public void testD() {
		this.policy = new CustomEpochPolicy(3, 10, 21, Long.MAX_VALUE);
		this.history = new VersionHistory<TestVersionHistory.DummyVersion>(
				Mockito.mock(IMultiVersion.class),
				this.policy,
				null,
				null,
				null,
				null);
		for (int i = 0; i < 12; i++) {
			commit(i, i);
		}
		commit(12, 20);
		Assert.assertThat(TestVersionHistory.getNotReleasedEpochs(history), Matchers.containsInAnyOrder(12L, 10L, 0L));
	}

	/**
	 * Test that the force discard works indeed.
	 */
	@Test
	public void testForceDiscard() {
		this.policy = new CustomEpochPolicy(3, 10, 21, -1);
		this.history = new VersionHistory<TestVersionHistory.DummyVersion>(
				Mockito.mock(IMultiVersion.class),
				this.policy,
				null,
				null,
				null,
				null);
		DummyVersion[] dummyVersions = new DummyVersion[13];
		for (int i = 0; i < 12; i++) {
			dummyVersions[i] = commit(i, i);
		}
		dummyVersions[12] = commit(12, 20);
		Assert.assertThat(TestVersionHistory.getNotReleasedEpochs(history), Matchers.containsInAnyOrder(12L, 10L, 0L));
		for (int i = 0; i < 13; i++) {
			assertEquals("i=" + i, i == 12l || i == 10 || i == 0, !dummyVersions[i].hasBeenDestroyed);
		}

	}

	protected DummyVersion commit(long epochId, long time) {
		DummyVersion v = new DummyVersion(new Epoch(epochId, time));
		history.record(v);
		policy.execute(time, v.getEpoch(), history);
		return v;
	}

	protected void print() {
		history.forEachVersion(new IVersionProcedure<DummyVersion>() {

			@Override
			public boolean execute(DummyVersion version) {
				System.out.println("Epoch: " + version.getEpochId() + " - Time: " + version.getEpoch().getTimestamp());
				return true;
			}
		});
	}
}
