/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.webservices;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * Prints the content of a cell set.
 *
 * @author Quartet FS
 *
 */
public class CellSetPrinter {

	protected final CellSet cellSet;

	protected final Axis slicer;

	protected final List<Axis> axes;

	protected final List<Cell> cells;

	public CellSetPrinter(CellSet cellSet) {
		this.cellSet = cellSet;
		this.axes = cellSet.getAxes().getAxis();
		this.slicer = cellSet.getSlicerAxis();
		this.cells = cellSet.getCells().getCell();
	}

	/**
	 * Compute axis positions from the cell ordinal with the classic formula:
	 * <ul>
	 * <li>(x0, x1, x2) -> x0 + x1 * n0 + x2 * n1 * n2
	 * <li>ordinal -> (ordinal % n0, (ordinal / n0) % n1, (ordinal / (n0*n1)) % n2)
	 * </ul>
	 *
	 * @param ordinal
	 * @return tuple expressed by coordinates
	 */
	protected List<String> getTuple(int ordinal) {
		List<String> tuple = new ArrayList<>();

		// Lookup positions on axes
		final int[] axisCoordinates = new int[axes.size()];

		int coeff = 1;
		for(int a = 0; a < axisCoordinates.length; a++) {
			int positionCount = axes.get(a).getPositions().getPosition().size();
			axisCoordinates[a] = (ordinal / coeff) % positionCount;
			coeff *= positionCount;
		}

		for(int a = 0; a < axisCoordinates.length; a++) {
			AxisPosition position = axes.get(a).getPositions().getPosition().get(axisCoordinates[a]);
			for(Member member : position.getMembers().getMember()) {
				for (String pathElement : member.getPath().getItems().getItem()) {
					if (!"AllMember".equals(pathElement)) {
						tuple.add(pathElement);
					}
				}
			}
		}

		// Append slicer content
		for (AxisPosition position : slicer.getPositions().getPosition()) {
			for (Member member : position.getMembers().getMember()) {
				for(String pathElement : member.getPath().getItems().getItem()) {
					if(!"AllMember".equals(pathElement)) {
						tuple.add(pathElement);
					}
				}
			}
		}

		return tuple;
	}

	/**
	 * Computes the list of all member properties for each member and returns a
	 * for each member a serialized version of it as follow:
	 *
	 * <pre>
	 * Properties of MemberName : {property1:value1, property2:value2, ... , propertyN:valueN}
	 * </pre>
	 *
	 * @return A List of string representing the member properties for each
	 *         available member.
	 */
	protected List<String> getMemberProperties() {
		List<String> memberProperties = new ArrayList<>();
		for (int a = 0; a < axes.size(); a++) {
			for (AxisPosition position : axes.get(a).getPositions().getPosition())
				for (Member member : position.getMembers().getMember()) {
					StringBuilder builder = new StringBuilder();
					MapEntryList props = member.getProperties();
					if (props != null) {
						builder.append("Properties of " + member.getCaption() + " : {");
						int i = 0;
						for (MapEntry entry : props.getEntry()) {
							builder.append(entry.getKey().toString());
							builder.append(":");
							builder.append(entry.getValue().toString());
							if (i != props.getEntry().size() - 1)
								builder.append(", ");
							++i;
						}
						builder.append("}");
						memberProperties.add(builder.toString());
					}
				}
		}

		return memberProperties;
	}

	public void print(PrintStream out) {
		for (Cell cell : cells) {
			out.println(getTuple(cell.getOrdinal()) + " " + cell.getFormattedValue());
		}

		for (String memberProperties : getMemberProperties()) {
			out.println(memberProperties);
		}

	}

}
