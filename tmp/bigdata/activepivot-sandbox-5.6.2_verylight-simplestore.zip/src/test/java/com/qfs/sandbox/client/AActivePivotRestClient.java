/*
 * (C) Quartet FS 2016
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.client;

import static com.qfs.pivot.rest.query.IQueriesRestService.MDX_PATH;
import static com.qfs.server.cfg.impl.ActivePivotRestServicesConfig.CUBE_DISCOVERY_SUFFIX;
import static com.qfs.server.cfg.impl.ActivePivotRestServicesConfig.CUBE_QUERIES_SUFFIX;
import static com.qfs.server.cfg.impl.ActivePivotRestServicesConfig.REST_API_URL_PREFIX;

import java.io.IOException;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;

import com.qfs.QfsWebUtils;
import com.qfs.jackson.impl.JacksonSerializer;
import com.qfs.pivot.json.cellset.JsonCellSetData;
import com.qfs.pivot.json.discovery.CatalogDiscovery;
import com.qfs.pivot.json.discovery.CubeDiscovery;
import com.qfs.pivot.json.discovery.DimensionDiscovery;
import com.qfs.pivot.json.discovery.HierarchyDiscovery;
import com.qfs.pivot.json.discovery.JsonDiscovery;
import com.qfs.pivot.json.query.JsonMdxQuery;
import com.qfs.rest.client.impl.ClientPool;
import com.qfs.rest.client.impl.UserAuthenticator;
import com.qfs.rest.services.IRestService;
import com.qfs.rest.services.impl.JsonRestService;
import com.quartetfs.fwk.serialization.SerializerException;

/**
 *
 * Rest client that connects to the ActivePivot REST services and exchange request and responses in
 * JSon.
 *
 * @author Quartet FS
 *
 */
public class AActivePivotRestClient {

	static final Logger LOGGER = Logger.getLogger(AActivePivotRestClient.class.getName());

	static final Level LOG_LEVEL = Level.FINE;

	/** User name */
	static final String USER = "admin";

	/** User password */
	static final String PASSWORD = "admin";

	/** The rest service to run the queries. */
	protected final IRestService restService;

	/** Base url for Spring HTTP Remoting Services */
	protected final String baseUrl;

	/**
	 * Full constructor.
	 * @param port server port
	 */
	public AActivePivotRestClient(final int port) {
		baseUrl = "http://localhost:" + port;
		restService = new JsonRestService(baseUrl, new ClientPool(1, new UserAuthenticator(USER, PASSWORD)));
	}

	public JsonDiscovery discover() throws SerializerException, IOException {
		return restService.path(QfsWebUtils.url(baseUrl, REST_API_URL_PREFIX, CUBE_DISCOVERY_SUFFIX))
				.get()
				.as(JsonDiscovery.class);
	}

	public JsonCellSetData executeMDX(String mdx) throws IOException, SerializerException {
		final JsonMdxQuery mdxQuery = new JsonMdxQuery(mdx, Collections.<String, String> emptyMap());
		final String json = JacksonSerializer.serialize(mdxQuery);
		if (LOGGER.isLoggable(LOG_LEVEL)) {
			LOGGER.log(LOG_LEVEL, "Query Json: " + System.lineSeparator() + json);
		}

		return restService.path(QfsWebUtils.url(baseUrl, REST_API_URL_PREFIX, CUBE_QUERIES_SUFFIX, MDX_PATH))
				.post(Entity.entity(json, MediaType.APPLICATION_JSON_TYPE))
				.as(JsonCellSetData.class);
	}

	/**
	 * A test run of the test client, that make sure that rest request can be made.
	 *
	 * @throws Exception If the run failed.
	 */
	public void run() throws Exception {
		// Discover the cubes
		final JsonDiscovery discovery = discover();
		for (final CatalogDiscovery catalog : discovery.getCatalogs()) {
			System.out.println(catalog);

			for (final CubeDiscovery cube : catalog.getCubes()) {
				System.out.println(cube);

				for (final DimensionDiscovery dim : cube.getDimensions()) {
					System.out.println("   " + dim);

					for (final HierarchyDiscovery hier : dim.getHierarchies()) {
						System.out.println("      " + hier);
					}
				}
			}
		}

		// Run an MDX query
		final String mdx = "SELECT NON EMPTY {[Booking].[Desk].Members} ON ROWS, {[HistoricalDates].[AsOfDate].Members} ON COLUMNS FROM [EquityDerivativesCube] WHERE ([Measures].[pnl.SUM])";
		final JsonCellSetData result = executeMDX(mdx);

		System.out.println(result);
	}

}
