/*
 * (C) Quartet FS 2016
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.server;

import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.qfs.util.impl.QfsProperties;

/**
 * @author Quartet FS
 *
 */
public class SandboxActivePivotTestUtils {
	/**
	 * Loads the drivers required for SQL services.
	 * <p>
	 * This may be required since the drivers are cleaned automatically when the server stops.<br>
	 * If the server is supposed to restart in the same VM, drivers may not be reloaded.
	 * </p>
	 *
	 * @throws ClassNotFoundException if one of the drivers cannot be found
	 * @throws IllegalAccessException if not possible to create one of the drivers
	 * @throws InstantiationException if not possible to create one of the drivers
	 * @throws SQLException if the driver registration fails
	 */
	public static void loadSqlDrivers()
			throws ClassNotFoundException, IllegalAccessException, InstantiationException, SQLException {
		final Properties contentServerProps = QfsProperties.loadProperties("hibernate.properties");
		final Class<?> csDriver = Class.forName(contentServerProps.getProperty("driverClassName"));
		DriverManager.registerDriver((Driver) csDriver.newInstance());
	}
}
