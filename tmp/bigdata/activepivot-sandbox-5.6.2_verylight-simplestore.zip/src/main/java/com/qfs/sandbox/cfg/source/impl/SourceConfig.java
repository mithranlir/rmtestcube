/*
 * (C) Quartet FS 2013-2015
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.cfg.source.impl;

import com.qfs.dic.IWritableDictionary;
import com.qfs.dic.impl.ChristmasDictionary;
import com.qfs.msg.csv.*;
import com.qfs.msg.csv.filesystem.impl.FileSystemCSVTopicFactory;
import com.qfs.msg.csv.impl.CSVSource;
import com.qfs.msg.csv.impl.FileSystemCSVMonitoring;
import com.qfs.sandbox.cfg.datastore.impl.DatastoreDescriptionConfig;
import com.qfs.server.cfg.IDatastoreConfig;
import com.qfs.source.impl.CSVMessageChannelFactory;
import com.qfs.source.impl.Fetch;
import com.qfs.store.IDatastore;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.log.impl.LogWriteException;
import com.qfs.store.record.IWritableByteRecordBlock;
import com.qfs.store.record.impl.Records;
import com.qfs.store.transaction.DatastoreTransactionException;
import com.qfs.store.transaction.ITransactionManager;
import com.qfs.util.impl.QfsFiles;
import com.quartetfs.fwk.QuartetRuntimeException;
import com.quartetfs.fwk.monitoring.jmx.impl.JMXEnabler;
import org.apache.avro.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import qfs.msg.parquet.IParquetMappingProvider;
import qfs.msg.parquet.IPivotRecord;
import qfs.msg.parquet.IStoreToParquetMapping;
import qfs.msg.parquet.impl.ParquetConverterFactory;
import qfs.msg.parquet.impl.ParquetParser;
import qfs.msg.parquet.impl.StoreToParquetMapping;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.qfs.sandbox.cfg.datastore.impl.DatastoreDescriptionConfig.RISK_STORE_NAME;

/**
 *
 * Spring configuration of the Sandbox ActivePivot server.<br>
 * The parameters of the Sandbox ActivePivot server can be quickly changed by modifying the
 * pojo.properties file.
 *
 * @author Quartet FS
 *
 */
@PropertySource(value = "classpath:data.properties")
@Configuration
public class SourceConfig {

	protected static Logger LOGGER = Logger.getLogger(SourceConfig.class.getName());

	@Autowired
	protected Environment env;

	@Autowired
	protected IDatastoreConfig datastoreConfig;

	public static final char CSV_SEPARATOR = ';';

	public static final String RISKS_TOPIC = RISK_STORE_NAME;

	public static final String RISK_STORE_FILE = "risk.csv";

	@Bean
	public CSVMessageChannelFactory<Path> csvChannelFactory() {
		final CSVMessageChannelFactory<Path> csvChannelFactory = new CSVMessageChannelFactory<>(
				csvSource(),
				datastoreConfig.datastore());
		return csvChannelFactory;
	}

	@Bean
	public ICSVSource<Path> csvSource() {

		final FileSystemCSVTopicFactory factory = new FileSystemCSVTopicFactory(false);

		final CSVSource<Path> source = new CSVSource<>();

		final String dataSet = env.getProperty("csvSource.dataset");
		try {
			final File file = new File(QfsFiles.getResourceUrl(dataSet).toURI());
			if (!file.exists() && !file.isDirectory()) {
				LOGGER.severe("The csvSource.dataset does not point to a valid directory: " + file.getAbsolutePath());
				throw new QuartetRuntimeException(
						"The csvSource.dataset does not point to a valid directory: " + file.getAbsolutePath());
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "The csvSource.dataset does not point to a valid directory: " + dataSet, e);
			throw new QuartetRuntimeException(
					"The csvSource.dataset does not point to a valid directory: " + dataSet,
					e);
		}

		final IDatastoreSchemaMetadata schemaMetadata = datastoreConfig.datastore().getSchemaMetadata();

		final String filePath = dataSet + System.getProperty("file.separator");
		// Create the CSV topics.
		final List<String> riskColumns = schemaMetadata.getFields(RISKS_TOPIC);


		// TradeId;AsOfDate;HostName;delta;pnlDelta;gamma;vega;pnlVega;pnl

		final ICSVTopic<Path> risks = factory.createTopic(RISKS_TOPIC, filePath + RISK_STORE_FILE, source.createParserConfiguration(riskColumns));
		risks.getParserConfiguration().setSeparator(CSV_SEPARATOR);
		source.addTopic(risks);


		final Properties sourceProps = new Properties();
		final String parserThreads = env.getProperty("csvSource.parserThreads", "4");
		sourceProps.setProperty(ICSVSourceConfiguration.PARSER_THREAD_PROPERTY, parserThreads);

		final String bufferSize = env.getProperty("csvSource.bufferSize");
		if (null != bufferSize) {
			sourceProps.setProperty(ICSVSourceConfiguration.BUFFER_SIZE_PROPERTY, bufferSize);
		}

		source.configure(sourceProps);

		return source;
	}

	@Bean
	@DependsOn({ "startManager" })
	public Void csvInitialLoad() throws LogWriteException {

		// CSV loading is disabled by default.
		// final boolean doCsvLoad = Boolean.parseBoolean(env.getProperty("csvSource.enabled", "false"));
		final boolean doCsvLoad = false;
		final boolean doParquetLoad = true;

		if (doCsvLoad) {
			final Fetch<IFileInfo<Path>, ILineReader> initialLoad = new Fetch<IFileInfo<Path>, ILineReader>(csvChannelFactory(),  Arrays.asList(RISK_STORE_NAME));

			final long before = System.currentTimeMillis();
			initialLoad.fetch(csvSource());
			final long elapsed = System.currentTimeMillis() - before;


			LOGGER.info("CSV data load completed in " + elapsed + "ms.");
		}

		if(doParquetLoad) {
			loadForexFromParquetFile();
		}

		return null;
	}

	private void loadForexFromParquetFile() {
		final ITransactionManager transactionManager = datastoreConfig.datastore().getTransactionManager();

		try {
			try {
				transactionManager.startTransaction();
			} catch (DatastoreTransactionException e) {
				throw new RuntimeException(e);
			}

			final String dirPath = "D:\\dev\\active pivot\\server\\activepivot-sandbox-5.6.2_verylight-simplestore\\src\\main\\resources\\data\\risk.parquet";

			final Stream<Path> list = Files.list(Paths.get(dirPath));
			final List<Path> collect = list.filter(path2 -> path2.getFileName().toString().endsWith(".parquet")).collect(Collectors.toList());
			String filePath;
			if(collect.size()>0) {
				filePath = collect.get(0).toAbsolutePath().toString();
			}
			else {
				throw new RuntimeException("parquet file not found in " + dirPath);
			}


			final boolean autocomplete = true;
			final StoreToParquetMapping storeToParquetMapping = new StoreToParquetMapping(
					RISK_STORE_NAME, new HashMap<>(), autocomplete);


			Map<String, FieldCalculator> calculatedFieldsMap = new HashMap<>();
			calculatedFieldsMap.put("TOTO", new TotoFieldCalculator());

			final ParquetParser parquetParser = new ParquetParser(datastoreConfig.datastore()) {

				private Map<Integer, String> calculatedFieldPosMap = new HashMap<>();

				protected void read(IWritableByteRecordBlock block, IPivotRecord pivotRecord, int recordIdx, IParquetMappingProvider mappingProvider, int recordFieldIndex) {
					Object value = pivotRecord.get(mappingProvider.getParquetFieldIndex(recordFieldIndex));
					// fix
					if(value instanceof String) {
						writeValue(block, pivotRecord, recordIdx, mappingProvider, recordFieldIndex, value);
					}
					else {
						super.read(block, pivotRecord, recordIdx, mappingProvider, recordFieldIndex);
					}
				}


				protected void writeValue(IWritableByteRecordBlock block, IPivotRecord pivotRecord, int recordIdx, IParquetMappingProvider mappingProvider, int recordFieldIndex, Object value) {
					if (mappingProvider.getDictionnary(recordFieldIndex) == null) {
						block.write(recordIdx, recordFieldIndex, value);
					} else {
						final IWritableDictionary<String> dictionnary = (IWritableDictionary<String>) mappingProvider.getDictionnary(recordFieldIndex);
						block.writeInt(recordIdx, recordFieldIndex, dictionnary.map((String) value));
					}
				}

				protected ParquetConverterFactory createParquetConverterFactory(IDatastore datastore, IStoreToParquetMapping topic) {
					return new ParquetConverterFactory(datastore, topic) {

						public void initialize(Schema schema) throws QuartetRuntimeException {

							List storeFields = this.schemaMetadata.getFields(this.storeToParquetMapping.getStoreName());
							Records.IDictionaryProvider dictionaries = this.dictionaryProvider.getStoreDictionaries(this.getStoreId());
							this.reverseIndexMapping = new int[schema.getFields().size()];
							Arrays.fill(this.reverseIndexMapping, -1);
							int storeFieldIndex = 0;

							for(int size = storeFields.size(); storeFieldIndex < size; ++storeFieldIndex) {
								String storeFieldName = (String)storeFields.get(storeFieldIndex);
								String parquetFieldName = this.storeToParquetMapping.getParquetFieldName(storeFieldName, schema);
								if(parquetFieldName == null
										&& this.isKeyField(storeFieldIndex)
										&& !calculatedFieldsMap.keySet().contains(storeFieldName)) {
									throw new QuartetRuntimeException("Wrong mapping: key field " + (String)storeFields.get(storeFieldIndex) + " cannot be found in map\nList of store fields " + storeFields.toString() + "\nList of map fields " + this.storeToParquetMapping.toString());
								}

								if(calculatedFieldsMap.keySet().contains(storeFieldName)) {
									calculatedFieldPosMap.put(storeFieldIndex, storeFieldName);
								}

								if(parquetFieldName == null) {
									if(calculatedFieldsMap.keySet().contains(storeFieldName)) {
										this.dicMapping[storeFieldIndex] = (IWritableDictionary)dictionaries.getDictionary(storeFieldIndex);
									}
									else {
										this.indexMapping[storeFieldIndex] = -1;
										this.typeMapping[storeFieldIndex] = null;
										this.dicMapping[storeFieldIndex] = null;
									}
								} else {
									this.createMapping(storeFieldIndex, schema, parquetFieldName);
									this.dicMapping[storeFieldIndex] = (IWritableDictionary)dictionaries.getDictionary(storeFieldIndex);
								}
							}

							this.isInitialized = true;
						}
					};
				}


				protected void writeRecordToBlocks(IWritableByteRecordBlock[] blocks, IPivotRecord pivotRecord, int recordIdx, IParquetMappingProvider[] mappingProviders) {

					int numberOfFields = mappingProviders[0].getNumberOfFields();

					for(int j = 0, length = blocks.length; j < length; ++j) {
						final IWritableByteRecordBlock block = blocks[j];
						block.writeStarted(recordIdx);
					}

					// read field
					for(int recordFieldIndex = 0; recordFieldIndex < numberOfFields; ++recordFieldIndex) {
						if(!calculatedFieldPosMap.containsKey(recordFieldIndex)) {
							for(int j = 0, length = blocks.length; j < length; ++j) {
								final IWritableByteRecordBlock block = blocks[j];
								final IParquetMappingProvider mappingProvider = mappingProviders[j];
								super.readRecord(block, pivotRecord, recordIdx, mappingProvider, recordFieldIndex);
							}
						}
					}

					// compute calculated fields now...
					for(int recordFieldIndex : calculatedFieldPosMap.keySet()) {
						for (int j = 0, length = blocks.length; j < length; ++j) {
							final IWritableByteRecordBlock block = blocks[j];
							final IParquetMappingProvider mappingProvider = mappingProviders[j];

							final String calculatedFieldName = calculatedFieldPosMap.get(recordFieldIndex);
							final FieldCalculator fieldCalculator = calculatedFieldsMap.get(calculatedFieldName);
							final String calculatedValue = fieldCalculator.calculateField(recordIdx, block, mappingProvider);

							writeValue(block, pivotRecord, recordIdx, mappingProvider, recordFieldIndex, calculatedValue);
						}
					}

					for(int j = 0, length = blocks.length; j < length; ++j) {
						final IWritableByteRecordBlock block = blocks[j];
						block.writeComplete(recordIdx);
					}
				}

			};
			parquetParser.parse(new org.apache.hadoop.fs.Path(filePath), new IStoreToParquetMapping[]{storeToParquetMapping});

			transactionManager.commitTransaction();

		}
		catch (IOException | DatastoreTransactionException e) {
			try {
				transactionManager.rollbackTransaction();
			} catch (DatastoreTransactionException e1) {
				e1.printStackTrace();
			}
			throw new RuntimeException(e);
		}
	}

	public interface FieldCalculator {
		String calculateField(int recordIdx, IWritableByteRecordBlock block, IParquetMappingProvider mappingProvider);
	}

	public class TotoFieldCalculator implements  FieldCalculator {
		public String calculateField(int recordIdx, IWritableByteRecordBlock block, IParquetMappingProvider mappingProvider) {
			final Object hostName = getValueFromBlock(recordIdx, block, mappingProvider, "HostName");
			final Object asOfDate = getValueFromBlock(recordIdx, block, mappingProvider, "AsOfDate");
			return hostName.toString() + "|" + asOfDate.toString();
		}
	}

	public static Object getValueFromBlock(int recordIdx, IWritableByteRecordBlock block, IParquetMappingProvider mappingProvider, String fieldName) {
		final int fieldId = mappingProvider.getRecordFormat().getFieldIndex(fieldName);
		return getValueFromBlock(recordIdx, block, mappingProvider, fieldId);
	}

	public static Object getValueFromBlock(int recordIdx, IWritableByteRecordBlock block, IParquetMappingProvider mappingProvider, int fieldId) {
		Object hostName;
		if(mappingProvider.getDictionnary(fieldId)!=null) {
			final int refId = block.readInt(recordIdx, fieldId);
			hostName = mappingProvider.getDictionnary(fieldId).read(refId);
		}
		else {
			hostName = block.read(recordIdx, fieldId);
		}
		return hostName;
	}

	@Bean
	public JMXEnabler JMXCsvSourceEnabler() {
		return new JMXEnabler(new FileSystemCSVMonitoring(csvSource()));
	}


}
