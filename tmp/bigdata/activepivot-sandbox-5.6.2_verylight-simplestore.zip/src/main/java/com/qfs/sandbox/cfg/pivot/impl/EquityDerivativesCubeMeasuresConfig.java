package com.qfs.sandbox.cfg.pivot.impl;

import com.activeviam.desc.build.ICanStartBuildingMeasures;
import com.activeviam.desc.build.IHasAtLeastOneMeasure;

import static com.qfs.sandbox.cfg.datastore.impl.DatastoreDescriptionConfig.*;
import static com.qfs.sandbox.cfg.pivot.impl.EquityDerivativesCubeConfig.PNL_FOLDER;
import static com.qfs.sandbox.cfg.pivot.impl.EquityDerivativesCubeConfig.SENSITIVITIES_FOLDER;



public class EquityDerivativesCubeMeasuresConfig {

	/** The sum(pv) measure name. */
	public static final String PV_SUM = "pv.SUM";
	/** The sum(pnl) measure name. */
	public static final String PNL_SUM = "pnl.SUM";
	/** The sum(pnlDelta) measure name. */
	public static final String PNL_DELTA_SUM = "pnlDelta.SUM";

	/** The formatter for double measures with at most 2 digits after the decimal separator. */
	public static final String DOUBLE_FORMATTER = "DOUBLE[#,###.00;-#,###.00]";

	/** The int formatter. */
	public static final String INT_FORMATTER = "INT[#,###]";
	/** The date formatters for timestamps. */
	public static final String TIMESTAMP_FORMATTER = "DATE[HH:mm:ss]";

	public static IHasAtLeastOneMeasure measures(final ICanStartBuildingMeasures builder) {
		return builder
				.withContributorsCount()
					.withAlias("Count")
					.withFormatter(INT_FORMATTER)
				.withUpdateTimestamp()
					.withAlias("Timestamp")
					.withFormatter(TIMESTAMP_FORMATTER)
				.withMeasures(EquityDerivativesCubeMeasuresConfig::sensitivitiesMeasures)
				.withMeasures(EquityDerivativesCubeMeasuresConfig::pnlMeasures)
				;
	}

	protected static IHasAtLeastOneMeasure sensitivitiesMeasures(final ICanStartBuildingMeasures builder) {
		return builder
				.withAggregatedMeasure()
					.sum(RISK__DELTA)
					.withinFolder(SENSITIVITIES_FOLDER)
					.withFormatter(DOUBLE_FORMATTER)
				.withAggregatedMeasure()
					.sum(RISK__GAMMA)
					.withinFolder(SENSITIVITIES_FOLDER)
					.withFormatter(DOUBLE_FORMATTER)
				.withAggregatedMeasure()
					.sum(RISK__VEGA)
					.withinFolder(SENSITIVITIES_FOLDER)
					.withFormatter(DOUBLE_FORMATTER);
	}

	protected static IHasAtLeastOneMeasure pnlMeasures(final ICanStartBuildingMeasures builder) {
		return builder
				.withAggregatedMeasure()
					.sum(RISK__PNL)
					.withName(PNL_SUM)
					.withinFolder(PNL_FOLDER)
					.withFormatter(DOUBLE_FORMATTER)
				.withAggregatedMeasure()
					.sum(RISK__PNL_DELTA)
					.withName(PNL_DELTA_SUM)
					.withinFolder(PNL_FOLDER)
					.withFormatter(DOUBLE_FORMATTER)
				.withAggregatedMeasure()
					.sum(RISK__PNL_VEGA)
					.withinFolder(PNL_FOLDER)
					.withFormatter(DOUBLE_FORMATTER)
				;
	}
}
