/*
 * (C) Quartet FS 2017
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.cfg.pivot.impl;

import com.activeviam.builders.StartBuilding;
import com.activeviam.copper.HierarchyCoordinate;
import com.activeviam.desc.build.ICanBuildCubeDescription;
import com.activeviam.desc.build.ICubeDescriptionBuilder.INamedCubeDescriptionBuilder;
import com.quartetfs.biz.pivot.context.impl.QueriesTimeLimit;
import com.quartetfs.biz.pivot.cube.hierarchy.measures.IMeasureHierarchy;
import com.quartetfs.biz.pivot.definitions.IActivePivotInstanceDescription;

import static com.qfs.sandbox.cfg.pivot.impl.EquityDerivativesCubeDimensionsConfig.*;
import static com.qfs.sandbox.cfg.pivot.impl.EquityDerivativesCubeMeasuresConfig.PNL_DELTA_SUM;
import static com.qfs.sandbox.cfg.pivot.impl.EquityDerivativesCubeMeasuresConfig.PNL_SUM;

/**
 * Configuration for the "EquityDerivativesCube"
 * ActivePivot instance.
 *
 * @author ActiveViam
 */
public class EquityDerivativesCubeConfig {

	/** The name of the cube */
	public static final String CUBE_NAME = "EquityDerivativesCube";

	/* ******* */
	/* Folders */
	/* ******* */

	/** The folder for bucketed measures. */
	public static final String BUCKETING_FOLDER = "Bucketing";
	/** The folder for sensitivities related measures. */
	public static final String SENSITIVITIES_FOLDER = "Sensitivities";
	/** The folder for the PnL related measures. */
	public static final String PNL_FOLDER = "PnL";

	/**
	 * Creates the cube description.
	 *
	 * @param isActiveMonitorEnabled Whether ActiveMonitor is enabled or not.
	 * @return The created cube description
	 */
	public static IActivePivotInstanceDescription createCubeDescription(final boolean isActiveMonitorEnabled) {
		return configureCubeBuilder(StartBuilding.cube(CUBE_NAME), isActiveMonitorEnabled).build();
	}

	/**
	 * Configures the given builder in order to created the cube
	 * description.
	 *
	 * @param builder The builder to configure
	 * @param isActiveMonitorEnabled Whether ActiveMonitor is enabled or not.
	 * @return The configured builder
	 */
	public static ICanBuildCubeDescription<IActivePivotInstanceDescription> configureCubeBuilder(
			final INamedCubeDescriptionBuilder builder,
			final boolean isActiveMonitorEnabled)
	{
		return builder
				.withMeasures(EquityDerivativesCubeMeasuresConfig::measures)
				.withDimensions(EquityDerivativesCubeDimensionsConfig::dimensions)
				.withAggregateProvider()
					.jit()
					.withPartialProvider()
						.excludingHierarchies(new HierarchyCoordinate(TRADES_HIERARCHY))
						.includingOnlyMeasures(PNL_DELTA_SUM, PNL_SUM)
					.withPartialProvider()
						.excludingMeasures(PNL_DELTA_SUM, PNL_SUM)

				.withAggregatesCache()
					.withSize(1_000)
					.cachingOnlyMeasures(IMeasureHierarchy.COUNT_ID, PNL_SUM)

				// Shared context values
				// Query maximum execution time (before timeout cancellation): 30s
				.withSharedContextValue(new QueriesTimeLimit(30))
			;
	}
}
