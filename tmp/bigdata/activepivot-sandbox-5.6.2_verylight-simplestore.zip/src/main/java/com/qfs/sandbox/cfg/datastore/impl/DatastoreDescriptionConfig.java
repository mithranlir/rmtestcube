/*
 * (C) Quartet FS 2017
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.cfg.datastore.impl;

import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.desc.IReferenceDescription;
import com.qfs.desc.IStoreDescription;
import com.qfs.desc.IStoreDescriptionBuilder.ICanBuild;
import com.qfs.desc.impl.DatastoreSchemaDescription;
import com.qfs.desc.impl.StoreDescriptionBuilder;
import com.qfs.multiversion.IEpochManagementPolicy;
import com.qfs.multiversion.impl.CustomEpochPolicy;
import com.qfs.repository.IParameterStoreConfiguration;
import com.qfs.repository.config.impl.IParameterAwareDatastoreDescriptionConfig;
import com.qfs.repository.impl.RepositoryCacheUtil;
import com.quartetfs.fwk.format.impl.LocalDateParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.util.Collection;
import java.util.LinkedList;

import static com.qfs.literal.ILiteralType.DOUBLE;
import static com.qfs.literal.ILiteralType.LONG;
import static com.qfs.literal.ILiteralType.STRING;

/**
 * Spring configuration file that exposes the datastore
 * {@link IDatastoreSchemaDescription description}.
 *
 * @author ActiveViam
 */
@Configuration
public class DatastoreDescriptionConfig implements IParameterAwareDatastoreDescriptionConfig {

	/** Spring environment, automatically wired */
	@Autowired
	protected Environment env;

	/** Name of the risk store */
	public static final String RISK_STORE_NAME = "Risk";

	// ///////////////////////////////////////////////
	// Risk store fields

	public static final String RISK__TRADE_ID = "TradeId";
	public static final String RISK__AS_OF_DATE = "AsOfDate";
	public static final String RISK__HOST_NAME = "HostName";
	public static final String RISK__DELTA = "delta";
	public static final String RISK__PNL_DELTA = "pnlDelta";
	public static final String RISK__GAMMA = "gamma";
	public static final String RISK__VEGA = "vega";
	public static final String RISK__PNL_VEGA = "pnlVega";
	public static final String RISK__PNL = "pnl";

	/** @return the description of the risk store */
	public IStoreDescription riskStoreDescription() {
		ICanBuild sb = new StoreDescriptionBuilder()
				.withStoreName(RISK_STORE_NAME)
				.withField(RISK__TRADE_ID, LONG).asKeyField()
				//.withField(RISK__AS_OF_DATE, "localDate[" + LocalDateParser.DEFAULT_PATTERN + "]").asKeyField()
				.withField(RISK__AS_OF_DATE, STRING).asKeyField()
				.withField(RISK__HOST_NAME, STRING)
				.withField(RISK__DELTA, DOUBLE)
				.withField(RISK__PNL_DELTA, DOUBLE)
				.withField(RISK__GAMMA, DOUBLE)
				.withField(RISK__VEGA, DOUBLE)
				.withField(RISK__PNL_VEGA, DOUBLE)
				.withField(RISK__PNL, DOUBLE)
				.withField("TOTO", STRING).asKeyField()
				.withModuloPartitioning(RISK__TRADE_ID, tradeIdPartitioningModulo());

		if (valuePartitioningOnDate()) {
			sb = sb.withValuePartitioningOn(RISK__AS_OF_DATE);
		}
		return sb.build();
	}

	public Collection<IReferenceDescription> references() {
		final Collection<IReferenceDescription> references = new LinkedList<>();
		return references;
	}

	protected int tradeIdPartitioningModulo() {
		return env != null ? Integer.parseInt(env.getProperty("partitioning.TradeId", "8")) : 8;
	}

	protected boolean valuePartitioningOnDate() {
		return env != null ? Boolean.parseBoolean(env.getProperty("partitioning.AsOfDate", "true")) : true;
	}

	@Bean
	public IDatastoreSchemaDescription schemaDescription() {
		final Collection<IStoreDescription> stores = new LinkedList<>();
		stores.add(riskStoreDescription());
		return new DatastoreSchemaDescription(stores, references());
	}

	@Bean
	@Override
	public IParameterStoreConfiguration parameterStoreConfiguration() {
		return RepositoryCacheUtil.defaultParameterStoreConfiguration();
	}

	@Override
	public IEpochManagementPolicy epochManagementPolicy() {
		return new CustomEpochPolicy(5 * 60_000, 5 * 60_000, 30 * 60_000, 10 * 60_000);
	}


}
