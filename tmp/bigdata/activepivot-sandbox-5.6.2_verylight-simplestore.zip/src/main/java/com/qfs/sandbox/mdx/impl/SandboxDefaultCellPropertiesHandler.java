/*
 * (C) Quartet FS 2007-2016
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.mdx.impl;

import com.quartetfs.fwk.QuartetType;
import com.quartetfs.pivot.mdx.IDefaultCellPropertiesHandler;
import com.quartetfs.pivot.mdx.impl.DefaultCellPropertiesHandler;

/**
 * A customized cell properties handler that returns a red fore color when values are negative numbers.
 * This class is annotated with the {@link QuartetType} annotation,
 * which makes it the one that is picked by the registry.
 * If you want to create your own customized cell properties handler,
 * make sure that you remove this class or at least its {@link QuartetType} annotation
 * so that your own class annotated with {@link QuartetType} is taken into account
 * (your class must also be accessible via the ClassPathProvider for your customization to work).
 *
 * @author Quartet FS
 */
@QuartetType(description = "Sets the fore color of negative numeric value to red", intf = IDefaultCellPropertiesHandler.class)
public class SandboxDefaultCellPropertiesHandler extends DefaultCellPropertiesHandler {

	/**
	 * The fore color is red if the value is negative, unspecified otherwise
	 * (e.g. the GUI can choose its preferred color based on its theme).
	 */
	@Override
	protected Integer getForeColor(Object cellValue) {
		if (cellValue instanceof Number) {
			if (((Number) cellValue).doubleValue() < 0) {
				return 0x0000ff;
			}
		}
		return null;
	}
}
