/*
 * (C) Quartet FS 2017
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.cfg.pivot.impl;

import com.activeviam.builders.StartBuilding;
import com.qfs.desc.IDatastoreSchemaDescription;
import com.qfs.server.cfg.IActivePivotManagerConfig;
import com.quartetfs.biz.pivot.definitions.IActivePivotManagerDescription;
import com.quartetfs.biz.pivot.definitions.IActivePivotSchemaDescription;
import com.quartetfs.biz.pivot.definitions.ICatalogDescription;
import com.quartetfs.biz.pivot.definitions.ISelectionDescription;
import com.quartetfs.biz.pivot.impl.ActivePivotManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import static com.qfs.sandbox.cfg.datastore.impl.DatastoreDescriptionConfig.*;

@Configuration
public class EquityDerivativesManagerConfig implements IActivePivotManagerConfig {

	@Autowired
	protected Environment env;

	@Autowired
	protected IDatastoreSchemaDescription datastoreDescription;

	@Bean
	@Override
	public IActivePivotManagerDescription managerDescription() {
		return StartBuilding.managerDescription(MANAGER_NAME)
				.withCatalog(CATALOG_NAME)
					.containingAllCubes()
				.withSchema(SANDBOX_SCHEMA_NAME)
					.withSelection(createSandboxSchemaSelectionDescription(this.datastoreDescription))
						.withCube(EquityDerivativesCubeConfig.createCubeDescription(isActiveMonitorEnabled()))
				.build();
	}

	@Bean
	public boolean isActiveMonitorEnabled() {
		return  false;
	}

	/** The name of the {@link ActivePivotManager} */
	public static final String MANAGER_NAME = "EquityDerivativesManager";

	/** The name of the {@link ICatalogDescription}. */
	public static final String CATALOG_NAME = "Catalog";

	/** Name of the Sandbox {@link IActivePivotSchemaDescription schema} */
	public static final String SANDBOX_SCHEMA_NAME = "SandboxSchema";

	public static ISelectionDescription createSandboxSchemaSelectionDescription(
			final IDatastoreSchemaDescription datastoreDescription)
	{
		return StartBuilding.selection(datastoreDescription)
				.fromBaseStore(RISK_STORE_NAME)
				.withAllReachableFields()
			.build();
	}


}
