/*
 * (C) Quartet FS 2013-2017
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.cfg.content.impl;

import com.qfs.pivot.content.IActivePivotContentService;
import com.qfs.pivot.content.impl.ActivePivotContentServiceBuilder;
import com.qfs.sandbox.cfg.impl.ActiveUIResourceServerConfig;
import com.qfs.server.cfg.content.IActivePivotContentServiceConfig;
import com.qfs.server.cfg.i18n.impl.LocalI18nConfig;
import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.definitions.ICalculatedMemberDescription;
import com.quartetfs.biz.pivot.definitions.IKpiDescription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;

/**
 * Spring configuration of the <b>Content Service</b> backed by a local <b>Content Server</b>.
 *
 * <p> Since the content service is embedded in the current ActivePivot server when using
 * this configuration file, it also exposes the ActiveUI web application which is otherwise
 * exposed by the remote content server.
 *
 * @author Quartet FS
 */
@Import(value={
		LocalI18nConfig.class, // (I18n) Cube translation is set up from the file system
		ActiveUIResourceServerConfig.class, // (ActiveUI) Expose the ActiveUI web application
})
@Configuration
@Profile({EmbeddedContentServiceConfig.SPRING_PROFILE})
public class EmbeddedContentServiceConfig extends ContentServiceConfig implements IActivePivotContentServiceConfig {

	/** The name of the Spring profile that enables this configuration file */
	public static final String SPRING_PROFILE = "embedded-content";

	/**
	 * The Spring environment of the Content service
	 */
	@Autowired
	private Environment env;

	/**
	 * The name of the property which contains the role allowed to add new calculated members in the
	 * configuration service.
	 */
	public static final String CALCULATED_MEMBER_ROLE_PROPERTY = "contentServer.security.calculatedMemberRole";

	/**
	 * The name of the property which contains the role allowed to add new KPIs in the configuration
	 * service.
	 */
	public static final String KPI_ROLE_PROPERTY = "contentServer.security.kpiRole";

	/**
	 * Service used to store the ActivePivot descriptions and the entitlements (i.e.
	 * {@link IContextValue context values}, {@link ICalculatedMemberDescription calculated members}
	 * and {@link IKpiDescription KPIs}).
	 *
	 * @return the {@link IActivePivotContentService content service} used by the Sandbox
	 *         application
	 */

	@Bean
	@Override
	public IActivePivotContentService activePivotContentService() {
		return new ActivePivotContentServiceBuilder()
				.with(contentService())
				.withCacheForEntitlements(-1)

				// WARNING: In production, you should not keep the next lines, which will erase
				// parts of your remote configuration. Prefer pushing them manually using the
				// PushToContentServer utility class before starting the ActivePivot server.

				// Setup directories and permissions
				.needInitialization(
						env.getRequiredProperty(CALCULATED_MEMBER_ROLE_PROPERTY),
						env.getRequiredProperty(KPI_ROLE_PROPERTY))
				.build();
	}

}
