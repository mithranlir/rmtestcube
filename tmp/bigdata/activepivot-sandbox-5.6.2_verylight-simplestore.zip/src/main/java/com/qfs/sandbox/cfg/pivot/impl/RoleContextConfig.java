/*
 * (C) ActiveViam 2017
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */

package com.qfs.sandbox.cfg.pivot.impl;

import com.activeviam.builders.StartBuilding;
import com.qfs.sandbox.cfg.security.impl.ASecurityConfig;
import com.qfs.server.cfg.IRoleContextConfig;
import com.quartetfs.biz.pivot.security.IEntitlementsProvider;
import com.quartetfs.biz.pivot.security.builders.ICanHaveRoleEntitlements.ICanStartBuildingEntitlement;
import com.quartetfs.biz.pivot.security.builders.ICanHaveRoleEntitlements.IHasAtLeastOneEntitlement;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class RoleContextConfig implements IRoleContextConfig {

	protected static final String ROLE_ADMIN = ASecurityConfig.ROLE_ADMIN;

	protected static final String ROLE_DESK_A = "ROLE_DESK_A";

	protected static IHasAtLeastOneEntitlement roleAdmin(final ICanStartBuildingEntitlement builder) {
		return builder
				.withGlobalEntitlement()
						.forRole(ROLE_ADMIN)
						.withMdxContext()
								.withCubeFormatter("en-US")
								.end()
		;
	}

	protected static IHasAtLeastOneEntitlement roleDeskA(final ICanStartBuildingEntitlement builder) {
		return builder
				.withGlobalEntitlement()
						.forRole(ROLE_DESK_A)
						.withMdxContext()
								.withCubeFormatter("fr-FR")
								.end();
	}


	@Bean
	@Override
	public IEntitlementsProvider entitlementsProvider() {
		return StartBuilding.entitlementsProvider()
				.withEntitlements(RoleContextConfig::roleAdmin)
				.withEntitlements(RoleContextConfig::roleDeskA)
				.build();
	}
}
