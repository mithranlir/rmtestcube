/*
 * (C) Quartet FS 2017
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.cfg.pivot.impl;

import com.activeviam.desc.build.ICanBuildCubeDescription;
import com.activeviam.desc.build.dimensions.ICanStartBuildingDimensions;
import com.qfs.fwk.ordering.impl.ReverseEpochComparator;
import com.quartetfs.biz.pivot.cube.dimension.IDimension.DimensionType;
import com.quartetfs.biz.pivot.cube.hierarchy.ILevelInfo.LevelType;
import com.quartetfs.biz.pivot.definitions.IActivePivotInstanceDescription;
import com.quartetfs.fwk.ordering.impl.ReverseOrderComparator;

import static com.qfs.sandbox.cfg.datastore.impl.DatastoreDescriptionConfig.RISK__AS_OF_DATE;
import static com.qfs.sandbox.cfg.datastore.impl.DatastoreDescriptionConfig.RISK__TRADE_ID;

public class EquityDerivativesCubeDimensionsConfig {

	public static final String HOST_NAME_HIERARCHY = "HostName";
	public static final String TRADES_HIERARCHY = "Trades";
	public static final String TIME_DIMENSION = "Time";
	public static final String HISTORICAL_DATES_HIERARCHY = "HistoricalDates";

	/**
	 * Adds the dimensions descriptions to the input
	 * builder.
	 *
	 * @param builder The cube builder
	 * @return The builder for chained calls
	 */
	public static ICanBuildCubeDescription<IActivePivotInstanceDescription> dimensions(
			ICanStartBuildingDimensions builder)
	{
		return builder

			.withSingleLevelDimension(HOST_NAME_HIERARCHY)

			.withDimension(TRADES_HIERARCHY)
				.withHierarchyOfSameName()
						.withLevel(RISK__TRADE_ID)
				.withHierarchy("TOTO")
						.withLevel("TOTO")

			.withDimension(TIME_DIMENSION)
				.withType(DimensionType.TIME)
				.withHierarchy(HISTORICAL_DATES_HIERARCHY).slicing()
					.withLevel(RISK__AS_OF_DATE)
						.withType(LevelType.TIME)
						.withFormatter("DATE[yyyy-MM-dd]")
						.withComparator(ReverseOrderComparator.type)

			.withEpochDimension()
				.withEpochsLevel()
					.withComparator(ReverseEpochComparator.TYPE)
					.withFormatter("EPOCH[HH:mm:ss]")
					.end()
		;
	}

}
