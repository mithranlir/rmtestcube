/*
 * (C) Quartet FS 2013-2017
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.cfg.content.impl;


import com.qfs.content.cfg.IContentServiceConfig;
import com.qfs.content.service.IContentService;
import com.qfs.content.service.audit.impl.AuditableHibernateContentService;
import com.qfs.sandbox.util.impl.HibernateUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Spring Configuration class used to create
 * the content service Bean.
 *
 * @author QuartetFS
 */
@Configuration
public class ContentServiceConfig implements IContentServiceConfig {

	/**
	 * The content service is a bean which can be used by ActivePivot server to store:
	 * <ul>
	 * <li>calculated members and share them between users</li>
	 * <li>the cube descriptions</li>
	 * <li>entitlements</li>
	 * </ul>
	 * @return the content service
	 */
	@Override
	@Bean
	public IContentService contentService() {
		org.hibernate.cfg.Configuration conf  = HibernateUtil.loadConfiguration("hibernate.properties");
		return new AuditableHibernateContentService(conf);
	}


}
