/*
 * (C) Quartet FS 2014-2016
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.multiversion.impl;

import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

import com.qfs.fwk.ordering.impl.EpochComparator;
import com.qfs.multiversion.ADefaultEpochPolicy;
import com.qfs.multiversion.IEpoch;
import com.qfs.multiversion.IEpochHistory;
import com.qfs.multiversion.IEpochManagementPolicy;
import com.qfs.multiversion.IHistoryNode;
import com.qfs.multiversion.IVersionHistory;

/**
 * A custom epoch management {@link IEpochManagementPolicy policy} that keeps a version
 * each fixed period of time and releases all the others.
 * <p>
 * Example: <code> CustomEpochPolicy(2 * 60_000, 5 * 60_000, 30 * 60_000) </code>
 * Keeps the last 2 minutes, then one version each 5 minutes until the last half an hour.
 *
 * @author Quartet FS
 */
public class CustomEpochPolicy extends ADefaultEpochPolicy {

	/** The minimal time period (in ms), a version should be kept in the history */
	protected final long minTimeToKeep;

	/** The interval of time (in ms), after each, we should keep a version */
	protected final long period;

	/** The maximal time period (in ms), a version can be kept.*/
	protected final long maxTimeToKeep;

	/** For each component, versions that are periodically kept (rule 2) */
	protected final ConcurrentHashMap<String, SortedSet<IEpoch>> periodicKeptById = new ConcurrentHashMap<>();

	/**
	 * The maximum duration for which a version can stay released. Once a version has been released
	 * for this long we force its discarding.
	 */
	protected final long forceDiscardOldVersions;

	/**
	 * Constructor of a {@link IEpochManagementPolicy} that executes the 4 following rules:
	 * <ul>
	 * <li>Rule 1: Keeps all versions created in the last {@code minTimeToKeep} milliseconds.
	 * <li>Rule 2: Keeps one version each {@code period} milliseconds until {@code maxTimeToKeep}
	 * milliseconds.
	 * <li>Rule 3: Releases all other versions.
	 * <li>Rule 4: Once a version has been released for long enough we force its discard (ie we
	 * force the cleanup of the associated data).
	 * </ul>
	 *
	 * @param minTimeToKeep The MINIMAL time period (in ms), a version should be kept in the
	 *        history.
	 * @param period The interval of time (in ms), after each, we should keep a version.
	 * @param maxTimeToKeep The MAXIMAL time period (in ms), a version can be kept alive.
	 * @param forceDiscardOldVersionsTime The maximum duration (in ms) for which a version can stay
	 *        released. Once a version has been released for this long we force its discarding.
	 */
	public CustomEpochPolicy(long minTimeToKeep, long period, long maxTimeToKeep, long forceDiscardOldVersionsTime) {
		super();
		this.minTimeToKeep = minTimeToKeep;
		this.period = period;
		this.maxTimeToKeep = maxTimeToKeep;
		this.forceDiscardOldVersions = forceDiscardOldVersionsTime;
	}

	@Override
	public void onCommit(IEpoch epoch, IEpochHistory history) {
		final long now = System.currentTimeMillis();
		execute(now, epoch, history);
	}

	/**
	 * Gets the set of periodically kept epochs for the given component.
	 * @param mvId The component's id
	 * @return the set of periodically kept epochs for the given component.
	 */
	protected SortedSet<IEpoch> getOrCreatePeriodicallyKept(String mvId) {
		SortedSet<IEpoch> l = this.periodicKeptById.get(mvId);
		if (l == null) {
			l = new TreeSet<>(EpochComparator.INSTANCE);
			SortedSet<IEpoch> previous = this.periodicKeptById.putIfAbsent(mvId, l);
			if (previous != null)
				l = previous;
		}
		return l;
	}

	/**
	 * Method to be called after each commit to release all unnecessary versions.
	 *
	 * @param currentTime The current time (in ms).
	 * @param currentEpoch The current (i.e. new committed) epoch.
	 * @param history The {@link IVersionHistory history} of the component
	 */
	protected void execute(final long currentTime, final IEpoch currentEpoch, final IEpochHistory history) {
		// In a commit heavy application, it would be best to release and discard
		// epochs in a separate thread, to avoid blocking the commit.

		final SortedSet<IEpoch> periodicallyKept = getOrCreatePeriodicallyKept(history.getMultiVersionId());

		// Add the new committed epoch to the list of periodically kept if needed
		if (periodicallyKept.isEmpty()
				|| currentEpoch.getTimestamp() - period >= periodicallyKept.last().getTimestamp()) {
			periodicallyKept.add(currentEpoch);
		}

		history.releaseEpochs(currentEpoch.getBranch(), new Predicate<IHistoryNode>() {

			@Override
			public boolean test(IHistoryNode historyNode) {
				final long time = historyNode.getEpoch().getTimestamp();
				if (currentTime - time < minTimeToKeep) {
					// Rule 1: Keep the last minTimeToKeep ms
					return false;
				}
				if (currentTime - time >= maxTimeToKeep) {
					// Rule 3
					periodicallyKept.remove(historyNode.getEpoch());
					return true;
				}

				// Rule 2: periodically kept
				return !periodicallyKept.contains(historyNode.getEpoch());
			}
		});

		history.forceDiscardEpochs(new Predicate<IHistoryNode>() {
			@Override
			public boolean test(IHistoryNode historyNode) {
				// Rule 4: force the discard of the old epochs.
				return System.currentTimeMillis() - historyNode.getReleaseTimestamp() > forceDiscardOldVersions;
			};
		});
	}
}
