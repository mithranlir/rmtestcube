//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.activeviam.lic.impl;

import com.activeviam.activation.impl.LicenseException;
import com.activeviam.activation.impl.LicenseManager;
import com.activeviam.activation.impl.Platform;
import com.activeviam.lic.common.EncryptUtils;
import com.activeviam.lic.common.SessionInfo;
import com.activeviam.lic.common.UsageRequest;
import com.activeviam.lic.impl.ActiveViamLicense;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qfs.logging.MessagesDatastore;
import com.qfs.platform.IPlatform;
import com.qfs.platform.share.VirtualPlatform;
import com.qfs.pool.impl.QFSPools;
import com.quartetfs.fwk.IPair;
import com.quartetfs.fwk.QuartetRuntimeException;
import com.quartetfs.fwk.impl.Pair;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.management.ManagementFactory;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public final class Licensing {
    public static final String DEV_ENV = "DEV";
    static final String LOGGING_SOURCE_NAME = "ActiveViam License";
    static final String LOGGING_METHOD_NAME = "log";
    static final Logger logger = MessagesDatastore.getLogger(Licensing.class);
    private static final String newLine = System.getProperty("line.separator");
    static final AtomicBoolean infoLogged = new AtomicBoolean(false);
    private static volatile Licensing.LicenseContext licenseContext;

    public Licensing() {
    }

    private static void log(Level level, String message) {
        logger.logp(level, "ActiveViam License", "log", message);
    }

    private static void log(Level level, String message, Exception e) {
        logger.logp(level, "ActiveViam License", "log", message + "(" + e.getMessage() + ")");
    }

    public static void logLicenseInfoOnce() {
        if(infoLogged.compareAndSet(false, true)) {
            log(Level.INFO, getLicenseContext().toString() + "\n" + getLicense().toString());
        }

    }

    public static boolean checkLicence() {
        logLicenseInfoOnce();
        boolean isValid = getLicenseContext().verifyLicense();
        if(isValid) {
            log(Level.FINE, "License status: Valid");
            log(Level.FINE, "License: " + getLicense().getLicenseStatus());
        } else {
            log(Level.SEVERE, "License status: Invalid");
            log(Level.SEVERE, "License: " + getLicense().getLicenseStatus());
        }

        return isValid;
    }

    private static final Licensing.LicenseContext getLicenseContext() {
        if(licenseContext == null) {
            Class var0 = Licensing.LicenseContext.class;
            synchronized(Licensing.LicenseContext.class) {
                if(licenseContext == null) {
                    licenseContext = new Licensing.LicenseContext();
                }
            }
        }

        return licenseContext;
    }

    public static final ActiveViamLicense getLicense() {
        return getLicenseContext().getLicense();
    }

    public static final byte[] getBinaryLicense() {
        return getLicenseContext().getBinaryLicense();
    }

    public static final void reset() {
        getLicenseContext().reset();
        infoLogged.set(false);
    }

    public static final String reload(String licensePath) {
        String oldPath = System.setProperty("activepivot.license", licensePath);
        Licensing.LicenseContext ctx = new Licensing.LicenseContext();
        if(!ctx.verifyLicense()) {
            String msg1 = "The ActiveViam license at " + licensePath + " is not valid: " + ctx.license.getLicenseStatus();
            log(Level.SEVERE, msg1);
            System.setProperty("activepivot.license", oldPath);
            return msg1;
        } else {
            Class msg = Licensing.LicenseContext.class;
            synchronized(Licensing.LicenseContext.class) {
                /*
                if(licenseContext.onDemandNotificationUsage != null) {
                    licenseContext.onDemandNotificationUsage.cancel(true);
                    licenseContext.onDemandNotificationUsage = null;
                }
                */
                licenseContext = ctx;
                log(Level.INFO, "ActiveViam Licensing Agent reloaded.");
                infoLogged.compareAndSet(true, false);
            }

            logLicenseInfoOnce();
            return "ActiveViam Licensing Agent reloaded.";
        }
    }

    private static byte[] httpRequestSync(String urlStr, Optional<String> requestMethod, Collection<IPair<String, String>> requestHeaders, Optional<IPair<String, Licensing.OutputStreamConsumer>> content, Optional<Integer> timeoutInMillis) throws IOException, Licensing.RecoverableLicensingException {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        if(requestMethod.isPresent()) {
            conn.setRequestMethod((String)requestMethod.get());
        }

        Iterator is = requestHeaders.iterator();

        while(is.hasNext()) {
            IPair requestHeader = (IPair)is.next();
            conn.setRequestProperty((String)requestHeader.getLeft(), (String)requestHeader.getRight());
        }

        Throwable requestHeader1;
        if(content.isPresent()) {
            conn.setRequestProperty("Content-Type", (String)((IPair)content.get()).getLeft());
            conn.setDoOutput(true);
            OutputStream is1 = conn.getOutputStream();
            requestHeader1 = null;

            try {
                ((Licensing.OutputStreamConsumer)((IPair)content.get()).getRight()).process(is1);
            } catch (Throwable var45) {
                requestHeader1 = var45;
                throw var45;
            } finally {
                if(is1 != null) {
                    if(requestHeader1 != null) {
                        try {
                            is1.close();
                        } catch (Throwable var44) {
                            requestHeader1.addSuppressed(var44);
                        }
                    } else {
                        is1.close();
                    }
                }

            }
        }

        timeoutInMillis.ifPresent(conn::setConnectTimeout);
        conn.connect();

        try {
            if(conn.getResponseCode() != 200) {
                throw new Licensing.RecoverableLicensingException("Http request failed with http code : " + conn.getResponseCode());
            } else {
                InputStream is2 = conn.getInputStream();
                requestHeader1 = null;

                try {
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    byte[] data = new byte[16384];

                    int nRead;
                    while((nRead = is2.read(data, 0, data.length)) != -1) {
                        buffer.write(data, 0, nRead);
                    }

                    buffer.flush();
                    byte[] var12 = buffer.toByteArray();
                    return var12;
                } catch (Throwable var47) {
                    requestHeader1 = var47;
                    throw var47;
                } finally {
                    if(is2 != null) {
                        if(requestHeader1 != null) {
                            try {
                                is2.close();
                            } catch (Throwable var43) {
                                requestHeader1.addSuppressed(var43);
                            }
                        } else {
                            is2.close();
                        }
                    }

                }
            }
        } finally {
            conn.disconnect();
        }
    }

    public static String getMac() {
        try {
            return Platform.getLocalHostMacAddress();
        } catch (IOException var1) {
            return "Error retrieving MAC address";
        }
    }

    public static String getIp() {
        try {
            return Platform.getLocalHostAddress();
        } catch (UnknownHostException var1) {
            return "Error retrieving IP address";
        }
    }

    public static String getHostname() {
        try {
            return Platform.getLocalHostName();
        } catch (UnknownHostException var1) {
            return "Error retrieving hostname";
        }
    }

    protected static class RecoverableLicensingException extends Exception {
        private static final long serialVersionUID = 1385585591011658954L;

        private RecoverableLicensingException(String message) {
            super(message);
        }
    }

    private static final class LicenseContext {
        final long currentTime;
        final int cpuCount;
        volatile byte[] binaryLicense;
        volatile ActiveViamLicense license;
        volatile boolean initCheckDone;
        volatile boolean initCheckResult;
        private ScheduledFuture<?> onDemandNotificationUsage;
        private volatile Optional<String> onDemandLicenseError;

        private LicenseContext() {
            this.initCheckDone = false;
            this.initCheckResult = false;
            this.currentTime = System.currentTimeMillis();
            IPlatform platform = IPlatform.CURRENT_PLATFORM;
            if(platform instanceof VirtualPlatform) {
                this.cpuCount = ((VirtualPlatform)platform).getUnderlying().getProcessorCount();
            } else {
                this.cpuCount = platform.getProcessorCount();
            }

        }

        private final ActiveViamLicense getLicense() {
            if(this.license == null) {
                Class var1 = ActiveViamLicense.class;
                synchronized(ActiveViamLicense.class) {
                    if(this.license == null) {
                        Licensing.log(Level.INFO, "Activating ActiveViam Licensing Agent.");

                        /*
                        try {
                            byte[] le = LicenseManager.getBinaryLicense(ActiveViamLicense.class);
                            ActiveViamLicense license = (ActiveViamLicense)LicenseManager.getLicense(ActiveViamLicense.class, le);
                            this.binaryLicense = le;
                            this.license = license;
                        } catch (LicenseException var9) {
                            this.license = new ActiveViamLicense();
                            Licensing.log(Level.SEVERE, "Error loading ActiveViam license: " + var9.getMessage());
                            this.license.status = var9.getMessage();
                        } finally {
                            Licensing.logLicenseInfoOnce();
                        }
                        */

                        try {
                            ActiveViamLicense license = createFakeActiveViamLicense();
                            this.binaryLicense = null;
                            this.license = license;
                        } finally {
                            Licensing.logLicenseInfoOnce();
                        }


                    }
                }
            }

            return this.license;
        }

        public static ActiveViamLicense createFakeActiveViamLicense() {
            final Properties properties = new Properties();

            final Long startDate = (new Date()).getTime() - (24 * 60 * 60 * 1000); // now - 1d;
            properties.put("sDate", startDate.toString());

            final Long endDate = (new Date()).getTime() + (365 * 24 * 60 * 60 * 1000); // now + 1 year;
            properties.put("eDate", endDate.toString());

            String host = "";
            try {
                host = Platform.getLocalHostName();
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
            properties.put("host", host);

            int maxNbOfCPU = 0;
            IPlatform platform = IPlatform.CURRENT_PLATFORM;
            if(platform instanceof VirtualPlatform) {
                maxNbOfCPU = ((VirtualPlatform)platform).getUnderlying().getProcessorCount();
            } else {
                maxNbOfCPU = platform.getProcessorCount();
            }

            properties.put("maxNbOfCPU", maxNbOfCPU + "");

            properties.put("live", "YES");

            properties.put("sentinel", "YES");

            properties.put("rs", "YES");

            final ActiveViamLicense license = new ActiveViamLicense(properties);

            license.status = "License loaded and tested successfully.";

            return license;
        }


        private final byte[] getBinaryLicense() {
            /*
            if(this.binaryLicense == null) {
                this.getLicense();
            }

            return this.binaryLicense;
            */
            return null;
        }

        private final void reset() {
            if(this.license != null) {
                Class var1 = ActiveViamLicense.class;
                synchronized(ActiveViamLicense.class) {
                    if(this.license != null) {
                        Licensing.log(Level.INFO, "Resetting ActiveViam Licensing Agent.");
                        this.license = null;
                        this.binaryLicense = null;
                        this.initCheckDone = false;
                        /*
                        if(this.onDemandNotificationUsage != null) {
                            this.onDemandNotificationUsage.cancel(true);
                            this.onDemandNotificationUsage = null;
                        }
                        */
                    }
                }
            }

        }

        private final boolean verifyLicense() {
            if(!this.initCheckDone) {
                synchronized(this) {
                    if(!this.initCheckDone) {
                        boolean result = this.verifyLicenseInit();
                        this.initCheckDone = true;
                        this.initCheckResult = result;
                        return result;
                    }
                }
            }

            // return this.verifyLicenseIncr();
            return true;
        }

        private boolean verifyLicenseInit() {
            /*
            String cloudId = null;
            String cloudProvider = null;

            try {
                IPair isOnDemandLicense = (IPair)QFSPools.getBackgroundSchedulerService().invokeAny(Arrays.asList(new Callable[]{() -> {
                    return new Pair(new String(Licensing.httpRequestSync("http://169.254.169.254/latest/meta-data/instance-id", Optional.empty(), Collections.emptyList(), Optional.empty(), Optional.of(Integer.valueOf(50)))), "AWS");
                }, () -> {
                    return new Pair(new String(Licensing.httpRequestSync("http://169.254.169.254/metadata/instance/compute/vmId?api-version=2017-04-02&format=text", Optional.empty(), Arrays.asList(new IPair[]{new Pair("Metadata", Boolean.toString(true))}), Optional.empty(), Optional.of(Integer.valueOf(50)))), "Azure");
                }, () -> {
                    return new Pair(new String(Licensing.httpRequestSync("http://metadata.google.internal/computeMetadata/v1/instance/id", Optional.empty(), Arrays.asList(new IPair[]{new Pair("Metadata-Flavor", "Google")}), Optional.empty(), Optional.of(Integer.valueOf(50)))), "GCP");
                }}));
                cloudId = (String)isOnDemandLicense.getLeft();
                cloudProvider = (String)isOnDemandLicense.getRight();
            } catch (InterruptedException var4) {
                throw new QuartetRuntimeException(var4);
            } catch (ExecutionException var5) {
                ;
            }

            boolean isOnDemandLicense1 = this.license.isOnDemand();
            if(cloudId != null && !isOnDemandLicense1) {
                this.license.status = "This license cannot be used in a cloud. Please request an on-demand license.";
                return false;
            } else {
                if(isOnDemandLicense1) {
                    if(!this.verifyLicenseOnDemandInit(cloudProvider, cloudId)) {
                        return false;
                    }
                } else if(!this.verifyLicenseRegularInit()) {
                    return false;
                }

                this.license.status = "License loaded and tested successfully.";
                Licensing.log(Level.INFO, this.license.status);
                return true;
            }
            */
            if(!this.verifyLicenseRegularInit()) {
                return false;
            }
            this.license.status = "License loaded and tested successfully.";
            Licensing.log(Level.INFO, this.license.status);
            return true;
        }

        private boolean verifyLicenseRegularInit() {
            if(this.currentTime <= this.license.getEndDate() && this.currentTime >= this.license.getStartDate()) {
                boolean restrictionFound1 = false;
                String status;
                if(!"-".equals(this.license.getMac())) {
                    restrictionFound1 = true;

                    try {
                        status = Platform.getLocalHostMacAddress();
                    } catch (IOException var6) {
                        this.license.status = "Unable to obtain MAC Address because of IOException.";
                        Licensing.log(Level.SEVERE, this.license.getLicenseStatus(), var6);
                        return false;
                    }

                    if(status == null || status.isEmpty()) {
                        this.license.status = "Unable to obtain MAC Address (empty MAC Address).";
                        Licensing.log(Level.SEVERE, this.license.getLicenseStatus());
                        return false;
                    }

                    if(!Platform.equals(status, this.license.getMac())) {
                        Licensing.logger.logp(Level.SEVERE, "ActiveViam License", "log", "EXC_MAC_LICENSE", new Object[]{status, this.license.getMac()});
                        this.license.status = "Your license is bound to another machine (your MAC Address: " + status + ", license MAC Address: " + this.license.getMac() + ").";
                        return false;
                    }
                }

                if(!"-".equals(this.license.getIp())) {
                    restrictionFound1 = true;

                    try {
                        status = Platform.getLocalHostAddress();
                    } catch (UnknownHostException var5) {
                        Licensing.log(Level.SEVERE, "EXC_UNKNOWN_IP", var5);
                        this.license.status = "EXC_UNKNOWN_IP";
                        return false;
                    }

                    if(!status.equals(this.license.getIp())) {
                        Licensing.log(Level.SEVERE, "EXC_IP_LICENSE");
                        this.license.status = "Your license is bound to another machine (your IP Address: " + status + ", license IP Address: " + this.license.getIp() + ").";
                        return false;
                    }
                }

                if(!"-".equals(this.license.getHostname())) {
                    restrictionFound1 = true;

                    try {
                        status = Platform.getLocalHostName();
                    } catch (UnknownHostException var4) {
                        Licensing.log(Level.SEVERE, "EXC_UNKNOWN_HOST", var4);
                        this.license.status = "EXC_UNKNOWN_HOST";
                        return false;
                    }

                    if(!status.equalsIgnoreCase(this.license.getHostname())) {
                        Licensing.logger.logp(Level.SEVERE, "ActiveViam License", "log", "EXC_HOST_LICENSE", new Object[]{status, this.license.getHostname()});
                        this.license.status = "Your license is bound to another machine (your hostname: " + status + ", license hostname: " + this.license.getHostname() + ").";
                        return false;
                    }
                }

                if(this.cpuCount > this.license.getCpuCount()) {
                    Licensing.logger.logp(Level.SEVERE, "ActiveViam License", "log", "EXC_CORE_EXCEEDED_LICENSE", new Object[]{Integer.valueOf(this.license.getCpuCount()), Integer.valueOf(this.cpuCount)});
                    status = "The number fo cores allowed by the license is not enough to operate on this server." + Licensing.newLine;
                    status = status + "Cores allowed by the license: " + this.license.getCpuCount() + Licensing.newLine;
                    status = status + "Cores in the server: " + this.cpuCount + Licensing.newLine;
                    status = status + "Please contact the ActiveViam support team.";
                    this.license.status = status;
                    return false;
                } else if(!restrictionFound1) {
                    Licensing.log(Level.SEVERE, "EXC_UNRESTRICTED_LICENSE");
                    status = "The license is not valid due to violated restrictions." + Licensing.newLine;
                    status = status + "Please contact the ActiveViam support team.";
                    this.license.status = status;
                    return false;
                } else {
                    return true;
                }
            } else {
                Licensing.log(Level.SEVERE, "EXC_EXPIRED_LICENSE");
                String restrictionFound = "Your license has expired: system date (" + new Date(this.currentTime) + ") is not between start date (" + new Date(this.license.getStartDate()) + ") and end date (" + new Date(this.license.getEndDate()) + ")." + Licensing.newLine;
                restrictionFound = restrictionFound + "Please contact ActiveViam.";
                this.license.status = restrictionFound;
                return false;
            }
        }

        /*
        private boolean verifyLicenseOnDemandInit(String cloudProvider, String cloudId) {
            String serverUrl;
            if(this.license.getEndDate() > 0L && this.currentTime > this.license.getEndDate() || this.license.getStartDate() > 0L && this.currentTime < this.license.getStartDate()) {
                Licensing.log(Level.SEVERE, "EXC_EXPIRED_LICENSE");
                serverUrl = "Your license has expired: system date (" + new Date(this.currentTime) + ") is not between start date (" + new Date(this.license.getStartDate()) + ") and end date (" + new Date(this.license.getEndDate()) + ")." + Licensing.newLine;
                serverUrl = serverUrl + "Please contact ActiveViam.";
                this.license.status = serverUrl;
                return false;
            } else {
                String licenseServerNotifierContextBuilder = this.license.getOnDemandLicenseServer();
                byte e = -1;
                switch(licenseServerNotifierContextBuilder.hashCode()) {
                    case -650134345:
                        if(licenseServerNotifierContextBuilder.equals("AWS_EU_WEST_1_UAT")) {
                            e = 1;
                        }
                        break;
                    case 484654490:
                        if(licenseServerNotifierContextBuilder.equals("AVInvalidUrlCode")) {
                            e = 3;
                        }
                        break;
                    case 1320539080:
                        if(licenseServerNotifierContextBuilder.equals("AWS_EU_WEST_1_PROD")) {
                            e = 2;
                        }
                        break;
                    case 1320645891:
                        if(licenseServerNotifierContextBuilder.equals("AWS_EU_WEST_1_TEST")) {
                            e = 0;
                        }
                }

                switch(e) {
                    case 0:
                        serverUrl = "https://eu-west-1-aws-licensing.cloud.activeviam.com/test/licensing-v0";
                        break;
                    case 1:
                        serverUrl = "https://eu-west-1-aws-licensing.cloud.activeviam.com/uat/licensing-v0";
                        break;
                    case 2:
                        serverUrl = "https://eu-west-1-aws-licensing.cloud.activeviam.com/prod/licensing-v0";
                        break;
                    case 3:
                        serverUrl = "https://activeviam.com/invalidurlfortest";
                        break;
                    default:
                        throw new RuntimeException("Unsupported / unrecognized license server : " + this.license.getOnDemandLicenseServer());
                }

                Licensing.LicenseServerNotifierContextBuilder licenseServerNotifierContextBuilder1 = new Licensing.LicenseServerNotifierContextBuilder();

                try {
                    Licensing.LicenseServerNotifier e1 = licenseServerNotifierContextBuilder1.build(serverUrl, this.license.getId(), this.cpuCount, Licensing.getHostname(), Licensing.getIp(), Licensing.getMac(), ManagementFactory.getRuntimeMXBean().getStartTime(), cloudProvider, cloudId, EncryptUtils.parseRSAPublicKey((String)Objects.requireNonNull(this.license.getPublicKey())));
                    this.onDemandLicenseError = e1.notifyUsage();
                    if(!this.onDemandLicenseError.isPresent()) {
                        Licensing.log(Level.INFO, "Connection to license server succeeded.");
                        Licensing.Frequency usageNotificationFrequency = licenseServerNotifierContextBuilder1.getNotificationFrequency();
                        this.onDemandNotificationUsage = QFSPools.getBackgroundSchedulerService().scheduleAtFixedRate(new Licensing.LicenseContext.BackgroundJobLicenseServerNotifier(this, e1, licenseServerNotifierContextBuilder1.toleranceDelay()), usageNotificationFrequency.getDelayInUnits(), usageNotificationFrequency.getDelayInUnits(), usageNotificationFrequency.getUnit());
                        return true;
                    } else {
                        this.license.status = (String)this.onDemandLicenseError.get();
                        return false;
                    }
                } catch (IOException var7) {
                    this.license.status = "Unable to check license server for initial check because of a network error.";
                    Licensing.log(Level.SEVERE, this.license.getLicenseStatus(), var7);
                    return false;
                } catch (Licensing.RecoverableLicensingException var8) {
                    this.license.status = "Unable to check license server for initial check because of an error on the licensing server.";
                    Licensing.log(Level.SEVERE, this.license.getLicenseStatus(), var8);
                    return false;
                } catch (GeneralSecurityException var9) {
                    this.license.status = "Unable to check license server for initial check because of a security issue.";
                    Licensing.log(Level.SEVERE, this.license.getLicenseStatus(), var9);
                    return false;
                }
            }
        }
        */

        /*
        private final boolean verifyLicenseIncr() {
            if(!this.initCheckResult) {
                return false;
            } else if(!this.license.isOnDemand()) {
                if(System.currentTimeMillis() > this.license.getEndDate()) {
                    Licensing.log(Level.SEVERE, "EXC_EXPIRED_LICENSE");
                    String e = "Your license has expired: system date (" + new Date(this.currentTime) + ") is after end date (" + new Date(this.license.getEndDate()) + ")." + Licensing.newLine;
                    e = e + "Please contact ActiveViam.";
                    this.license.status = e;
                    return false;
                } else {
                    return true;
                }
            } else if(this.onDemandNotificationUsage.isDone()) {
                try {
                    this.onDemandNotificationUsage.get();
                    throw new QuartetRuntimeException("Usage notification has been stopped while it should not have.");
                } catch (ExecutionException | InterruptedException var2) {
                    this.license.status = "Unable to notify license server of usage.";
                    Licensing.log(Level.SEVERE, this.license.getLicenseStatus(), var2);
                    return false;
                } catch (CancellationException var3) {
                    this.license.status = "Application has been shut down.";
                    Licensing.log(Level.SEVERE, this.license.getLicenseStatus());
                    return false;
                }
            } else if(QFSPools.getBackgroundSchedulerService().isShutdown()) {
                this.license.status = "Application has been shut down.";
                Licensing.log(Level.SEVERE, this.license.getLicenseStatus());
                return false;
            } else if(this.onDemandLicenseError.isPresent()) {
                return false;
            } else if(-this.onDemandNotificationUsage.getDelay(TimeUnit.MINUTES) > 5L) {
                this.license.status = "License server hasn\'t replied for too long.";
                Licensing.log(Level.SEVERE, this.license.getLicenseStatus());
                return false;
            } else {
                return true;
            }
        }
        */

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("\n*************** Platform Information *****************");
            sb.append("\nSystem Time: ").append(new Date(this.currentTime));
            sb.append("\nNumber of Processors: ").append(this.cpuCount);
            sb.append("\nMAC address: ").append(Licensing.getMac());
            sb.append("\nIP address: ").append(Licensing.getIp());
            sb.append("\nHostname: ").append(Licensing.getHostname());
            sb.append("\n******************************************************");
            return sb.toString();
        }

        /*
        static final class BackgroundJobLicenseServerNotifier implements Runnable {
            private long initialSuccessfulNotificationTimestamp = (new Date()).getTime();
            private Optional<Long> lastNetworkFailureStartTimestamp = Optional.empty();
            private final Licensing.LicenseContext parentLicenseContext;
            private final Licensing.LicenseServerNotifier licenseServerNotifier;
            final long toleranceDelay;

            public BackgroundJobLicenseServerNotifier(Licensing.LicenseContext parentLicenseContext, Licensing.LicenseServerNotifier licenseServerNotifier, long toleranceDelay) {
                this.parentLicenseContext = parentLicenseContext;
                this.licenseServerNotifier = licenseServerNotifier;
                this.toleranceDelay = toleranceDelay;
            }

            public synchronized void run() {
                boolean licenseWasInvalidated = this.parentLicenseContext.onDemandLicenseError.isPresent();

                try {
                    this.parentLicenseContext.onDemandLicenseError = this.licenseServerNotifier.notifyUsage();
                    if(!this.parentLicenseContext.onDemandLicenseError.isPresent()) {
                        Licensing.log(Level.INFO, "Usage notification to license server succeeded.");
                        if(this.lastNetworkFailureStartTimestamp.isPresent()) {
                            this.parentLicenseContext.license.status = "License loaded and tested successfully.";
                            this.lastNetworkFailureStartTimestamp = Optional.empty();
                        }

                        if(licenseWasInvalidated) {
                            this.licenseServerNotifier.refreshSessionId();
                            this.initialSuccessfulNotificationTimestamp = (new Date()).getTime();
                            this.lastNetworkFailureStartTimestamp = Optional.empty();
                        }
                    } else {
                        this.parentLicenseContext.license.status = (String)this.parentLicenseContext.onDemandLicenseError.get();
                        Licensing.log(Level.SEVERE, this.parentLicenseContext.license.getLicenseStatus());
                    }
                } catch (Licensing.RecoverableLicensingException | IOException var5) {
                    long currentTimestamp = (new Date()).getTime();
                    if(!this.lastNetworkFailureStartTimestamp.isPresent()) {
                        this.parentLicenseContext.license.status = "Unable to check license on the distant server.";
                        this.lastNetworkFailureStartTimestamp = Optional.of(Long.valueOf(currentTimestamp));
                    }

                    Licensing.log(Level.SEVERE, this.parentLicenseContext.license.getLicenseStatus(), var5);
                    if(!this.parentLicenseContext.onDemandLicenseError.isPresent() && (currentTimestamp - this.initialSuccessfulNotificationTimestamp < this.toleranceDelay || currentTimestamp - ((Long)this.lastNetworkFailureStartTimestamp.get()).longValue() > this.toleranceDelay)) {
                        this.parentLicenseContext.onDemandLicenseError = Optional.of(this.parentLicenseContext.license.status);
                    }
                } catch (GeneralSecurityException var6) {
                    throw new QuartetRuntimeException(var6);
                }

            }
        }
        */
    }


    static class Frequency {
        final long delayInUnits;
        final TimeUnit unit;

        public Frequency(long delayInUnits, TimeUnit unit) {
            this.delayInUnits = delayInUnits;
            this.unit = unit;
        }

        public long getDelayInUnits() {
            return this.delayInUnits;
        }

        public TimeUnit getUnit() {
            return this.unit;
        }
    }

    /*
    static class LicenseServerNotifier {
        private final String url;
        private final String licenseId;
        private final int cpuCount;
        private final String hostname;
        private final String ip;
        private final String mac;
        String sessionId;
        private final long vmStartTime;
        protected final String cloudProvider;
        private final String cloudId;
        private final transient ObjectMapper mapper = new ObjectMapper();
        private final RSAPublicKey publicKey;
        private final KeyGenerator symKeyGen;
        private static final TypeReference<HashMap<String, Object>> QUARTET_JSON_RESPONSE_TYPE_REF = new TypeReference() {
        };

        public LicenseServerNotifier(String url, String licenseId, int cpuCount, String hostname, String ip, String mac, long vmStartTime, String cloudProvider, String cloudId, RSAPublicKey publicKey) {
            this.url = url;
            this.licenseId = licenseId;
            this.cpuCount = cpuCount;
            this.hostname = hostname;
            this.ip = ip;
            this.mac = mac;
            this.vmStartTime = vmStartTime;
            this.cloudProvider = cloudProvider;
            this.cloudId = cloudId;
            this.refreshSessionId();
            this.publicKey = publicKey;

            try {
                this.symKeyGen = KeyGenerator.getInstance("AES");
            } catch (NoSuchAlgorithmException var13) {
                throw new QuartetRuntimeException(var13);
            }
        }

        public Optional<String> notifyUsage() throws IOException, Licensing.RecoverableLicensingException, GeneralSecurityException {
            SecretKey symKey = this.symKeyGen.generateKey();
            UsageRequest newUsageRequest = new UsageRequest(this.licenseId, EncryptUtils.encryptRSA(Base64.getEncoder().encode(symKey.getEncoded()), this.publicKey), EncryptUtils.encryptAES(this.mapper.writeValueAsBytes(new SessionInfo(this.cpuCount, this.hostname, this.ip, this.mac, this.sessionId, this.vmStartTime, this.cloudProvider, this.cloudId)), symKey));
            byte[] newUsageRequestAsBytes = this.mapper.writeValueAsBytes(newUsageRequest);
            byte[] responsesAsBytes = Licensing.httpRequestSync(this.url,
                    Optional.of("POST"),
                    Collections.emptyList(),
                    Optional.of(new Pair("application/json", (os) -> os.write(newUsageRequestAsBytes))),
                    Optional.empty());
            Map response = (Map)this.mapper.readValue(responsesAsBytes, QUARTET_JSON_RESPONSE_TYPE_REF);
            Map responseData;
            if(!"success".equals(response.get("status"))) {
                responseData = (Map)response.get("error");
                if(responseData == null) {
                    throw new Licensing.RecoverableLicensingException("Technical error on the licensing server");
                } else {
                    Map licenseServerTimeStamp1 = (Map)((List)responseData.get("errorChain")).get(0);
                    return Optional.of((String)licenseServerTimeStamp1.get("message"));
                }
            } else {
                responseData = (Map)response.get("data");
                long licenseServerTimeStamp = ((Long)responseData.get("serverTimestamp")).longValue();
                if(licenseServerTimeStamp <= 0L) {
                    return Optional.of("ActiveViam license server\'s response is invalid.");
                } else {
                    long currentTimeStamp = (new Date()).getTime();
                    return Math.abs(licenseServerTimeStamp - currentTimeStamp) > TimeUnit.MINUTES.toMillis(15L)?Optional.of("Too much time difference between this server and the ActiveViam license server. Please verify your server clock."):(!EncryptUtils.verifyRSA(Long.toString(licenseServerTimeStamp).getBytes(), this.publicKey, ((String)responseData.get("signature")).getBytes())?Optional.of("Difference between this server and the ActiveViam license server\'s keys."):Optional.empty());
                }
            }
        }

        private void refreshSessionId() {
            this.sessionId = UUID.randomUUID().toString();
        }
    }
    */

    protected interface OutputStreamConsumer {
        void process(OutputStream var1) throws IOException;
    }

    /*
    static class LicenseServerNotifierContextBuilder {
        LicenseServerNotifierContextBuilder() {
        }

        Licensing.LicenseServerNotifier build(String url, String licenseId, int cpuCount, String hostname, String ip, String mac, long vmStartTime, String cloudProvider, String cloudId, RSAPublicKey publicKey) {
            return new Licensing.LicenseServerNotifier(url, licenseId, cpuCount, hostname, ip, mac, vmStartTime, cloudProvider, cloudId, publicKey);
        }

        Licensing.Frequency getNotificationFrequency() {
            return new Licensing.Frequency(5L, TimeUnit.MINUTES);
        }

        long toleranceDelay() {
            return 1200000L;
        }
    }
    */
}
