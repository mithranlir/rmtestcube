# Sandbox ActivePivot

## Introduction

This sandbox starts a ActivePivot Server.

ActivePivot Server requires a Content Server to operate. This Sandbox can be started in two different modes,
based on the active Spring profile(s):
- If the `embedded-content` Spring profile is activated, an embedded Content Server will be started in the
  same process as the ActivePivot Server. It can therefore be used a standalone application in that case.
- If the `remote-content` Spring profile is activated, a remote Content Server is required. See for instance
  the `contentservice` project.

# Start the server with a remote Content Server

Before the application can be started, it must be compiled with maven, to generate the needed resources and folders.

Run `mvn clean install`. _You can skip tests if needed, using `-DskipTests=true` option._

You must first execute the class `com.qfs.sandbox.server.ContentServer` at `sandboxes/contentservice`.
Once the Content Server is online, put the URL of the Content Server at `contentServer.remote.url` 
in the file `content.service.properties`. 

Run the class `com.qfs.sandbox.server.PushToContentServer` with user **admin** (pass: "admin") the first time the application
is started. This will initialize the remote Content Server. This operation only needs to be performed once since the
Content Server data is persisted in an external database.

After the application finishes running, connect to the Content Server UI, at [localhost:9091/content](http://localhost:9091/content),
verify that the data entry of pivot exists.

Then run the class `com.qfs.sandbox.server.ActivePivotServer` located within the test sources with the `-Dspring.profiles.active="remote-content"` property.  
This starts a Jetty server, offering ActivePivot APIs such as:
- ActivePivot XMLA APIs., at [localhost:9090/xmla](http://localhost:9090/xmla).
- ActivePivot web services. 
  You can also go to [localhost:9090/webservices](http://localhost:9090/webservices) for an exhaustive
  list of web services provided by the server.

You can connect your ActiveUI to this ActivePivot server using [localhost:9090](http://localhost:9090).

# Start the server with an embedded Content Server

Before the application can be started, it must be compiled with maven, to generate the needed resources and folders.

Run `mvn clean install`. _You can skip tests if needed, using `-DskipTests=true` option._
Then run the class `com.qfs.sandbox.server.ActivePivotServer` located within the test sources with the `-Dspring.profiles.active="embedded-content"` property.

This starts a Jetty server, offering ActivePivot APIs such as:
- ActivePivot XMLA APIs., at [localhost:9090/xmla](http://localhost:9090/xmla).
- ActivePivot web services. 
  You can also go to [localhost:9090/webservices](http://localhost:9090/webservices) for an exhaustive
  list of web services provided by the server.

You can connect to the Content Server UI at [localhost:9090/content](http://localhost:9090/content).  
You can connect your ActiveUI to this ActivePivot server using [localhost:9090](http://localhost:9090).

## ActiveMonitor

ActiveMonitor can be activated in one of two ways:
- as an embedded server running in the same process as ActivePivot Server by activating the
  `embedded-monitor` Spring profile.
- as a remote server by executing the class `com.qfs.snl.server.ActiveMonitorServer` at `sandboxes/activemonitor` and
  activating the `remote-monitor` Spring profile in the ActivePivot Server application.

When running ActiveMonitor on a separate , you can modify the file `activemonitor.service.properties` 
to connect your ActiveMonitor to this ActivePivot Server by specifying these properties: 
- `sentinel.remote.url`
- `repository.remote.url`
- `activepivot.snl.url`
- `live.snl.url`

## ActivePivot configuration

ActivePivot sandbox project is only configured using Spring Configuration classes. 

The root Spring configuration class is `com.qfs.sandbox.cfg.impl.ActivePivotServerConfig`. Consult this class as 
a starting point to discover all defined beans. Consult imported classes Javadoc to get a description of the beans, 
their names and purposes.

2 classes are interesting to look at first:

- `com.qfs.sandbox.cfg.datastore.impl.DatastoreDescriptionConfig` for Datastore configuration
- `com.qfs.sandbox.cfg.source.impl.SourceConfig` for Data source configuration

## Resources

The resources used to configure the ActivePivot application (cube descriptions, context values, etc.) can be found at
`src/main/resources`. They are shared by Full server and Standalone ActivePivot server.
They will be copied and put at the root of the WAR when it is created.
You can take a look at the POM of these two servers to see how it is done by `maven-dependency-plugin`.
