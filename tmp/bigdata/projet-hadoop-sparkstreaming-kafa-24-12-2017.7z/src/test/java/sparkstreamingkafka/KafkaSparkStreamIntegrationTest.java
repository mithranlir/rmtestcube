package sparkstreamingkafka;

// doesn't work with minicluster... because different version of spark...

import com.github.sakserv.minicluster.config.ConfigVars;
import com.github.sakserv.minicluster.impl.KafkaLocalBroker;
import com.github.sakserv.minicluster.impl.ZookeeperLocalCluster;
import com.github.sakserv.propertyparser.PropertyParser;
import com.google.common.collect.ImmutableList;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

public class KafkaSparkStreamIntegrationTest {


    // Logger
    private static final Logger LOG = LoggerFactory.getLogger(KafkaSparkStreamIntegrationTest.class);

    // Setup the property parser
    private static PropertyParser propertyParser;
    static {
        try {
            propertyParser = new PropertyParser(ConfigVars.DEFAULT_PROPS_FILE);
            propertyParser.parsePropsFile();
        } catch(IOException e) {
            LOG.error("Unable to load property file: {}", propertyParser.getProperty(ConfigVars.DEFAULT_PROPS_FILE));
        }
    }

    private static ZookeeperLocalCluster zookeeperLocalCluster;
    private static KafkaLocalBroker kafkaLocalBroker;

    @BeforeClass
    public static void setUp() throws Exception {

        zookeeperLocalCluster = createZookeeperLocalCluster();
        zookeeperLocalCluster.start();

        kafkaLocalBroker = createKafkaLocalBroker();
        kafkaLocalBroker.start();

    }

    private static KafkaLocalBroker createKafkaLocalBroker() {
        return new KafkaLocalBroker.Builder()
                .setKafkaHostname(propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY))
                .setKafkaPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_PORT_KEY)))
                .setKafkaBrokerId(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_TEST_BROKER_ID_KEY)))
                .setKafkaProperties(new Properties())
                .setKafkaTempDir(propertyParser.getProperty(ConfigVars.KAFKA_TEST_TEMP_DIR_KEY))
                .setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY))
                .build();
    }

    private static ZookeeperLocalCluster createZookeeperLocalCluster() {
        return new ZookeeperLocalCluster.Builder()
                .setPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.ZOOKEEPER_PORT_KEY)))
                .setTempDir(propertyParser.getProperty(ConfigVars.ZOOKEEPER_TEMP_DIR_KEY))
                .setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY))
                .build();
    }

    @AfterClass
    public static void tearDown() throws Exception {

        kafkaLocalBroker.stop();
        zookeeperLocalCluster.stop();
    }


    private static final String CHECKPOINT_DIR = "/tmp";

    private static final Pattern SPACE = Pattern.compile(" ");

    @Test
    public void test() throws Exception {

        System.setProperty("hadoop.home.dir", "D:\\dev\\hadoop-horton\\projet-hadoop\\windows_libs\\2.6.2.0");

        final String kafkaHostName = propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY);
        final int kKafkaPort = Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_PORT_KEY));
        final String topics = "MyKafkaTopic";

        final String brokers = kafkaHostName + ":" + kKafkaPort;
        // Create context with a 2 seconds batch interval
        final SparkConf sparkConf = new SparkConf()
                .setAppName("StreamingE")
                .setMaster("local[*]");
        final JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(2));

        final Set<String> topicsSet = new HashSet<>(Arrays.asList(topics.split(",")));
        final Map<String, Object> kafkaParams = new HashMap<>();
        kafkaParams.put("metadata.broker.list", brokers);
        System.out.println("Brokers: " + brokers);

        final KafkaProducer<String, String> producer = new KafkaProducer<>(
                createConsumerConfig(kafkaHostName, kKafkaPort));

        produceMessages(producer, 1, topics);

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {

                for(int i=0; i<400; i++) {
                    produceMessages(producer, 10, topics);
                    try {
                        Thread.sleep(400);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();

        // Create direct kafka stream with brokers and topics
        // https://spark.apache.org/docs/2.1.0/api/java/index.html?org/apache/spark/streaming/kafka/KafkaUtils.html

        // https://github.com/apache/spark/blob/v2.1.0/examples/src/main/java/org/apache/spark/examples/streaming/JavaDirectKafkaWordCount.java
        // Create direct kafka stream with brokers and topics
        final JavaInputDStream<ConsumerRecord<String, String>> messages = KafkaUtils.createDirectStream(
                jssc,
                LocationStrategies.PreferConsistent(),
                ConsumerStrategies.<String,String>Subscribe(ImmutableList.of(topics), kafkaParams));


        // Get the lines, split them into words, count the words and print
        JavaDStream<String> lines = messages.map(tuple2 -> tuple2.value());
        JavaDStream<String> words = lines.flatMap(x -> Arrays.asList(SPACE.split(x)).iterator());
        JavaPairDStream<String, Integer> wordCounts = words.mapToPair(
                s -> new Tuple2<>(s, 1)).reduceByKey(
                (i1, i2) -> i1 + i2);
        wordCounts.print();


        // Start the computation
        jssc.start();
        jssc.awaitTermination();
    }

    public void produceMessages(KafkaProducer<String, String> producer, int messageCount, String topic) {

        int count = 0;
        while(count < messageCount) {
            final String value = "test" + count;
            producer.send(new ProducerRecord<>(topic, value));
            // LOG.info("Sent message: {}", value.toString());
            count++;
        }
    }


    public Map<String, Object> createConsumerConfig(String kafkaHostName, int kafkaPort) {
        final Map<String, Object> config = new HashMap<String, Object>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        config.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        config.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        return config;
    }


}
