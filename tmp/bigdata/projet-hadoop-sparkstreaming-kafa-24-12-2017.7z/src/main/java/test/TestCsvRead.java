package test;

import org.apache.commons.io.IOUtils;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.junit.Test;
import scala.collection.immutable.List;

import java.io.Serializable;
import java.util.Iterator;

public class TestCsvRead implements Serializable {

    @Test
    public void test() {

        final SparkConf conf = new SparkConf().setAppName("CSV Reader").setMaster("local[*]");
        final JavaSparkContext sc = new JavaSparkContext(conf);

        final SQLContext sqlContext = new SQLContext(sc);

        final StructType customSchema = new StructType(new StructField[] {
                new StructField("valueDate", DataTypes.StringType, true, Metadata.empty()),
                new StructField("name", DataTypes.StringType, true, Metadata.empty()),
                new StructField("value", DataTypes.DoubleType, true, Metadata.empty()),
        });


        final DataFrame df = sqlContext.read()
                .format("com.databricks.spark.csv")
                .option("delimiter", ";")
                .option("inferSchema", "false")
                .schema(customSchema)
                .option("header", "false")
                .load("file.csv");

        df.write().partitionBy("valueDate").mode(SaveMode.Overwrite).parquet("myparquet");

        final DataFrame df2 = sqlContext.read().parquet("myparquet");

        final List<StructField> structFieldList = df2.schema().toList();

        System.out.println("before foreachPartition");

        final JavaRDD<Row> rowJavaRDD = df2.toJavaRDD().repartition(10);

        System.out.println("rowJavaRDD partitions.size=" + rowJavaRDD.partitions().size());

        rowJavaRDD.foreachPartition(new VoidFunction<Iterator<Row>>() {

                    public void call(Iterator<Row> rowIterator) throws Exception {
                /*
                while(rowIterator.hasNext()) {
                    final Row row = rowIterator.next();
                    final String str = Thread.currentThread().getName() + " name=" + row.getString(0) + " value=" + row.getDouble(1) + " valueDate=" + row.getString(2);
                    System.out.println(str);
                }
                */
                        int cpt = 0;
                        while (rowIterator.hasNext()) {
                            final Row row = rowIterator.next();
                            cpt++;
                        }
                        final String str = Thread.currentThread().getName();
                        System.out.println(str + " cpt=" + cpt);
                    }
                });

        IOUtils.closeQuietly(sc);


        System.out.println("END");
    }

}
