/*
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package kafkaconsumer;

import com.github.sakserv.minicluster.config.ConfigVars;
import com.github.sakserv.minicluster.impl.KafkaLocalBroker;
import com.github.sakserv.minicluster.impl.ZookeeperLocalCluster;
import com.github.sakserv.propertyparser.PropertyParser;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.ConfigHelper;

import java.io.IOException;
import java.util.*;

public class SimpleTest {

    // Logger
    private static final Logger LOG = LoggerFactory.getLogger(SimpleTest.class);

    // Setup the property parser
    private static PropertyParser propertyParser = ConfigHelper.getPropertyParser();

    private static ZookeeperLocalCluster zookeeperLocalCluster;
    private static KafkaLocalBroker kafkaLocalBroker;
    
    @BeforeClass
    public static void setUp() throws Exception {

        zookeeperLocalCluster = createZookeeperLocalCluster();
        zookeeperLocalCluster.start();

        kafkaLocalBroker = createKafkaLocalBroker();
        kafkaLocalBroker.start();

    }

    private static KafkaLocalBroker createKafkaLocalBroker() {
        return new KafkaLocalBroker.Builder()
                .setKafkaHostname(propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY))
                .setKafkaPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_PORT_KEY)))
                .setKafkaBrokerId(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_TEST_BROKER_ID_KEY)))
                .setKafkaProperties(new Properties())
                .setKafkaTempDir(propertyParser.getProperty(ConfigVars.KAFKA_TEST_TEMP_DIR_KEY))
                .setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY))
                .build();
    }

    private static ZookeeperLocalCluster createZookeeperLocalCluster() {
        return new ZookeeperLocalCluster.Builder()
                .setPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.ZOOKEEPER_PORT_KEY)))
                .setTempDir(propertyParser.getProperty(ConfigVars.ZOOKEEPER_TEMP_DIR_KEY))
                .setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY))
                .build();
    }

    @AfterClass
    public static void tearDown() throws Exception {

        kafkaLocalBroker.stop();
        zookeeperLocalCluster.stop();
    }

    // https://developer.ibm.com/hadoop/2016/06/23/getting-started-with-kafka-2/
    @Test
    public void testKafkaLocalBroker() throws Exception {

        final String kafkaHostName = propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY);
        final String kafkaTopic = propertyParser.getProperty(ConfigVars.KAFKA_TEST_TOPIC_KEY);
        final Integer kafkaPort = kafkaLocalBroker.getKafkaPort();

        final KafkaProducer producer = new KafkaProducer(createProducerConfig(kafkaHostName, kafkaPort));
        for(int i = 0; i < 1000; i++) {
            final String key = "Message "+Integer.toString(i);
            final String value = "Message" + Integer.toString(i);
            final ProducerRecord record = new ProducerRecord(kafkaTopic, key, value);
            producer.send(record);
        }


        final KafkaConsumer consumer = new KafkaConsumer(createConsumerConfig(kafkaHostName, kafkaPort, "myGroup"));
        consumer.subscribe(Arrays.asList(kafkaTopic));

        int timeoutCount = 0;
        int messageCount = 0;
        while (true) {
            final ConsumerRecords records = consumer.poll(100);
            if(records.isEmpty()) {
                timeoutCount++;
            }
            else {
                final Iterator<ConsumerRecord> iterator = records.iterator();
                while(iterator.hasNext()) {
                    final ConsumerRecord record = iterator.next();
                    System.out.printf(" key = %s, value = %s \n", record.key(), record.value());
                    messageCount++;
                }
                timeoutCount = 0;
            }
            if (timeoutCount == 50) {
                System.out.println("Total No of Messages Consumed from the topic " + kafkaTopic +" is " + messageCount);
                System.out.println("Kafka Consumer Timeout, because no data is received from Kafka Topic");
                break;
            }
        }


    }

    public Map<String, Object> createConsumerConfig(String kafkaHostName, Integer kafkaPort, String groupId) {
        Map<String, Object> config = new HashMap<String, Object>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        config.put("group.id", "consumer-group-"+groupId);
        config.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        config.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        return config;
    }

    public Map<String, Object> createProducerConfig(String kafkaHostName, Integer kafkaPort) {
        Map<String, Object> config = new HashMap<String, Object>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        config.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        config.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        return config;
    }
}
