package genfile;

import org.apache.commons.io.IOUtils;

import java.io.*;

public class GenCsvFile {

    public static void main(String[]args) throws IOException {


        final String pathname =
                "D:\\dev\\hadoop-horton\\projet-hadoop\\file.csv";

        final String pathname2 =
                "D:\\dev\\hadoop-horton\\projet-hadoop\\filebig.csv";

        final byte[] content =
                IOUtils.toByteArray(new FileInputStream(new File(pathname)));

        FileOutputStream out = new FileOutputStream(pathname2);

        for(int i=0; i<100; i++) {
            out.write(content);
            out.flush();
        }
        out.close();
    }

}
