package kafkastream;

import java.util.Map;

public class CountryMessageSerializer extends JsonPOJOSerializer<AppTest.CountryMessage> {
    public CountryMessageSerializer() {}

    @SuppressWarnings("unchecked")
    @Override
    public void configure(Map<String, ?> props, boolean isKey) {
        tClass = AppTest.CountryMessage.class;
    }

}
