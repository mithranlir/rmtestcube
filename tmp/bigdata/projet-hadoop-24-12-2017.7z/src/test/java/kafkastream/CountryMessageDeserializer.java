package kafkastream;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

/**
 * Created by Romain on 28/11/2017.
 */
public class CountryMessageDeserializer extends JsonPOJODeserializer<AppTest.CountryMessage> {

    public CountryMessageDeserializer() {}

    @SuppressWarnings("unchecked")
    @Override
    public void configure(Map<String, ?> props, boolean isKey) {
        tClass = AppTest.CountryMessage.class;
    }

}