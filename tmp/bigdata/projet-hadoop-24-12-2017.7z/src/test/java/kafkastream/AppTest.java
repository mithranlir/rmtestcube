/*
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package kafkastream;

import com.github.sakserv.minicluster.config.ConfigVars;
import com.github.sakserv.minicluster.impl.KafkaLocalBroker;
import com.github.sakserv.minicluster.impl.ZookeeperLocalCluster;
import com.github.sakserv.propertyparser.PropertyParser;
import kafka.producer.KeyedMessage;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KStreamBuilder;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.processor.WallclockTimestampExtractor;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.ConfigHelper;

import java.io.*;
import java.util.*;

public class AppTest {

    // Logger
    private static final Logger LOG = LoggerFactory.getLogger(AppTest.class);

    // Setup the property parser
    private static PropertyParser propertyParser = ConfigHelper.getPropertyParser();

    private static ZookeeperLocalCluster zookeeperLocalCluster;
    private static KafkaLocalBroker kafkaLocalBroker;
    
    @BeforeClass
    public static void setUp() throws Exception {

        zookeeperLocalCluster = createZookeeperLocalCluster();
        zookeeperLocalCluster.start();

        kafkaLocalBroker = createKafkaLocalBroker();
        kafkaLocalBroker.start();

    }

    private static KafkaLocalBroker createKafkaLocalBroker() {
        return new KafkaLocalBroker.Builder()
                .setKafkaHostname(propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY))
                .setKafkaPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_PORT_KEY)))
                .setKafkaBrokerId(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_TEST_BROKER_ID_KEY)))
                .setKafkaProperties(new Properties())
                .setKafkaTempDir(propertyParser.getProperty(ConfigVars.KAFKA_TEST_TEMP_DIR_KEY))
                .setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY))
                .build();
    }

    private static ZookeeperLocalCluster createZookeeperLocalCluster() {
        return new ZookeeperLocalCluster.Builder()
                .setPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.ZOOKEEPER_PORT_KEY)))
                .setTempDir(propertyParser.getProperty(ConfigVars.ZOOKEEPER_TEMP_DIR_KEY))
                .setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY))
                .build();
    }

    @AfterClass
    public static void tearDown() throws Exception {

        kafkaLocalBroker.stop();
        zookeeperLocalCluster.stop();
    }

    // https://developer.ibm.com/hadoop/2016/06/23/getting-started-with-kafka-2/
    @Test
    public void testKafkaLocalBroker() throws Exception {

        Properties properties = getProperties(
                propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY), kafkaLocalBroker.getKafkaPort(),
                zookeeperLocalCluster.getZookeeperConnectionString()
        );

        System.out.println("Kafka Streams Demonstration");

        // Create an instance of StreamsConfig from the Properties instance
        StreamsConfig config = new StreamsConfig(properties);
        final Serde<String> stringSerde = Serdes.String();
        final Serde<Long> longSerde = Serdes.Long();

        // define countryMessageSerde
        final Serializer<CountryMessage> countryMessageSerializer = buildCountryMessageSerializer();
        final Deserializer<CountryMessage> countryMessageDeserializer = buildCountryMessageDeserializer();
        final Serde<CountryMessage> countryMessageSerde = Serdes.serdeFrom(countryMessageSerializer, countryMessageDeserializer);

        final String countryTopic = "countries";

        // building Kafka Streams Model
        KStreamBuilder kStreamBuilder = new KStreamBuilder();
        // the source of the streaming analysis is the topic with country messages
        KStream<String, CountryMessage> countriesStream =
                kStreamBuilder.stream(stringSerde, countryMessageSerde, countryTopic);

        // THIS IS THE CORE OF THE STREAMING ANALYTICS:
        // running count of countries per continent, published in topic RunningCountryCountPerContinent
        KTable<String,Long> runningCountriesCountPerContinent = countriesStream
                .selectKey((k, country) -> country.continent)
                .groupByKey(stringSerde, countryMessageSerde)
                .count("Counts");

        final String countTopic = "RunningCountryCountPerContinent";

        runningCountriesCountPerContinent.to(stringSerde, longSerde,  countTopic);
        //runningCountriesCountPerContinent.print(stringSerde, longSerde);

        System.out.println("Starting Kafka Streams Countries Example");
        KafkaStreams kafkaStreams = new KafkaStreams(kStreamBuilder, config);
        kafkaStreams.start();
        System.out.println("Now started CountriesStreams Example");

        final String kafkaHostName = propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY);
        final Integer kafkaPort = kafkaLocalBroker.getKafkaPort();

        final KafkaProducer producer = new KafkaProducer(createProducerConfig(kafkaHostName, kafkaPort));
        final InputStream in = this.getClass().getClassLoader().getResourceAsStream("countries2.csv");
        final BufferedReader br = new BufferedReader(new InputStreamReader(in));

        String lineStr;
        int cpt = 0;
        while ((lineStr = br.readLine()) != null) {
            if(cpt>0) {
                final CountryMessage countryMessage = buildCountryMessage(lineStr);
                final String key = countryMessage.code;
                final ProducerRecord record = new ProducerRecord(countryTopic, key, countryMessage);
                producer.send(record);
            }
            cpt++;
        }

        br.close();
        producer.flush();
        producer.close();


        final KafkaConsumer consumer = new KafkaConsumer(createCountConsumerConfig(kafkaHostName, kafkaPort, APP_ID));
        consumer.subscribe(Arrays.asList(countTopic));


        Thread.sleep(10000);
        consumerPoll(countTopic, consumer);
        Thread.sleep(10000);
        consumerPoll(countTopic, consumer);
        Thread.sleep(10000);
        consumerPoll(countTopic, consumer);

        System.out.println("END OF SLEEP");
    }

    private void consumerPoll(String countTopic, KafkaConsumer consumer) {
        int timeoutCount = 0;
        int messageCount = 0;
        while (true) {
            final ConsumerRecords records = consumer.poll(100);
            if(records.isEmpty()) {
                timeoutCount++;
            }
            else {
                final Iterator<ConsumerRecord> iterator = records.iterator();
                while(iterator.hasNext()) {
                    final ConsumerRecord record = iterator.next();
                    System.out.printf(" key = %s, value = %s \n", record.key(), record.value());
                    messageCount++;
                }
                timeoutCount = 0;
            }
            if (timeoutCount == 50) {
                System.out.println("Total No of Messages Consumed from the topic " + countTopic +" is " + messageCount);
                System.out.println("Kafka Consumer Timeout, because no data is received from Kafka Topic");
                break;
            }
        }
    }

    private Deserializer<CountryMessage> buildCountryMessageDeserializer() {
        Map< String, Object > deserdeProps = new HashMap< >();
        final Deserializer< CountryMessage > countryMessageDeserializer = new JsonPOJODeserializer< >();
        deserdeProps.put("JsonPOJOClass", CountryMessage.class);
        countryMessageDeserializer.configure(deserdeProps, false);
        return countryMessageDeserializer;
    }

    private Serializer<CountryMessage> buildCountryMessageSerializer() {
        Map< String, Object > serdeProps = new HashMap< >();
        final Serializer<CountryMessage> countryMessageSerializer = new JsonPOJOSerializer< >();
        serdeProps.put("JsonPOJOClass", CountryMessage.class);
        countryMessageSerializer.configure(serdeProps, false);
        return countryMessageSerializer;
    }

    private CountryMessage buildCountryMessage(String lineStr) {
        final String[] line = lineStr.split(";");
        final CountryMessage countryMessage = new CountryMessage();
        countryMessage.name = line[0];
        countryMessage.code = line[1];
        countryMessage.continent = line[2];
        countryMessage.population = Integer.parseInt(line[4]);
        countryMessage.size = Integer.parseInt(line[5]);
        return countryMessage;
    }

    private static final String APP_ID = "countries-streaming-analysis-app";

    static public class CountryMessage {
        public String code;
        public String name;
        public int population;
        public int size;
        public String continent;
    }

    public Map<String, Object> createProducerConfig(String kafkaHostName, Integer kafkaPort) {
        Map<String, Object> config = new HashMap<String, Object>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        config.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        config.put("value.serializer","kafkastream.CountryMessageSerializer");
        return config;
    }

    public Map<String, Object> createCountConsumerConfig(String kafkaHostName, Integer kafkaPort, String groupId) {
        Map<String, Object> config = new HashMap<String, Object>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        config.put("group.id", groupId + "-consumer");
        config.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        config.put("value.deserializer", "org.apache.kafka.common.serialization.LongDeserializer");
        return config;
    }


    private static Properties getProperties(String kafkaHostName, Integer kafkaPort, String zookeeperConnection) {
        Properties settings = new Properties();
        // Set a few key parameters
        settings.put(StreamsConfig.APPLICATION_ID_CONFIG, APP_ID);
        // Kafka bootstrap server (broker to talk to); ubuntu is the host name for my VM running Kafka, port 9092 is where the (single) broker listens
        settings.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        // Apache ZooKeeper instance keeping watch over the Kafka cluster; ubuntu is the host name for my VM running Kafka, port 2181 is where the ZooKeeper listens
        settings.put(StreamsConfig.ZOOKEEPER_CONNECT_CONFIG, zookeeperConnection);
        // default serdes for serialzing and deserializing key and value from and to streams in case no specific Serde is specified
        settings.put(StreamsConfig.KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        settings.put(StreamsConfig.VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        settings.put(StreamsConfig.STATE_DIR_CONFIG, "C:\\temp");
        // to work around exception Exception in thread "StreamThread-1" java.lang.IllegalArgumentException: Invalid timestamp -1
        // at org.apache.kafka.clients.producer.ProducerRecord.<init>(ProducerRecord.java:60)
        // see: https://groups.google.com/forum/#!topic/confluent-platform/5oT0GRztPBo
        settings.put(StreamsConfig.TIMESTAMP_EXTRACTOR_CLASS_CONFIG, WallclockTimestampExtractor.class);
        return settings;
    }




}
