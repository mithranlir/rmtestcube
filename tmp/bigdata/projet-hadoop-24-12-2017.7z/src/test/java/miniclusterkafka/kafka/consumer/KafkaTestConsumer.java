/*
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package miniclusterkafka.kafka.consumer;

import kafka.api.FetchRequest;
import kafka.api.FetchRequestBuilder;
import kafka.common.ErrorMapping;
import kafka.javaapi.*;
import kafka.javaapi.consumer.SimpleConsumer;
import kafka.message.MessageAndOffset;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class KafkaTestConsumer {

    // Logger
    private static final Logger LOG = LoggerFactory.getLogger(KafkaTestConsumer.class);

    long numRead = 0;
    private List<String> m_replicaBrokers = new ArrayList<String>();

    public void consumeMessages(long maxReads, String topic, int partition, List<String> seedBrokers, int port) throws Exception {
        // find the meta data about the topic and partition we are interested in
        //
        final PartitionMetadata metadata = findLeader(seedBrokers, port, topic, partition);
        if (metadata == null || metadata.leader() == null) {
            LOG.info("Can't find metadata for Topic and Partition. Exiting");
            return;
        }
        String leadBroker = metadata.leader().host();
        final String clientName = "Client_" + topic + "_" + partition;

        final int timeout = 100000;
        final int bufferSize = 64 * 1024;
        SimpleConsumer consumer = new SimpleConsumer(leadBroker, port, timeout, bufferSize, clientName);
        long readOffset = 0L;

        int numErrors = 0;
        while (maxReads > 0) {
            if (consumer == null) {
                consumer = new SimpleConsumer(leadBroker, port, timeout, bufferSize, clientName);
            }
            final FetchRequest req = createFetchRequest(topic, partition, clientName, readOffset);
            final FetchResponse fetchResponse = consumer.fetch(req);

            if (fetchResponse.hasError()) {
                numErrors++;
                // Something went wrong!
                final short code = fetchResponse.errorCode(topic, partition);
                LOG.info("Error fetching data from the Broker: {} Reason: {}", leadBroker, code);
                if (numErrors > 5) {
                    break;
                }
                if (code == ErrorMapping.OffsetOutOfRangeCode())  {
                    // We asked for an invalid offset. For simple case ask for the last element to reset
                    readOffset = 0L;
                }
                consumer.close();
                consumer = null;
                leadBroker = findNewLeader(leadBroker, topic, partition, port);
            }
            else {
                numErrors = 0;
                for (MessageAndOffset messageAndOffset : fetchResponse.messageSet(topic, partition)) {
                    final long currentOffset = messageAndOffset.offset();
                    if (currentOffset < readOffset) {
                        LOG.info("Found an old offset: {} Expecting: {}", currentOffset, readOffset);
                    }
                    else {
                        readOffset = messageAndOffset.nextOffset();
                        final byte[] bytes = getPayloadContent(messageAndOffset);
                        LOG.info("Consumed: {}: {}", String.valueOf(messageAndOffset.offset()), new String(bytes, "UTF-8"));
                        numRead++;
                        maxReads--;
                    }
                }

                if (numRead == 0) {
                    try {
                        Thread.sleep(1000);
                    }
                    catch (InterruptedException ie) {
                    }
                }
            }

        }
        if (consumer != null) consumer.close();
    }

    private byte[] getPayloadContent(MessageAndOffset messageAndOffset) {
        final ByteBuffer payload = messageAndOffset.message().payload();

        final byte[] bytes = new byte[payload.limit()];
        payload.get(bytes);
        return bytes;
    }

    private FetchRequest createFetchRequest(String topic, int partition, String clientName, long readOffset) {
        return new FetchRequestBuilder()
                        .clientId(clientName)
                        .addFetch(topic, partition, readOffset, 100000) // Note: this fetchSize of 100000 might need to be increased if large batches are written to Kafka
                        .build();
    }

    private String findNewLeader(String oldLeader, String topic, int partition, int port) throws Exception {
        for (int i = 0; i < 3; i++) {
            boolean goToSleep = false;
            final PartitionMetadata metadata = findLeader(m_replicaBrokers, port, topic, partition);
            if (metadata == null || metadata.leader() == null) {
                goToSleep = true;
            }
            else if (oldLeader.equalsIgnoreCase(metadata.leader().host()) && i == 0) {
                // first time through if the leader hasn't changed give ZooKeeper a second to recover
                // second time, assume the broker did recover before failover, or it was a non-Broker issue
                //
                goToSleep = true;
            }
            else {
                return metadata.leader().host();
            }
            if (goToSleep) {
                try {
                    Thread.sleep(1000);
                }
                catch (InterruptedException ie) {
                }
            }
        }
        LOG.info("Unable to find new leader after Broker failure. Exiting");
        throw new Exception("Unable to find new leader after Broker failure. Exiting");
    }

    private PartitionMetadata findLeader(List<String> seedBrokers, int port, String topic, int partition) {
        final PartitionMetadata returnMetaData = getPartitionMetadata(seedBrokers, port, topic, partition);
        if (returnMetaData != null) {
            m_replicaBrokers.clear();
            for (kafka.cluster.BrokerEndPoint replica : returnMetaData.replicas()) {
                m_replicaBrokers.add(replica.host());
            }
        }
        return returnMetaData;
    }

    private PartitionMetadata getPartitionMetadata(List<String> seedBrokers, int port, String topic, int partition) {
        for (String seed : seedBrokers) {
            SimpleConsumer consumer = null;
            try {
                consumer = new SimpleConsumer(seed, port, 100000, 64 * 1024, "leaderLookup");
                final List<String> topics = Collections.singletonList(topic);
                final TopicMetadataRequest req = new TopicMetadataRequest(topics);
                final TopicMetadataResponse resp = consumer.send(req);
                final List<TopicMetadata> metaData = resp.topicsMetadata();
                for (TopicMetadata item : metaData) {
                    for (PartitionMetadata part : item.partitionsMetadata()) {
                        if (part.partitionId() == partition) {
                            return part; // found
                        }
                    }
                }
            } catch (Exception e) {
                LOG.info("Error communicating with Broker [{}] to find Leader for [{},{}] Reason: {}", seed, topic, partition, e);
            }
            finally {
                if (consumer != null) {
                    consumer.close();
                }
            }
        }
        return null;
    }

    public long getNumRead() {
        return numRead;
    }
}
