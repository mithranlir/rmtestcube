/*
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package miniclusterkafka;

import com.github.sakserv.minicluster.config.ConfigVars;
import com.github.sakserv.minicluster.impl.KafkaLocalBroker;
import com.github.sakserv.minicluster.impl.ZookeeperLocalCluster;
import miniclusterkafka.kafka.consumer.KafkaTestConsumer;
import miniclusterkafka.kafka.producer.KafkaSimpleTestProducer;
import com.github.sakserv.propertyparser.PropertyParser;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.ConfigHelper;

import java.util.ArrayList;
import java.util.List;

import static utils.ConfigHelper.buildKafkaLocalBroker;

public class KafkaLocalBrokerIntegrationTest {

    // Logger
    private static final Logger LOG = LoggerFactory.getLogger(KafkaLocalBrokerIntegrationTest.class);

    // Setup the property parser
    private static PropertyParser propertyParser = ConfigHelper.getPropertyParser();

    private static ZookeeperLocalCluster zookeeperLocalCluster;
    private static KafkaLocalBroker kafkaLocalBroker;
    
    @BeforeClass
    public static void setUp() throws Exception {

        ConfigHelper.setHadoopHomeDir();

        zookeeperLocalCluster = createZookeeperLocalCluster();
        zookeeperLocalCluster.start();

        kafkaLocalBroker = createKafkaLocalBroker();
        kafkaLocalBroker.start();

    }

    private static KafkaLocalBroker createKafkaLocalBroker() {
        return buildKafkaLocalBroker(propertyParser);
    }

    private static ZookeeperLocalCluster createZookeeperLocalCluster() {
        return ConfigHelper.buildZookeeperLocalCluster(propertyParser);
    }


    @AfterClass
    public static void tearDown() throws Exception {

        kafkaLocalBroker.stop();
        zookeeperLocalCluster.stop();
    }

    @Test
    public void testKafkaLocalBroker() throws Exception {

        // Producer 
        final KafkaSimpleTestProducer kafkaTestProducer = createKafkaSimpleTestProducer();
        kafkaTestProducer.produceMessages();

        // Consumer
        final List<String> seeds = new ArrayList<String>();
        final String kafkaHostname = kafkaLocalBroker.getKafkaHostname();
        seeds.add(kafkaHostname);
        final KafkaTestConsumer kafkaTestConsumer = new KafkaTestConsumer();

        consumeMessages(seeds, kafkaTestConsumer);


        // Assert num of messages produced = num of message consumed
        final long expectedMessageCount = Long.parseLong(propertyParser.getProperty(ConfigVars.KAFKA_TEST_MESSAGE_COUNT_KEY));
        Assert.assertEquals(expectedMessageCount,
                kafkaTestConsumer.getNumRead());

    }

    private void consumeMessages(List<String> seeds, KafkaTestConsumer kafkaTestConsumer) throws Exception {
        final int messageCount = Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_TEST_MESSAGE_COUNT_KEY));
        final String kafkaTopic = propertyParser.getProperty(ConfigVars.KAFKA_TEST_TOPIC_KEY);
        final Integer kafkaPort = kafkaLocalBroker.getKafkaPort();
        kafkaTestConsumer.consumeMessages(
                messageCount,
                kafkaTopic,
                0,
                seeds,
                kafkaPort);
    }

    private KafkaSimpleTestProducer createKafkaSimpleTestProducer() {
        final String kafkaHostName = propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY);
        final int kafkaPort = Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_PORT_KEY));
        final String kafkaTopic = propertyParser.getProperty(ConfigVars.KAFKA_TEST_TOPIC_KEY);
        final int messageCount = Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_TEST_MESSAGE_COUNT_KEY));
        return new KafkaSimpleTestProducer.Builder()
                .setKafkaHostname(kafkaHostName)
                .setKafkaPort(kafkaPort)
                .setTopic(kafkaTopic)
                .setMessageCount(messageCount)
                .build();
    }

}
