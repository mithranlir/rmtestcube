package kafkastream4;

public class Referential {

    private Long id;
    private String name;

    public Referential(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Referential() {

    }

    public String getName() {
        return name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }
}
