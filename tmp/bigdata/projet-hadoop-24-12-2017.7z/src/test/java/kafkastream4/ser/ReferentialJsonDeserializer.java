package kafkastream4.ser;

import kafkastream4.Referential;

public class ReferentialJsonDeserializer extends JsonDeserializer<Referential> {
    public ReferentialJsonDeserializer() {
        super(Referential.class);
    }
}