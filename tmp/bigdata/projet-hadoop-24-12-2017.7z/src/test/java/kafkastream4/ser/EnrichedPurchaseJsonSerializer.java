package kafkastream4.ser;

import kafkastream4.BrutPurchase;

public class EnrichedPurchaseJsonSerializer extends JsonSerializer<BrutPurchase> {
}
