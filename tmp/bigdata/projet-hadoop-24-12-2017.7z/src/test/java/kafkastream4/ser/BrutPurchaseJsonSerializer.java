package kafkastream4.ser;

import kafkastream4.BrutPurchase;

public class BrutPurchaseJsonSerializer extends JsonSerializer<BrutPurchase> {
}
