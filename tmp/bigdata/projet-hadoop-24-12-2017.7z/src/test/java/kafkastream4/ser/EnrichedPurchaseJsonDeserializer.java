package kafkastream4.ser;

import kafkastream4.EnrichedPurchase;

public class EnrichedPurchaseJsonDeserializer extends JsonDeserializer<EnrichedPurchase> {
    public EnrichedPurchaseJsonDeserializer() {
        super(EnrichedPurchase.class);
    }
}