package kafkastream4;

import java.math.BigDecimal;

public class BrutPurchase {

    public BrutPurchase() {
    }

    public BrutPurchase(Long id, BigDecimal price) {
        this.id = id;
        this.price = price;
    }

    private Long id;
    private BigDecimal price;

    public BigDecimal getPrice() {
        return price;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}
