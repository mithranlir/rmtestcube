package kafkastream4;

import com.github.sakserv.minicluster.config.ConfigVars;
import com.github.sakserv.minicluster.impl.KafkaLocalBroker;
import com.github.sakserv.minicluster.impl.ZookeeperLocalCluster;
import com.github.sakserv.propertyparser.PropertyParser;
import kafkastream2.IntegrationTestUtils;
import kafkastream4.ser.*;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.*;
import org.apache.kafka.common.utils.Utils;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KStreamBuilder;
import org.apache.kafka.streams.kstream.KTable;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.ConfigHelper;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import static org.assertj.core.api.Assertions.assertThat;

public class EnrichIntegrationTest {

    // Logger
    private static final Logger LOG = LoggerFactory.getLogger(EnrichIntegrationTest.class);

    // Setup the property parser
    private static PropertyParser propertyParser = ConfigHelper.getPropertyParser();

    private static ZookeeperLocalCluster zookeeperLocalCluster;
    private static KafkaLocalBroker kafkaLocalBroker;

    @BeforeClass
    public static void setUp() throws Exception {

        zookeeperLocalCluster = createZookeeperLocalCluster();
        zookeeperLocalCluster.start();

        kafkaLocalBroker = createKafkaLocalBroker();
        kafkaLocalBroker.start();

    }

    private static KafkaLocalBroker createKafkaLocalBroker() {
        return new KafkaLocalBroker.Builder()
                .setKafkaHostname(propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY))
                .setKafkaPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_PORT_KEY)))
                .setKafkaBrokerId(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_TEST_BROKER_ID_KEY)))
                .setKafkaProperties(new Properties())
                .setKafkaTempDir(propertyParser.getProperty(ConfigVars.KAFKA_TEST_TEMP_DIR_KEY))
                .setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY))
                .build();
    }

    private static ZookeeperLocalCluster createZookeeperLocalCluster() {
        return new ZookeeperLocalCluster.Builder()
                .setPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.ZOOKEEPER_PORT_KEY)))
                .setTempDir(propertyParser.getProperty(ConfigVars.ZOOKEEPER_TEMP_DIR_KEY))
                .setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY))
                .build();
    }

    @AfterClass
    public static void tearDown() throws Exception {
        kafkaLocalBroker.stop();
        zookeeperLocalCluster.stop();
        kafkaLocalBroker.cleanUp();
    }

    public static final String REFERENTIAL_TOPIC = "referential";
    public static final String PURCHASES_TOPIC = "purchases";
    public static final String PURCHASES_BY_PRODUCT_ID_TOPIC = "purchases-by-product-id";
    public static final String ENRICHED_PURCHASES_TOPIC = "enriched-purchases";

    @Test
    public void test() throws Exception {

        final String kafkaHostName = propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY);
        final Integer kafkaPort = kafkaLocalBroker.getKafkaPort();

        final Properties streamsConfiguration = createStreamsConfiguration(kafkaHostName, kafkaPort);

        final KStreamBuilder builder = new KStreamBuilder();

        final Serde<BrutPurchase> brutPurchaseSerde = Serdes.serdeFrom(new JsonSerializer<>(), new JsonDeserializer<>(BrutPurchase.class));
        final Serde<EnrichedPurchase> enrichedPurchaseSerde = Serdes.serdeFrom(new JsonSerializer<>(), new JsonDeserializer<>(EnrichedPurchase.class));
        final Serde<Referential> referentialSerde = Serdes.serdeFrom(new JsonSerializer<>(), new JsonDeserializer<>(Referential.class));

        final KStream<String, BrutPurchase> purchases = builder.stream(Serdes.String(), brutPurchaseSerde, PURCHASES_TOPIC);
        final KTable<String, Referential> referential = builder.table(Serdes.String(), referentialSerde, REFERENTIAL_TOPIC, "ReferentialStore");

        final KStream<String, EnrichedPurchase> enriched = purchases
                .map((k, v) -> new KeyValue<>(v.getId().toString(), v))
                .through(Serdes.String(), brutPurchaseSerde, PURCHASES_BY_PRODUCT_ID_TOPIC)
                .leftJoin(referential, (purchase, ref) -> {
                    if (ref == null) {
                        return new EnrichedPurchase(purchase.getId(), "REF INCONNUE", purchase.getPrice());
                    }
                    else {
                        return new EnrichedPurchase(purchase.getId(), ref.getName(), purchase.getPrice());
                    }
                });

        enriched.to(Serdes.String(), enrichedPurchaseSerde, ENRICHED_PURCHASES_TOPIC);

        final KafkaStreams streams = new KafkaStreams(builder, streamsConfiguration);
        streams.start();


        final List<KeyValue<String, BrutPurchase>> brutPurchasesKV = Arrays.asList(
                new KeyValue("11111", new BrutPurchase(1L, new BigDecimal(10.0))),
                new KeyValue("13333", new BrutPurchase(2L, new BigDecimal(30.0))),
                new KeyValue("14444", new BrutPurchase(3L, new BigDecimal(60.0))),
                new KeyValue("15555",  new BrutPurchase(4L, new BigDecimal(100.0)))
        );
        final Properties brutPurchaseProducerConfig = createBrutPurchaseProducerConfig(kafkaHostName, kafkaPort);
        IntegrationTestUtils.produceKeyValuesSynchronously(PURCHASES_TOPIC, brutPurchasesKV, brutPurchaseProducerConfig);

        final List<KeyValue<String, Referential>> referentialsKV = Arrays.asList(
                new KeyValue("1", new Referential(1L, "produit1")),
                new KeyValue("2", new Referential(2L, "produit2")),
                new KeyValue("3", new Referential(3L, "produit3"))
        );
        final Properties referentialProducerConfig = createReferentialProducerConfig(kafkaHostName, kafkaPort);
        IntegrationTestUtils.produceKeyValuesSynchronously( REFERENTIAL_TOPIC, referentialsKV, referentialProducerConfig);

        final Properties enrichedPurchaseConsumerConfig = createEnrichedPurchaseConsumerConfig(kafkaHostName, kafkaPort);
        final List<KeyValue<String, EnrichedPurchase>> actual = IntegrationTestUtils.waitUntilMinKeyValueRecordsReceived(
                enrichedPurchaseConsumerConfig,
                ENRICHED_PURCHASES_TOPIC, 4);

        final List<KeyValue<String, EnrichedPurchase>> expected = Arrays.asList(
                new KeyValue<>("1", new EnrichedPurchase(1L, "produit1", new BigDecimal(10.0))),
                new KeyValue<>("2", new EnrichedPurchase(2L, "produit2", new BigDecimal(30.0))),
                new KeyValue<>("3", new EnrichedPurchase(3L, "produit3", new BigDecimal(60.0))),
                new KeyValue<>("4", new EnrichedPurchase(4L, "REF INCONNUE", new BigDecimal(100.0)))
                );

        streams.close();

        assertThat(actual).containsAll(expected);
    }


    private Properties createEnrichedPurchaseConsumerConfig(String kafkaHostName, Integer kafkaPort) {
        Properties consumerConfig = new Properties();
        consumerConfig.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        consumerConfig.put(ConsumerConfig.GROUP_ID_CONFIG, "join-lambda-integration-test-standard-consumer");
        consumerConfig.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        consumerConfig.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        consumerConfig.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, EnrichedPurchaseJsonDeserializer.class);
        return consumerConfig;
    }

    private Properties createBrutPurchaseProducerConfig(String kafkaHostName, Integer kafkaPort) throws java.util.concurrent.ExecutionException, InterruptedException {
        final Properties config = new Properties();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.RETRIES_CONFIG, 0);
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, BrutPurchaseJsonSerializer.class);
        return config;
    }

    private Properties createReferentialProducerConfig(String kafkaHostName, Integer kafkaPort) throws java.util.concurrent.ExecutionException, InterruptedException {
        final Properties config = new Properties();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.RETRIES_CONFIG, 0);
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ReferentialJsonSerializer.class);
        return config;
    }

    private Properties createStreamsConfiguration(String kafkaHostName, Integer kafkaPort) {
        Properties streamsConfiguration = new Properties();
        streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG,  "enrichissement-achats");
        streamsConfiguration.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaHostName + ":" + kafkaPort);
        // The commit interval for flushing records to state stores and downstream must be lower than
        // this integration test's timeout (30 secs) to ensure we observe the expected processing results.
        streamsConfiguration.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, 10 * 1000);
        streamsConfiguration.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        // Use a temporary directory for storing state, which will be automatically removed after the test.
        streamsConfiguration.put(StreamsConfig.STATE_DIR_CONFIG, tempDirectory().getAbsolutePath());
        return streamsConfiguration;
    }


    public static File tempDirectory(final Path parent, String prefix) {
        final File file;
        prefix = prefix == null ? "kafka-" : prefix;
        try {
            file = parent == null ?
                    Files.createTempDirectory(prefix).toFile() : Files.createTempDirectory(parent, prefix).toFile();
        } catch (final IOException ex) {
            throw new RuntimeException("Failed to create a temp dir", ex);
        }
        file.deleteOnExit();

        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                Utils.delete(file);
            }
        });

        return file;
    }

    public static File tempDirectory(final String prefix) {
        return tempDirectory(null, prefix);
    }

    /**
     * Create a temporary relative directory in the default temporary-file directory with a
     * prefix of "kafka-"
     *
     * @return the temporary directory just created.
     */
    public static File tempDirectory() {
        return tempDirectory(null);
    }


}
