package miniclusterknox;

import com.github.sakserv.minicluster.config.ConfigVars;
import com.github.sakserv.minicluster.impl.HdfsLocalCluster;
import com.github.sakserv.minicluster.impl.KnoxLocalCluster;
import com.github.sakserv.minicluster.impl.ZookeeperLocalCluster;
import com.github.sakserv.propertyparser.PropertyParser;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utils.ConfigHelper;
import utils.NoCertificateHelper;

import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import static org.junit.Assert.assertEquals;

public class HdfsTestWithUrlCustomization {

    // Logger
    private static final Logger LOG = LoggerFactory.getLogger(HdfsTestWithUrlCustomization.class);

    // Setup the property parser
    private static PropertyParser propertyParser = ConfigHelper.getPropertyParser();

    private static ZookeeperLocalCluster zookeeperLocalCluster;
    private static HdfsLocalCluster hdfsCluster;
    private static KnoxLocalCluster knoxCluster;

    private static final String TEST_USER = "guest";

    @BeforeClass
    public static void setUp() throws Exception {

        ConfigHelper.setHadoopHomeDir();

        // We need Zookeeper/HBase/HBaseRest for Knox
        zookeeperLocalCluster = ConfigHelper.buildZookeeperLocalCluster(propertyParser);
        zookeeperLocalCluster.start();

        // We need HDFS/WEBHDFS for Knox
        hdfsCluster = ConfigHelper.buildHdfsLocalCluster(propertyParser);
        hdfsCluster.start();

        knoxCluster = ConfigHelper.buildKnoxLocalCluster(propertyParser);
        knoxCluster.start();
    }


    @AfterClass
    public static void tearDown() throws Exception {
        zookeeperLocalCluster.stop();
        hdfsCluster.stop();
        knoxCluster.stop();
    }

    private URL buildURL(String url) throws MalformedURLException {
        final String customUrl = url + "&user.name=" + TEST_USER;
        return new URL(customUrl);
    }

    @Test
    public void testKnoxWithWebhdfs() throws Exception {


        final String knoxServer = "localhost";
        final String hdfsNameNodePort = propertyParser.getProperty(ConfigVars.HDFS_NAMENODE_HTTP_PORT_KEY);
        final String knoxPort = propertyParser.getProperty(ConfigVars.KNOX_PORT_KEY);
        final String testFilePath = propertyParser.getProperty(ConfigVars.HDFS_TEST_FILE_KEY);
        final String testFileContent = propertyParser.getProperty(ConfigVars.HDFS_TEST_STRING_KEY);

        final String webhdfsPath = "webhdfs/v1";
        final String knoxWebhdfsGatewayPath = "gateway/mycluster/webhdfs/v1";

        // Write a file to HDFS containing the test string
        FileSystem hdfsFsHandle = hdfsCluster.getHdfsFileSystemHandle();
        try (FSDataOutputStream writer = hdfsFsHandle.create(new Path(testFilePath))) {
            writer.write(testFileContent.getBytes("UTF-8"));
            writer.flush();
        }


        // Read the file throught webhdfs

        URL url = buildURL(
                String.format("http://%s:%s/%s?op=GETHOMEDIRECTORY", knoxServer, hdfsNameNodePort, webhdfsPath));
        URLConnection connection = url.openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");
        try (BufferedReader response = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line = response.readLine();
            assertEquals("{\"Path\":\"/user/guest\"}", line);
        }

        url = buildURL(
                String.format("http://%s:%s/%s%s?op=OPEN", knoxServer, hdfsNameNodePort, webhdfsPath, testFilePath));
        connection = url.openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");
        try (BufferedReader response = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line = response.readLine();
            response.close();
            assertEquals(testFileContent, line);
        }


        // Knox clients need self trusted certificates in tests
        NoCertificateHelper.defaultBlindTrust();


        // Read the file throught Knox

        url = buildURL(
                String.format("https://%s:%s/%s?op=GETHOMEDIRECTORY", knoxServer, knoxPort, knoxWebhdfsGatewayPath));

        connection = url.openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");
        try (BufferedReader response = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line = response.readLine();
            assertEquals("{\"Path\":\"/user/guest\"}", line);
        }

        url = buildURL(
                String.format("https://%s:%s/%s/%s?op=OPEN", knoxServer, knoxPort, knoxWebhdfsGatewayPath, testFilePath));
        connection = url.openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");
        try (BufferedReader response = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line = response.readLine();
            response.close();
            assertEquals(testFileContent, line);
        }
    }



}
