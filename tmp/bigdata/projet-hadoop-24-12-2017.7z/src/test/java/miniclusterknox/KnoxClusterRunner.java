package miniclusterknox;

import com.github.sakserv.minicluster.config.ConfigVars;
import com.github.sakserv.minicluster.impl.HdfsLocalCluster;
import com.github.sakserv.minicluster.impl.KnoxLocalCluster;
import com.github.sakserv.minicluster.impl.ZookeeperLocalCluster;

import com.github.sakserv.propertyparser.PropertyParser;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import utils.ConfigHelper;
import utils.NoCertificateHelper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import static org.junit.Assert.assertEquals;

public class KnoxClusterRunner {

    private static final String TEST_USER = "guest";

    public static final void main(String... args) throws Exception {


        final PropertyParser propertyParser = ConfigHelper.getPropertyParser();


        final String testFilePath = propertyParser.getProperty(ConfigVars.HDFS_TEST_FILE_KEY);
        final String testFileContent = propertyParser.getProperty(ConfigVars.HDFS_TEST_STRING_KEY);

        ConfigHelper.setHadoopHomeDir();

        ZookeeperLocalCluster zookeeperLocalCluster = ConfigHelper.buildZookeeperLocalCluster(propertyParser);
        zookeeperLocalCluster.start();

        HdfsLocalCluster hdfsCluster = ConfigHelper.buildHdfsLocalCluster(propertyParser);
        hdfsCluster.start();

        KnoxLocalCluster  knoxCluster = ConfigHelper.buildKnoxLocalCluster(propertyParser);
        knoxCluster.start();


        // Write a file to HDFS containing the test string
        FileSystem hdfsFsHandle = hdfsCluster.getHdfsFileSystemHandle();
        try (FSDataOutputStream writer = hdfsFsHandle.create(new Path(testFilePath))) {
            writer.write(testFileContent.getBytes("UTF-8"));
            writer.flush();
        }


        /*
        // Knox clients need self trusted certificates in tests
        NoCertificateHelper.defaultBlindTrust();

        final String knoxServer = "localhost";
        final String knoxPort = propertyParser.getProperty(ConfigVars.KNOX_PORT_KEY);
        final String knoxWebhdfsGatewayPath = "gateway/mycluster/webhdfs/v1";

        URL url = buildURL(
                String.format("https://%s:%s/%s/tmp/testing?op=GETFILESTATUS", knoxServer, knoxPort, knoxWebhdfsGatewayPath));

        URLConnection connection = url.openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");
        try (BufferedReader response = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line = response.readLine();
            System.out.println(line);
        }

        url = buildURL(
                String.format("https://%s:%s/%s/tmp/testing?op=LISTSTATUS", knoxServer, knoxPort, knoxWebhdfsGatewayPath));

        connection = url.openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");
        try (BufferedReader response = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line = response.readLine();
            System.out.println(line);
        }
        */


        // zookeeperLocalCluster.stop();
        // hdfsCluster.stop();
        // knoxCluster.stop();
        System.out.println("END");
    }


    private static URL buildURL(String url) throws MalformedURLException {
        final String customUrl = url + "&user.name=" + TEST_USER;
        return new URL(customUrl);
    }
}
