package mygroup.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import mygroup.domain.FileDTO;
import mygroup.repository.RemoteFileRepository;

import java.io.IOException;
import java.util.List;

@Service
public class FileServiceImpl implements FileService {

    private RemoteFileRepository fileRepository;

    @Autowired
    public FileServiceImpl(RemoteFileRepository fileRepository) {
        this.fileRepository = fileRepository;
    }

    @Override
    public List<FileDTO> getFiles(String parentPath) throws IOException {
        return fileRepository.list(parentPath);
    }

    @Override
    public String getParentPath(String path) {
        if(path == null || path.isEmpty() || path.equals("/")) {
            return null;
        }
        if(path.endsWith("/")) {
            path = path.substring(0, path.length()-1);
        }
        if(path.contains("/")) {
            return path.substring(0, path.lastIndexOf("/"));
        }
        return null;
    }
}
