package mygroup.service;

import mygroup.domain.FileDTO;

import java.io.IOException;
import java.util.List;

public interface FileService {
    List<FileDTO> getFiles(String parentPath) throws IOException;
    String getParentPath(String path);
}
