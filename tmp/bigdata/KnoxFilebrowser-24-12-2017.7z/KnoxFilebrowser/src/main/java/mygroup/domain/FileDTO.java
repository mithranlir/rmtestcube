package mygroup.domain;

public class FileDTO  {

    private String id;
    private String name;
    private String contentLength;
    private String isdir;
    private String modificationTime;
    private String permission;
    private String owner;
    private String group;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContentLength() {
        return contentLength;
    }

    public void setLength(String contentLength) {
        this.contentLength = contentLength;
    }

    public String getIsdir() {
        return isdir;
    }

    public void setIsdir(String isdir) {
        this.isdir = isdir;
    }

    public String getModificationTime() {
        return modificationTime;
    }

    public void setModificationTime(String modificationTime) {
        this.modificationTime = modificationTime;
    }

    public String getPermission() {
        return permission;
    }

    public void setPermission(String permission) {
        this.permission = permission;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    @Override
    public String toString() {
        return "FileDTO{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", contentLength=" + contentLength +
                ", isdir=" + isdir +
                ", modificationTime=" + modificationTime +
                ", permission='" + permission + '\'' +
                ", owner='" + owner + '\'' +
                ", group='" + group + '\'' +
                '}';
    }
}
