package mygroup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import mygroup.service.FileService;

import java.io.IOException;

@Controller
@RequestMapping({"/files", "/"})
public class FileController {

    private FileService fileService;

    @Autowired
    public FileController(FileService fileService) {
        this.fileService = fileService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView view(@RequestParam(value = "p", required = false) String path) throws IOException {
        final ModelAndView mav = new ModelAndView("files");
        mav.addObject("current", path);
        mav.addObject("files", fileService.getFiles(path));
        mav.addObject("parent", fileService.getParentPath(path));
        return mav;
    }


}
