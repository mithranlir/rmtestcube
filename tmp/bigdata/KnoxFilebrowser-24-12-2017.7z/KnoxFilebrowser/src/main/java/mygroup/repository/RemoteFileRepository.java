package mygroup.repository;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import mygroup.domain.FileDTO;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
public class RemoteFileRepository {

    private final String knoxServer = "localhost";
    private final String knoxPort = "8888";
    private final String knoxWebhdfsGatewayPath = "gateway/mycluster/webhdfs/v1";

    private static final String TEST_USER = "guest";

    private List<String> authorizedRootPaths = Arrays.asList("tmp");


    public RemoteFileRepository() throws KeyManagementException, NoSuchAlgorithmException {
        NoCertificateHelper.defaultBlindTrust();
    }

    public List<FileDTO> list(String parentPath) throws IOException {
        if(parentPath == null || parentPath.equals("/")) {
            // show the default directories...
            final List<FileDTO> result = new ArrayList<>();
            for(String path : authorizedRootPaths) {
                final FileDTO status = getStatus(path);
                if(status != null) {
                    result.add(status);
                }
            }
            return result;
        }
        return listInternal(parentPath);
    }

    public List<FileDTO> listInternal(String parentPath) throws IOException {

        final ObjectMapper mapper = new ObjectMapper();

        final URL url = buildListStatusURL(parentPath);
        System.out.println("URL=" + url);

        final URLConnection connection = url.openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");

        final List<FileDTO> result = new ArrayList<>();
        try (BufferedReader response = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            final String line = response.readLine();
            System.out.println(line);
            response.close();

            final AllFileStatus allFileStatus = mapper.readValue(line, AllFileStatus.class);
            for(OneFileStatus fileStatus : allFileStatus.fileStatuses.fileStatus) {
                final FileDTO fileDTO = convertToFileDTO(parentPath, fileStatus, null);
                result.add(fileDTO);
            }
        }
        return result;
    }

    public FileDTO getStatus(String path) throws IOException {

        final ObjectMapper mapper = new ObjectMapper();

        final URL url = buildGetFileStatusURL(path);
        System.out.println("URL=" + url);

        final URLConnection connection = url.openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");
        FileDTO result = null;
        try (BufferedReader response = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            final String line = response.readLine();
            System.out.println(line);
            response.close();

            final SingleFileStatus singleFileStatus = mapper.readValue(line, SingleFileStatus.class);
            final OneFileStatus fileStatus = singleFileStatus.fileStatus;
            result = convertToFileDTO(path, fileStatus, path);
        }
        return result;
    }

    private FileDTO convertToFileDTO(String parentPath, OneFileStatus fileStatus, String overridePathSuffix) {
        final FileDTO fileDTO = new FileDTO();
        fileDTO.setGroup(fileStatus.group);
        fileDTO.setId(normalizePath(parentPath, fileStatus.pathSuffix));
        final boolean isDirectory = "Directory".equalsIgnoreCase(fileStatus.type);
        fileDTO.setIsdir(isDirectory ? "true" : "false");
        fileDTO.setLength(humanReadableByteCount(fileStatus.length));
        fileDTO.setModificationTime(formatDate(fileStatus.modificationTime));
        final String pathSuffix = overridePathSuffix != null ? overridePathSuffix : fileStatus.pathSuffix;
        fileDTO.setName(pathSuffix.equals("") ? "." : pathSuffix);
        fileDTO.setOwner(fileStatus.owner);
        fileDTO.setPermission(listPermission(fileStatus.permission, isDirectory));
        return fileDTO;
    }

    private String normalizePath(String parentPath, String pathSuffix) {
        if(!parentPath.endsWith("/")) {
            parentPath = parentPath + "/";
        }
        return parentPath + pathSuffix;
    }

    private URL buildGetFileStatusURL(String path) throws MalformedURLException {
        return buildURL(
                    String.format("https://%s:%s/%s/%s?op=GETFILESTATUS", knoxServer, knoxPort, knoxWebhdfsGatewayPath, path));
    }

    private URL buildListStatusURL(String parentPath) throws MalformedURLException {
        return buildURL(
                String.format("https://%s:%s/%s/%s?op=LISTSTATUS", knoxServer, knoxPort, knoxWebhdfsGatewayPath, parentPath));
    }

    private URL buildURL(String url) throws MalformedURLException {
        final String customUrl = url + "&user.name=" + TEST_USER;
        return new URL(customUrl);
    }



    /**
     * Status of one file
     *
     * matches returned JSON
     */
    public static class OneFileStatus {
        public long accessTime;
        public int blockSize;
        public int childrenNum;
        public int fileId;
        public String group;
        public long length;
        public long modificationTime;
        public String owner;
        public String pathSuffix;
        public String permission;
        public int replication;
        public int storagePolicy;
        public String type;
        public  String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("\nAccessTime = ").append(accessTime);
            sb.append("\nBlockSize = ").append(blockSize);
            sb.append("\nChildrenNum = ").append(childrenNum);
            sb.append("\nFileId = ").append(fileId);
            sb.append("\nGroup = ").append(group);
            sb.append("\nLength = ").append(length);
            sb.append("\nModificationTime = ").append(modificationTime);
            sb.append("\nOwner = ").append(owner);
            sb.append("\nPathSuffix = ").append(pathSuffix);
            sb.append("\nPermission = ").append(permission);
            sb.append("\nReplication = ").append(replication);
            sb.append("\nStoragePolicy = ").append(storagePolicy);
            sb.append("\nType = ").append(type);
            return sb.toString();
        }
    }

    /**
     * Status of one file
     *
     * matches returned JSON
     */
    public static class SingleFileStatus {
        @JsonProperty("FileStatus")
        public OneFileStatus fileStatus;
    }

    /**
     * Status of all files in a directory
     *
     * matches returned JSON
     */
    public static class MultiFileStatus {
        @JsonProperty("FileStatus")
        public OneFileStatus[] fileStatus;
    }

    /**
     * Status of all files in a directory
     *
     * matches returned JSON
     */
    public static class AllFileStatus {
        @JsonProperty("FileStatuses")
        public MultiFileStatus fileStatuses;
    }

    private String humanReadableByteCount(long bytes) {
        int unit = 1024;
        if (bytes < unit) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(unit));
        String pre = "KMGTPE".charAt(exp - 1) + "";
        return String.format("%.1f %sB", bytes / Math.pow(unit, exp), pre);
    }

    private String formatDate(long value) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date(value));
    }

    private  String listPermission(String permission, boolean isDirectory){
        StringBuilder sb = new StringBuilder();
        sb.append(isDirectory ? 'd' : '-');
        int p = Integer.parseInt(permission, 16);
        sb.append(((p & 0x400) == 0) ? '-' : 'r');
        sb.append(((p & 0x200) == 0) ? '-' : 'w');
        sb.append(((p & 0x100) == 0) ? '-' : 'x');
        sb.append(((p & 0x40)  == 0) ? '-' : 'r');
        sb.append(((p & 0x20)  == 0) ? '-' : 'w');
        sb.append(((p & 0x10)  == 0) ? '-' : 'x');
        sb.append(((p & 0x4)   == 0) ? '-' : 'r');
        sb.append(((p & 0x2)   == 0) ? '-' : 'w');
        sb.append(((p & 0x1)   == 0) ? '-' : 'x');
        return sb.toString();
    }
}
