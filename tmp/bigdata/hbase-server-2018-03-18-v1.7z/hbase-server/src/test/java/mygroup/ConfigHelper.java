package mygroup;

public class ConfigHelper {

    public static void setHadoopHomeDir() {
        System.setProperty("hadoop.home.dir", "D:\\dev\\hadoop-horton\\projet-hadoop\\windows_libs\\2.6.2.0");
        System.setProperty("HADOOP_HOME", "D:\\dev\\hadoop-horton\\projet-hadoop\\windows_libs\\2.6.2.0");
    }

}
