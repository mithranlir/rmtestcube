package myelasticclient.service.employees.json;

import com.fasterxml.jackson.core.type.TypeReference;
import myelasticclient.service.document.response.QueryResponse;
import myelasticclient.service.employees.Employee;

/**
 * TypeReference ref = new TypeReference<ResponseHits<Employee>>() {};
 */
public class EmployeeTypeReference extends TypeReference<QueryResponse<Employee>> {
}
