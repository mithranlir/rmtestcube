package myelasticclient.indicator;

import myelasticclient.service.cluster.ClusterHealth;
import myelasticclient.service.cluster.ClusterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.stereotype.Component;

@Component
public class ElasticHealthIndicator extends AbstractHealthIndicator {

    private final ClusterService clusterService;

    @Autowired
    public ElasticHealthIndicator(ClusterService clusterService) {
        this.clusterService = clusterService;
    }

    @Override
    protected void doHealthCheck(Health.Builder builder) throws Exception {
        final ClusterHealth clusterHealth = clusterService.checkClusterHealth();

        if("green".equals(clusterHealth.getStatus()) || "yellow".equals(clusterHealth.getStatus())) {
            builder.up();
        }
        else {
            builder.down();
        }

        builder.withDetail("clusterName", clusterHealth.getClusterName());
        builder.withDetail("numberOfNodes", clusterHealth.getNumberOfNodes());
    }
}
