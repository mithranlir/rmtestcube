package eu.luminis.elastic.exception;

public class ClusterApiException extends ElasticClientException {
    public ClusterApiException(String message) {
        super(message);
    }

    public ClusterApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
