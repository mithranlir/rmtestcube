package myelasticclient.config;

import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.sniff.Sniffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class RestClientWrapper {

    private static final Logger logger = LoggerFactory.getLogger(RestClientWrapper.class);

    private RestClient restClient;
    private Sniffer sniffer;

    public RestClientWrapper(RestClient restClient) {
        this.restClient = restClient;
        this.sniffer = Sniffer.builder(restClient).build();
    }

    public RestClient getRestClient() {
        return restClient;
    }

    public Sniffer getSniffer() {
        return sniffer;
    }

    public void destroyInstance(RestClient instance) throws Exception {
        try {
            instance.close();
            this.sniffer.close();
        }
        catch (IOException e) {
            logger.error("Failed to close the elasticsearch sniffer");
        }
    }

}
