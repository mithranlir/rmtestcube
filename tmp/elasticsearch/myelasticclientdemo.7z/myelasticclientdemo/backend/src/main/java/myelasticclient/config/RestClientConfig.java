package myelasticclient.config;

import com.mitchellbosecke.pebble.PebbleEngine;
import com.mitchellbosecke.pebble.spring4.extension.SpringExtension;
import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("myelasticclient")
public class RestClientConfig {

    private static final Logger logger = LoggerFactory.getLogger(RestClientConfig.class);

    @Autowired
    private LoggingFailureListener loggingFailureListener;

    @Value("${eu.luminis.elastic.hostnames:#{\"localhost:9200\"}}")
    private String[] hostnames;

    @Bean
    public SpringExtension springExtension() {
        return new SpringExtension();
    }

    @Bean
    public PebbleEngine pebbleEngine() {
        return new PebbleEngine.Builder().extension(springExtension()).build();
    }

    @Bean
    public RestClientWrapper restClientWrapper() {
        final HttpHost[] hosts = new HttpHost[hostnames.length];
        for (int i = 0; i < hosts.length; i++) {
            hosts[i] = HttpHost.create(hostnames[i]);
        }
        final RestClient restClient = RestClient
                .builder(hosts)
                .setFailureListener(loggingFailureListener)
                .build();
        return new RestClientWrapper(restClient);
    }

}
