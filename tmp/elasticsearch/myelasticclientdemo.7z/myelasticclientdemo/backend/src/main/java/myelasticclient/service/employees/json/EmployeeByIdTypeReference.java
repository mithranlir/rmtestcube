package myelasticclient.service.employees.json;

import com.fasterxml.jackson.core.type.TypeReference;
import myelasticclient.service.document.response.GetByIdResponse;
import myelasticclient.service.employees.Employee;

public class EmployeeByIdTypeReference extends TypeReference<GetByIdResponse<Employee>> {
}
