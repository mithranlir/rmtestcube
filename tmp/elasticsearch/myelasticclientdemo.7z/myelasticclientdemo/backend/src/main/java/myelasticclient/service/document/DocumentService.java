package myelasticclient.service.document;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mitchellbosecke.pebble.PebbleEngine;
import com.mitchellbosecke.pebble.error.PebbleException;
import myelasticclient.config.RestClientWrapper;
import myelasticclient.service.document.request.IndexRequest;
import myelasticclient.service.document.request.QueryByIdRequest;
import myelasticclient.service.document.request.QueryByTemplateRequest;
import myelasticclient.service.document.response.GetByIdResponse;
import myelasticclient.service.document.response.QueryResponse;
import myelasticclient.exception.QueryByIdNotFoundException;
import myelasticclient.exception.QueryExecutionException;
import myelasticclient.exception.IndexDocumentException;
import myelasticclient.service.index.IndexResponse;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.ResponseException;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

@Component
public class DocumentService {
    private static final Logger logger = LoggerFactory.getLogger(DocumentService.class);

    private final RestClientWrapper clientWrapper;
    private final RestClient client;
    private final ObjectMapper jacksonObjectMapper;
    private final PebbleEngine pebbleEngine;

    @Autowired
    public DocumentService(RestClientWrapper clientWrapper, ObjectMapper jacksonObjectMapper, PebbleEngine pebbleEngine) {
        this.clientWrapper = clientWrapper;
        this.client = clientWrapper.getRestClient();
        this.jacksonObjectMapper = jacksonObjectMapper;
        this.pebbleEngine = pebbleEngine;
    }

    public <T> List<T> queryByTemplate(QueryByTemplateRequest request) {
        Assert.notNull(request, "Need to provide a QueryByTemplateRequest object");

        try {
            final Response response = client.performRequest(
                    "GET",
                    request.getIndexName() + "/_search",
                    new HashMap<>(),
                    new StringEntity(request.createQuery(pebbleEngine), Charset.defaultCharset()));

            final QueryResponse<T> queryResponse =
                    jacksonObjectMapper.readValue(response.getEntity().getContent(), request.getTypeReference());

            final List<T> result = new ArrayList<>();
            queryResponse.getHits().getHits().forEach(tHit -> {
                final T source = tHit.getSource();
                if (request.getAddId()) {
                    addIdToEntity(tHit.getId(), source);
                }
                result.add(source);
            });

            return result;
        }
        catch (IOException | PebbleException e) {
            logger.warn("Problem while executing request.", e);
            throw new QueryExecutionException("Error when executing a document");
        }

    }

    public <T> T querybyId(QueryByIdRequest request) {
        try {
            final Response response = client.performRequest(
                    "GET",
                    "/" + request.getIndex() + "/" + request.getType() + "/" + request.getId());

            final GetByIdResponse<T> queryResponse =
                    jacksonObjectMapper.readValue(response.getEntity().getContent(), request.getTypeReference());

            if (!queryResponse.getFound()) {
                throw new QueryByIdNotFoundException(request.getIndex(), request.getType(), request.getId());
            }

            final T entity = queryResponse.getSource();

            if (request.getAddId()) {
                addIdToEntity(request.getId(), entity);
            }

            return entity;
        }
        catch (ResponseException re) {
            if (re.getResponse().getStatusLine().getStatusCode() == 404) {
                throw new QueryByIdNotFoundException(request.getIndex(),request.getType(),request.getId());
            }
            else {
                logger.warn("Problem while executing request.", re);
                throw new QueryExecutionException("Error when executing a document");
            }
        } catch (IOException e) {
            logger.warn("Problem while executing request.", e);
            throw new QueryExecutionException("Error when executing a document");
        }
    }

    public String index(IndexRequest indexRequest) {
        try {
            final HttpEntity requestBody = new StringEntity(jacksonObjectMapper.writeValueAsString(indexRequest.getEntity()), Charset.defaultCharset());

            Response response;
            if (indexRequest.getId() != null) {
                response = client.performRequest(
                        "PUT",
                        indexRequest.getIndex() + "/" + indexRequest.getType() + "/" + indexRequest.getId(),
                        new Hashtable<>(),
                        requestBody);
            } else {
                response = client.performRequest(
                        "POST",
                        indexRequest.getIndex() + "/" + indexRequest.getType(),
                        new Hashtable<>(),
                        requestBody);
            }

            final int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode > 299) {
                logger.warn("Problem while indexing a document: {}", response.getStatusLine().getReasonPhrase());
                throw new QueryExecutionException("Could not index a document, status code is " + statusCode);
            }

            final IndexResponse queryResponse = jacksonObjectMapper.readValue(response.getEntity().getContent(), IndexResponse.class);

            return queryResponse.getId();

        } catch (IOException e) {
            logger.warn("Problem while executing request.", e);
            throw new IndexDocumentException("Error when executing a document");
        }

    }

    public String remove(String index, String type, String id) {
        try {
            final Response response = client.performRequest(
                    "DELETE",
                    index + "/" + type + "/" + id,
                    new Hashtable<>());
            return response.getStatusLine().getReasonPhrase();
        } catch (IOException e) {
            logger.warn("Problem while removing a document.", e);
            throw new IndexDocumentException("Error when removing a document");
        }
    }


    private <T> void addIdToEntity(String id, T source) {
        try {
            final Method setIdMethod = source.getClass().getMethod("setId", String.class);
            setIdMethod.invoke(source, id);
        }
        catch (NoSuchMethodException | InvocationTargetException e) {
            throw new QueryExecutionException("The setter for the id method is not available.", e);
        }
        catch (IllegalAccessException e) {
            throw new QueryExecutionException("Id argument seems to be wrong", e);
        }
    }
}
