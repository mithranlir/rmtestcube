package nl.gridshore.employees.json;

import com.fasterxml.jackson.core.type.TypeReference;
import eu.luminis.elastic.document.response.GetByIdResponse;
import nl.gridshore.employees.Employee;

public class EmployeeByIdTypeReference extends TypeReference<GetByIdResponse<Employee>> {
}
