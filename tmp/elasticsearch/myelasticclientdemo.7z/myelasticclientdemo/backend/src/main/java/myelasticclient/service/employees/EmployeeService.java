package myelasticclient.service.employees;

import myelasticclient.service.document.DocumentService;
import myelasticclient.service.document.request.IndexRequest;
import myelasticclient.service.document.request.QueryByIdRequest;
import myelasticclient.service.document.request.QueryByTemplateRequest;
import myelasticclient.service.index.IndexService;
import myelasticclient.service.employees.json.EmployeeByIdTypeReference;
import myelasticclient.service.employees.json.EmployeeTypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EmployeeService {
    private static final Logger logger = LoggerFactory.getLogger(EmployeeService.class);

    public static final String INDEX = "luminis";
    private static final String TYPE = "ams";

    private final DocumentService documentService;
    private final IndexService indexService;

    @Autowired
    public EmployeeService(DocumentService documentService, IndexService indexService) {
        this.documentService = documentService;
        this.indexService = indexService;
    }

    public String storeEmployee(Employee employee) {

        final IndexRequest request = IndexRequest.create()
                .setIndex(INDEX)
                .setType(TYPE)
                .setEntity(employee);

        if (employee.getId() != null) {
            request.setId(employee.getId());
        }

        return documentService.index(request);
    }

    public List<Employee> queryForEmployees(String name) {

        final Map<String, Object> params = new HashMap<>();
        params.put("name", name);
        params.put("operator", "or");

        final QueryByTemplateRequest request = QueryByTemplateRequest.create()
                .setAddId(true)
                .setTypeReference(new EmployeeTypeReference())
                .setIndexName(INDEX)
                .setModelParams(params)
                .setTemplateName("find_employee.peeble");

        return documentService.queryByTemplate(request);
    }

    public List<Employee> queryForEmployeesByNameAndEmail(String searchString) {

        final Map<String, Object> params = new HashMap<>();
        params.put("searchText", searchString);
        params.put("operator", "and");

        final QueryByTemplateRequest request = QueryByTemplateRequest.create()
                .setAddId(true)
                .setTypeReference(new EmployeeTypeReference())
                .setIndexName(INDEX)
                .setModelParams(params)
                .setTemplateName("find_employee_by_email.peeble");

        return documentService.queryByTemplate(request);
    }

    public Employee loadEmployeeById(String id) {
        final QueryByIdRequest request = QueryByIdRequest.create()
                .setAddId(true)
                .setIndex(INDEX)
                .setType(TYPE)
                .setId(id)
                .setTypeReference(new EmployeeByIdTypeReference());

        return documentService.querybyId(request);
    }

    public void removeEmployee(String id) {
        documentService.remove(INDEX, TYPE, id);
    }

    public void createIndex() {
        try {
            final File file = ResourceUtils.getFile("classpath:elastic/client-mapping.json");
            final FileReader fileReader = new FileReader(file);
            final String body = FileCopyUtils.copyToString(fileReader);
            fileReader.close();
            indexService.createIndex(INDEX, body);
        }
        catch (IOException e) {
            logger.warn("Could not read mapping file for creating index", e);
        }
    }
}
