package myelasticclient;

import myelasticclient.config.RestClientConfig;
import myelasticclient.service.index.IndexService;
import myelasticclient.service.index.IndiceService;
import myelasticclient.service.employees.Employee;
import myelasticclient.service.employees.EmployeeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@SpringBootApplication
@Import(RestClientConfig.class)
public class ElasticClientDemoApplication {

    private static final Logger logger = LoggerFactory.getLogger(ElasticClientDemoApplication.class);

    public static void main(String[] args) {

        final ConfigurableApplicationContext context = SpringApplication.run(ElasticClientDemoApplication.class, args);

        final EmployeeService employeeService = context.getBean(EmployeeService.class);
        final IndexService indexService = context.getBean(IndexService.class);
        final IndiceService indiceService = context.getBean(IndiceService.class);

        System.out.println("response=\n" + indiceService.getlistAllIndices());

        if (!indexService.indexExist(EmployeeService.INDEX)) {
            createEmployees(employeeService);
        }

        logger.info("employees:" + employeeService.queryForEmployeesByNameAndEmail("jettro"));
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**").allowedOrigins("http://localhost:8000");
            }
        };
    }

    private static void createEmployees(EmployeeService employeeService) {

        logger.info("createEmployees ENTER");

        logger.info("createIndex()");

        employeeService.createIndex();

        logger.info("storeEmployee() x 4 ");

        final Employee jettro = new Employee();
        jettro.setName("Jettro Coenradie");
        jettro.setEmail("jettro@gridshore.nl");
        jettro.setPhoneNumber("+31612345678");
        jettro.setSpecialties(new String[]{"java", "elasticsearch", "angularjs"});

        employeeService.storeEmployee(jettro);

        final Employee byron = new Employee();
        byron.setName("Byron Voorbach");
        byron.setEmail("byron@gridshore.nl");
        byron.setPhoneNumber("+31612345678");
        byron.setSpecialties(new String[]{"java", "elasticsearch", "security"});

        employeeService.storeEmployee(byron);

        final Employee ralph = new Employee();
        ralph.setName("Ralph Broers");
        ralph.setEmail("ralph@gridshore.nl");
        ralph.setPhoneNumber("+31612345678");
        ralph.setSpecialties(new String[]{"java", "elasticsearch", "rx"});

        employeeService.storeEmployee(ralph);

        final Employee roberto = new Employee();
        roberto.setName("Roberto van der Linden");
        roberto.setEmail("roberto@gridshore.nl");
        roberto.setPhoneNumber("+31612345678");
        roberto.setSpecialties(new String[]{"java", "elasticsearch", "ionicframework"});

        employeeService.storeEmployee(roberto);


    }
}
