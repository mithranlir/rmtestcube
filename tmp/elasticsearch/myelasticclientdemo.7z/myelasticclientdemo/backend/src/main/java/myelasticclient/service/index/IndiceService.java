package myelasticclient.service.index;

import com.fasterxml.jackson.databind.ObjectMapper;
import myelasticclient.config.RestClientWrapper;
import myelasticclient.exception.IndexApiException;
import myelasticclient.exception.QueryExecutionException;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class IndiceService {
    private static final Logger logger = LoggerFactory.getLogger(IndiceService.class);

    private final RestClientWrapper clientWrapper;
    private final RestClient client;
    private final ObjectMapper jacksonObjectMapper;

    @Autowired
    public IndiceService(RestClientWrapper clientWrapper, ObjectMapper jacksonObjectMapper) {
        this.clientWrapper = clientWrapper;
        this.client = clientWrapper.getRestClient();
        this.jacksonObjectMapper = jacksonObjectMapper;
    }

    public String getlistAllIndices() {
        try {
            final Response response = client.performRequest("GET", "/_cat/indices?v");
            final int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                final String content = EntityUtils.toString(response.getEntity());
                return content;
            }
            else if (statusCode == 404) {
                return "";
            }
            else {
                logger.warn("Problem while getting indices list : {}", response.getStatusLine().getReasonPhrase());
                throw new QueryExecutionException("Could not get indices list, status code is " + statusCode);
            }
        }
        catch (IOException e) {
            logger.warn("Problem while getting indices list.", e);
            throw new IndexApiException("Error when getting indices list.");
        }
    }
}
