package eu.luminis.elastic.config;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.sniff.Sniffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

/**
 * Configuration class
 */
@Configuration
@ComponentScan("eu.luminis.elastic")
public class RestClientConfig {

    private static final Logger logger = LoggerFactory.getLogger(RestClientConfig.class);

    @Autowired
    private LoggingFailureListener loggingFailureListener;

    private Sniffer sniffer;

    @Value("${eu.luminis.elastic.hostnames:#{\"localhost:9200\"}}")
    private String[] hostnames;

    @Bean
    public RestClient restClient() {
        final HttpHost[] hosts = new HttpHost[hostnames.length];
        for (int i = 0; i < hosts.length; i++) {
            hosts[i] = HttpHost.create(hostnames[i]);
        }
        final RestClient restClient = RestClient
                .builder(hosts)
                .setFailureListener(loggingFailureListener)
                .build();

        this.sniffer = Sniffer.builder(restClient).build();

        return restClient;
    }

    public void destroyInstance(RestClient instance) throws Exception {
        try {
            instance.close();
            this.sniffer.close();
        }
        catch (IOException e) {
            logger.error("Failed to close the elasticsearch sniffer");
        }
    }
}
