package myelasticclient.exception;

public class IndexApiException extends ElasticClientException {
    public IndexApiException(String message) {
        super(message);
    }

    public IndexApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
