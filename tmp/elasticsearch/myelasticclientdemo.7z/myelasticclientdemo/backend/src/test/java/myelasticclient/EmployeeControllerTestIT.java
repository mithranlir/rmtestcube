package myelasticclient;


import myelasticclient.service.employees.Employee;
import org.junit.Test;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmployeeControllerTestIT {

    @Test
    public void test() {

        final RestTemplate restTemplate = new RestTemplate();

        final String url = "http://localhost:8080/api/employee/_search?term={term}";

        final Map<String, String> uriParams = new HashMap<>();
        uriParams.put("term", "jettro");

        final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);

        final URI uri = builder.buildAndExpand(uriParams).toUri();

        final ResponseEntity<List<Employee>> response =
                restTemplate.exchange(
                        uri, HttpMethod.GET, null, new ParameterizedTypeReference<List<Employee>>() {});
        final List<Employee> employees = response.getBody();

        System.out.println("employees=" + employees);

    }
}
