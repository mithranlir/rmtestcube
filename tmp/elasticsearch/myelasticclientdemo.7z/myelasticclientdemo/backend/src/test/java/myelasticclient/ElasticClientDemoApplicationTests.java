package myelasticclient;

import myelasticclient.ElasticClientDemoApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ElasticClientDemoApplication.class)
public class ElasticClientDemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
