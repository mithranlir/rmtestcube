lancer l'app GWT dans IntelliJ ou avec l'url MAVEN...
(dans Intellij ; post task : mvn process-resources

Accès au serveur : http://127.0.0.1:8888/GwtWebApp.html

Pour dev angular, lancer : gulp
Acces au server dev angular : http://127.0.0.1:3000/


spring-boot-gwt
===============

A quickstart spring boot gwt application (Spring Boot 1.4.1, GWT 2.8)

## GWT Developer Console

Use the GWT console with : 
- mvn gwt:run
- mvn gwt:debug
or simply use mvn install as useal


## What's in the sources

Quick dive in the code :

- fr.ekito.gwt.server for server side code
- fr.ekito.gwt.client for GWT client side code
- fr.ekito.gwt.client.controller contains Client Http Rest controller

The application is build uppon Google Gin 

## More details

More details about the project on Ekito's blog :  http://www.ekito.fr/people/?p=4816


