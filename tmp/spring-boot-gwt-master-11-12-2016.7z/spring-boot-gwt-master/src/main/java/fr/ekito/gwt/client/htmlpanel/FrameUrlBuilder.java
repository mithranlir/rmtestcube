package fr.ekito.gwt.client.htmlpanel;

import com.google.gwt.user.client.Window;

public class FrameUrlBuilder {
    public String buildUrl(String path) {
        String url = Window.Location.getProtocol() + "//";
        url += Window.Location.getHost();
        url += path;
        return url;
    }
}
