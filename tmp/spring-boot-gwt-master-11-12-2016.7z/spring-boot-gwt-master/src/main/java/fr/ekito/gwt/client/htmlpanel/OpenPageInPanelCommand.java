package fr.ekito.gwt.client.htmlpanel;

import com.google.gwt.user.client.Command;

public class OpenPageInPanelCommand implements Command {

	private GridPopup gridPopup;
	private int yPosition;
	private int refWidth;
	private FrameUrlBuilder frameUrlBuilder;
	private String localUrl = "";

	public OpenPageInPanelCommand() {
		this.frameUrlBuilder = new FrameUrlBuilder();
	}

	@Override
	public void execute() {
		final String newUrl = this.frameUrlBuilder.buildUrl(this.localUrl);
		if(this.gridPopup == null) {
			this.gridPopup = new GridPopup(newUrl, this.yPosition, this.refWidth);
		}
		else {
			this.gridPopup.changeUrl(newUrl);
		}
		this.gridPopup.show();
	}

	public void setYPosition(int yPosition) {
		this.yPosition = yPosition;
	}

	public void applyRefWidthOnPopup(int refWidth) {
		if(getGridPopup()!=null) {
			// change width
			getGridPopup().resizeOnWidth(refWidth);
		}
		else {
			// keep width
			keepRefWidth(refWidth);
		}
	}

	public void keepRefWidth(int refWidth) {
		this.refWidth = refWidth;
	}

	public GridPopup getGridPopup() {
		return gridPopup;
	}

	public void setLocalUrl(String localUrl) {
		this.localUrl = localUrl;
	}

}
