package fr.ekito.gwt.client.htmlpanel;

import com.google.gwt.user.client.Command;

public class ClosePageInPanelCommand implements Command {

    private OpenPageInPanelCommand openPageInPanelCommand;

    public ClosePageInPanelCommand( OpenPageInPanelCommand openPageInPanelCommand) {
        this.openPageInPanelCommand = openPageInPanelCommand;
    }

    @Override
    public void execute() {
        final GridPopup gridPopup = openPageInPanelCommand.getGridPopup();
        gridPopup.hide();
    }
}
