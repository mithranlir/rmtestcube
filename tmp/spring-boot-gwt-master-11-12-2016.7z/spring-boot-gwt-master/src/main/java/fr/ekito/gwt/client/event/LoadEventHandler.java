package fr.ekito.gwt.client.event;

import com.google.gwt.event.shared.EventHandler;

/**
 * LoadEvent event handler
 * @author AGI
 *
 */
public interface LoadEventHandler extends EventHandler {
	void onLoadEventHandler(LoadEvent event);

}
