package fr.ekito.gwt.client.htmlpanel;

import com.google.gwt.dom.client.Style;
import com.google.gwt.user.client.ui.StackLayoutPanel;

public class CustomStackLayoutPanel extends StackLayoutPanel  {

    private OpenPageInPanelCommand openCmd;

    public CustomStackLayoutPanel(Style.Unit unit) {
        super(unit);
    }

    @Override
    protected void onLoad() {
        super.onLoad();
        configurePopupWidth();
    }

    @Override
    public void onResize() {
        super.onResize();
        configurePopupWidth();
    }

    private void configurePopupWidth() {
        if(openCmd!=null && this.getOffsetWidth()!=0) {
            openCmd.applyRefWidthOnPopup(this.getOffsetWidth());
        }
    }

    public void setOpenCmd(OpenPageInPanelCommand openCmd) {
        this.openCmd = openCmd;
    }

}
