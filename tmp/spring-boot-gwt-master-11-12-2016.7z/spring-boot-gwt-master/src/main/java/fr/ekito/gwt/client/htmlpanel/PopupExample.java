package fr.ekito.gwt.client.htmlpanel;

import com.google.gwt.core.client.Scheduler;
import com.google.gwt.dom.client.Style;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.MenuBar;
import com.google.gwt.user.client.ui.StackLayoutPanel;

import java.util.AbstractMap;


public class PopupExample {

    public StackLayoutPanel build() {

        final OpenPageInPanelCommand openCmd = new OpenPageInPanelCommand();
        final int menuHeight = 30;
        final int offsetMenu = 0;
        openCmd.setYPosition(menuHeight - offsetMenu);

        final ClosePageInPanelCommand closeCmd = new ClosePageInPanelCommand(openCmd);

        final CustomStackLayoutPanel panel = buildPanel(menuHeight, openCmd, closeCmd);
        panel.setOpenCmd(openCmd);

        return panel;
    }

    private CustomStackLayoutPanel buildPanel(int menuHeight,
                                              OpenPageInPanelCommand openCmd,
                                              ClosePageInPanelCommand closeCmd) {
        final MenuBar menu = buildMenuBar(openCmd, closeCmd);
        final CustomStackLayoutPanel panel = new CustomStackLayoutPanel(Style.Unit.PX);
        final String html = LipsumText.TEXT;
        panel.add(new HTML(html), menu, menuHeight);
        return panel;
    }

    private MenuBar buildMenuBar(OpenPageInPanelCommand openCmd, ClosePageInPanelCommand closeCmd) {

        final String[] menuItems = {
                "open /test.html", "/test.html",
                "open /", "/",
                "open /index.html", "/index.html",
                "open /#!/other", "/#!/other"
        };

        final MenuBar fooMenu = new MenuBar(true);
        for(int i=0; i< menuItems.length; i+=2) {
            fooMenu.addItem(menuItems[i], new MenuCommand(openCmd, menuItems[i+1]));
        }

        final MenuBar barMenu = new MenuBar(true);
        barMenu.addItem("close", closeCmd);

        final MenuBar menu = new MenuBar();
        menu.addItem("foo", fooMenu);
        menu.addItem("bar", barMenu);

        return menu;
    }

    public static class MenuCommand implements Scheduler.ScheduledCommand {
        private String localUrl = "";
        private OpenPageInPanelCommand openCmd;
        public MenuCommand(OpenPageInPanelCommand openCmd, String localUrl) {
            this.openCmd = openCmd;
            this.localUrl = localUrl;
        }
        @Override
        public void execute() {
            openCmd.setLocalUrl(localUrl);
            openCmd.execute();
        }
    }

    public static native void console(String text)
	/*-{
        console.log(text);
    }-*/;


}
