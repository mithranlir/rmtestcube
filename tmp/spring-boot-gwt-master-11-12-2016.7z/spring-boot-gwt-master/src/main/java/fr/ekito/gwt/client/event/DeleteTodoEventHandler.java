package fr.ekito.gwt.client.event;

import com.google.gwt.event.shared.EventHandler;

/**
 * DeleteTodoEvent event handler
 * 
 * @author AGI
 *
 */
public interface DeleteTodoEventHandler extends EventHandler {
	void onDeleteTodoEventHandler(DeleteTodoEvent event);

}
