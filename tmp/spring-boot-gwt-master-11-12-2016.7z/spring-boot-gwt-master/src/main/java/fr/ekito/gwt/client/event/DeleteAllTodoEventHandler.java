package fr.ekito.gwt.client.event;

import com.google.gwt.event.shared.EventHandler;

/**
 * DeleteAllTodoEvent event handler
 * @author AGI
 *
 */
public interface DeleteAllTodoEventHandler extends EventHandler {
	void onDeleteAllTodoEventHandler(DeleteAllTodoEvent event);

}
