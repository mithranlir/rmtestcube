package fr.ekito.gwt.client.htmlpanel;

import com.google.gwt.dom.client.Style;
import com.google.gwt.safehtml.shared.UriUtils;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Frame;
import com.google.gwt.user.client.ui.PopupPanel;

public class GridPopup extends PopupPanel {

    private Frame frame;
    private int currentRefWidth;

    public GridPopup(String url, int positionY, int refWidth) {
        super(false, false);

        final int borderWidth = 0;
        configurePopupStyles(borderWidth);

        this.frame = new Frame();
        this.frame.setUrl(UriUtils.fromTrustedString(url));

        if(refWidth!=0) {
            resizeOnWidth(refWidth);
        }

        setPopupPosition(0, positionY);

        final String frameHeight = computeFrameHeight(positionY);
        frame.setHeight(frameHeight);
        configureFrameStyles();

        setWidget(frame);
    }

    public void changeUrl(String url) {
        this.frame.setUrl(UriUtils.fromTrustedString(url));
    }

    private String computeFrameHeight(int positionY) {
        final int defaultMarginY = 4;
        return (Window.getClientHeight() - positionY - defaultMarginY) + "px";
    }

    private void configureFrameStyles() {
        frame.getElement().getStyle().setBorderWidth(0, Style.Unit.PX);
        frame.getElement().getStyle().setPadding(0, Style.Unit.PX);
        frame.getElement().getStyle().setMargin(0, Style.Unit.PX);
    }

    private void configurePopupStyles(int borderWidth) {
        this.getElement().getStyle().setBorderWidth(borderWidth, Style.Unit.PX);
        this.getElement().getStyle().setBorderColor("red");
        this.getElement().getStyle().setPadding(0, Style.Unit.PX);
        this.getElement().getStyle().setMargin(0, Style.Unit.PX);
    }

    public void resizeOnWidth(int width) {
        this.currentRefWidth = width;
        final String frameWidth = currentRefWidth + "px";
        frame.setWidth(frameWidth);
    }
}
