package fr.ekito.gwt.client.event;

import com.google.gwt.event.shared.EventHandler;

/**
 * AddTodoEvent event handler
 * @author AGI
 *
 */
public interface AddTodoEventHandler extends EventHandler {
	void onAddTodoEventHandler(AddTodoEvent event);

}
