package fr.ekito.gwt.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.RootLayoutPanel;
import fr.ekito.gwt.client.htmlpanel.PopupExample;

public class GwtWebApp implements EntryPoint {

	public void onModuleLoad() {
		final PopupExample builder = new PopupExample();
		final RootLayoutPanel rp = RootLayoutPanel.get();
		rp.add(builder.build());
	}

	/*
	private final GwtWebAppGinjector injector = GWT.create(GwtWebAppGinjector.class);

	public void onModuleLoad() {
		// ensure resources are injected
		ApplicationResources.INSTANCE.style().ensureInjected();
		// get controler from gin jector
		WebAppController controller = injector.getWebAppController();
		// bind event handlers
		controller.bindHandlers();
		// get main panel
		MainPanel mainPanel = injector.getMainPanel();
		// add for display
		RootLayoutPanel.get().add(mainPanel);

	}
	*/
}
