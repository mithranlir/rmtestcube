var gulp = require('gulp');
var browserify = require('browserify');
var source = require('vinyl-source-stream');
var jshint = require('gulp-jshint');
var browserSync = require('browser-sync').create();
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');
var httpProxy = require('http-proxy');

/** lint and css tasks **/

gulp.task('lint', function() {
  gulp.src('./src/app/**/*.js')
    .pipe(jshint())
    .pipe(jshint.reporter('default'));
});

gulp.task('css', function() {
    return gulp.src(
        [
            './src/assets/**/*.css',
            './node_modules/angular-material/**/*.css'
        ])
        .pipe(concat('style.css'))
        .pipe(gulp.dest('./public/'));
});

/** tasks used to build for local app running **/

gulp.task('vendor', function(){
    return gulp.src([
        './src/assets/**/*.js'
        ])
        .pipe(uglify())
        .pipe(concat('vendor.min.js'))
        .pipe(gulp.dest('./public/'));
});

gulp.task('browserify', function() {

    // Grabs the app.js file
    browserify([
            './src/app/app.js'
        ])
        // bundles it and creates a file called main.js
        .bundle()
        .pipe(source('main.js'))
        .pipe(gulp.dest('./public/'));
});

gulp.task('copy', ['browserify', 'vendor'], function() {
    return gulp.src(['./src/**/*.html'])
        .pipe(gulp.dest('./public'))
        .pipe(browserSync.stream());
});

gulp.task('build',['lint', 'copy', 'css']);

/** proxy config when running app with local server **/

//var localServerUrl = 'http://localhost:8080/';
var localServerUrl = 'http://localhost:8888/';

var proxy = httpProxy.createProxyServer({
    target: localServerUrl
});

var startsWith = function(value, str) {
    return value.substring( 0, str.length ) === str;
}

var endsWith = function(value, str) {
    return value.substring( value.length - str.length, value.length ) === str;
}

var proxyMiddleware = function(req, res, next) {
    if(req.url == '/' || startsWith(req.url, '/app/')) {
        console.log("no proxy for " + req.url);
        next();
    }
    else if(req.url == '/style.css' || req.url == '/vendor.min.js' || req.url == '/main.js') {
        console.log("no proxy for " + req.url);
        next();
    }
    else {
        console.log("proxy for " + req.url);
        proxy.web(req, res);
    }
};

/** run localhost:3000 with file sync **/

gulp.task('browser-sync', ['build'], function() {
    browserSync.init({
        server: {
            baseDir: "./public",
            middleware: proxyMiddleware
        },
        browser:"firefox"
    });
});

gulp.task('default', ['browser-sync'], function(){
    gulp.watch("./src/**/*.*", ["build"]);
    gulp.watch("./public/**/*.*").on('change', browserSync.reload);
})
