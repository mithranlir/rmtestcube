

require('angular');
require('angular-ui-router');
require('angular-aria');
require('angular-animate');
require('angular-material');
require('angular-resource');
require('angular-base64');

require('./components/poc/home/home.js');
require('./components/poc/home/other.js');

var app = angular.module('myApp', ['ui.router','ngMaterial','ngResource', 'myApp.home', 'myApp.other']);

app.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise("/");

    $stateProvider
        .state('home', {
            url: "/",
            views : {
                "" : {
                    templateUrl:"app/components/poc/home/home.html"
                },
                "header@home":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
        .state('other', {
            url: "/other",
            views : {
                "" : {
                    templateUrl:"app/components/poc/home/other.html"
                },
                "header@other":{
                    templateUrl:"app/shared/header/header.html"
                }
            }
        })
    ;
});
