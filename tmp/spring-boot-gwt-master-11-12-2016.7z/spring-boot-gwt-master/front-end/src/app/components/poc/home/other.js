angular.module('myApp.other', [])
.controller('otherCtrl',[function(){
	this.welcomeText = 'Welcome to AngularJS : myApp Other Page!';
}]);
