//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.qfs.activation.impl;

import com.qfs.activation.impl.LicenseCorruptedException;
import com.qfs.activation.impl.LicenseException;
import com.qfs.activation.impl.LicenseNotFoundException;
import com.quartetfs.biz.pivot.impl.Util;
import com.quartetfs.pivot.live.server.licensing.LicenseHandler;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class LicenseManager {
    private static final Logger a = Logger.getLogger(LicenseManager.class.getName());
    private static final String b = "LICENSE_FILENAME";
    private static final String c = "LICENSE_SYSTEM_PROPERTY";
    private static final String d = "LICENSE_ENVIRONMENT_VARIABLE";
    private static final String e = "M8lAD9i1Eo65v0S n2.tcPe";
    private static final int[] f = new int[]{12, 6, 9, 2, 6, 16, 15, 7, 5, 17, 18, 7, 10, 1, 18, 13, 18, 11};
    private static final int[] g = new int[]{3, 8, 14};
    private static final int[] h = new int[]{0, 4, 11};
    private static final String i = System.getProperty("line.separator");

    public LicenseManager() {
    }

    public static <T> byte[] getBinaryLicense(Class<T> paramClass) throws LicenseException {
        return null;
    }

    public static <T> T getLicense(Class<T> paramClass) throws LicenseException {
        if(paramClass.equals(LicenseHandler.LicenseHolder.class)) {
            return (T) createFakeLicenseHolder();
        }
        return null;
    }

    public static <T> T getLicense(Class<T> var0, byte[] var1) throws LicenseException {
        if(var0.equals(LicenseHandler.LicenseHolder.class)) {
            return (T) createFakeLicenseHolder();
        }
        return null;
    }

    public static LicenseHandler.LicenseHolder createFakeLicenseHolder() {
        final Properties properties = new Properties();

        final Long startDate = (new Date()).getTime() - (24 * 60 * 60 * 1000); // now - 1d;
        properties.put("sDate", startDate.toString());

        final Long endDate = (new Date()).getTime() + (365 * 24 * 60 * 60 * 1000); // now + 1 year;
        properties.put("eDate", endDate.toString());

        String host = "";
        try {
            host = Platform.getLocalHostName();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        properties.put("host", host);

        final int maxNbOfCPU = Util.retrieveNumberOfAllowedCores();
        properties.put("maxNbOfCPU", maxNbOfCPU + "");

        properties.put("live", "YES");

        properties.put("sentinel", "YES");

        properties.put("rs", "YES");

        final LicenseHandler.LicenseHolder holder = new LicenseHandler.LicenseHolder(properties);

        return holder;
    }

}
