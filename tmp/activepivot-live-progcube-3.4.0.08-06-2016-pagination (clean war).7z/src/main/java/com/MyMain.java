package com;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MyMain {
    public static void main(String[] args) throws ParseException {


        test1();
    }

    private static void test1() throws ParseException {
        String str = "Mon, 06-Jun-2016 05:53:07 GMT";
        DateFormat dateFormat = new SimpleDateFormat("EEE, dd-MMM-yyyy hh:mm:ss z");
        final Date parse = dateFormat.parse(str);
        System.out.println("parse" + parse);
    }

    private static void test2() throws ParseException {
        String str = "06-Jun-2016";
        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy", Locale.US);
        final Date parse = dateFormat.parse(str);
        System.out.println("parse" + parse);
    }

}
