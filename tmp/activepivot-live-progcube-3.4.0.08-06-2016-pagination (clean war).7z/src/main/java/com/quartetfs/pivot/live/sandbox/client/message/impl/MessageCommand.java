/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.message.impl;

import com.google.gwt.user.client.Command;
import com.quartetfs.pivot.live.core.client.widget.impl.PopupServices;
import com.quartetfs.pivot.live.sandbox.client.message.IMessage;

/**
 * The Dummy command simply show its message using a popup.<br/>
 * 
 * We use the IMessage interface to delay the moment when we compute the message
 * and avoid useless calculation
 * 
 * @author Quartet Financial Systems
 *
 */
public class MessageCommand implements Command {

	/** The message computer */
	protected final IMessage message;

	/** The computed body message */
	protected String bodyMsg;

	/** The computed header message */
	protected String bodyHeader;

	public MessageCommand(IMessage message) {
		this.message = message;
	}

	/**
	 * The final execute that prints the message using a popup
	 */
	@Override
	public void execute() {
		if(bodyMsg == null)
			bodyMsg = message.computeBody();

		if(bodyHeader == null)
			bodyHeader = message.computeHeader();

		//Print message using popup
		PopupServices.create().setTitle(bodyHeader).setContent(bodyMsg).isClosable().isModal().isAutoHide().center();
	}
}
