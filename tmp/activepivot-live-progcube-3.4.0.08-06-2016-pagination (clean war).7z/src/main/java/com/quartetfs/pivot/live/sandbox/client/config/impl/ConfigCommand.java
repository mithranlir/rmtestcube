package com.quartetfs.pivot.live.sandbox.client.config.impl;

import com.google.gwt.user.client.Command;
import com.google.inject.Inject;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.FailureType;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.impl.DefaultAsyncCallback;
import com.quartetfs.pivot.live.sandbox.shared.config.impl.ConfigAction;
import com.quartetfs.pivot.live.sandbox.shared.config.impl.ConfigResult;
import com.quartetfs.pivot.live.sandbox.shared.config.impl.ConfigResultHolder;

public class ConfigCommand implements Command {

	protected final IEventBus eventBus;
	protected final ICommandExecutorAsync commandExecutor;
	protected final ConfigResultHolder configResultHolder;

	@Inject
	public ConfigCommand(@Main IEventBus eventBus,
						 ICommandExecutorAsync commandExecutorAsync,
						 ConfigResultHolder configResultHolder) {
		this.eventBus = eventBus;
		this.commandExecutor = commandExecutorAsync;
		this.configResultHolder = configResultHolder;
	}

	@Override
	public void execute() {
		// Batches the PingAction with a generated client message
		commandExecutor.batch(new ConfigAction(),
				new DefaultAsyncCallback<ConfigResult> (eventBus, "Get Config Failed", FailureType.MAJOR) {
					@Override
					public void onFailure(Throwable reason) {
						super.onFailure(reason);
						// Nothing to do
					}

					@Override
					public void onSuccess(ConfigResult result) {
						configResultHolder.setConfigResult(result);
					}
				}
		);
	}

}
