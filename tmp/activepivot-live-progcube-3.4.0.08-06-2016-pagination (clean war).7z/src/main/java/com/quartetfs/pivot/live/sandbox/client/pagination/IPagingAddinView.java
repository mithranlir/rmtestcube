package com.quartetfs.pivot.live.sandbox.client.pagination;

import com.google.gwt.event.dom.client.HasClickHandlers;
import com.google.gwt.user.client.ui.HTML;
import com.quartetfs.pivot.live.core.client.widget.addin.IAddinView;

public interface IPagingAddinView extends IAddinView {
    void update();
    HasClickHandlers getActionTrigger();
    void setMaxHeight(int var1);

    HTML getTextBox();

    void hideButtonsAndTextbox();
    void showButtonsAndTextbox();
}
