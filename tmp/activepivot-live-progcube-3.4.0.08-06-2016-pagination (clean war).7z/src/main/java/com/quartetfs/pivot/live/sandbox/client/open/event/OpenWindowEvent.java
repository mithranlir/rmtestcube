/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.open.event;

import com.google.gwt.event.shared.GwtEvent;

public class OpenWindowEvent extends GwtEvent<IOpenWindowHandler> {

	public static final Type<IOpenWindowHandler> TYPE = new Type<IOpenWindowHandler>();

	/**
	 * The default list of features for the newly created window
	 */
	public static final String DEFAULT_WINDOW_FEATURES = "menubar=no,location=no,resizable=yes,scrollbars=yes,status=yes";

	/**
	 * The URL to display in the newly created window
	 */
	protected String url;
	/**
	 * The name to use for the newly created window
	 */
	protected String windowName;
	/**
	 * The string describing the window features
	 */
	protected String features;


	public OpenWindowEvent(String url, String windowName) {
		this.url = url;
		this.windowName = windowName;
		this.features = OpenWindowEvent.DEFAULT_WINDOW_FEATURES;
	}
	public OpenWindowEvent(String url, String windowName, String features) {
		this.url = url;
		this.windowName = windowName;
		this.features = features;
	}

	/**
	 * Url getter
	 * @return the url
	 */
	public String getUrl() {
		return this.url;
	}
	/**
	 * Window Name getter
	 * @return the window name
	 */
	public String getWindowName() {
		return this.windowName;
	}
	/**
	 * Window Name getter
	 * @return the configuration string for window features
	 */
	public String getFeatures() {
		return this.features;
	}

	/**
	 * Dispatch method. on dispatching we call the handler in the IOpenWindowHandler
	 * interface we are mapped to by the main event bus
	 */
	@Override
	protected void dispatch(IOpenWindowHandler handler) {
		handler.onOpenWindow(this);
	}

	/**
	 * returns a type used for mapping to IOpenWindowHandlers in the main event bus
	 */
	@Override
	public Type<IOpenWindowHandler> getAssociatedType() {
		return TYPE;
	}

	/**
	 * Static method for directly firing events on class having OpenWindowHandlers.
	 */
	public static void fire(IHasOpenWindowHandlers source, String url, String windowName) {
		source.fireEvent(new OpenWindowEvent(url, windowName));
	}
}
