package com.quartetfs.pivot.live.sandbox.shared.config.impl;

import com.quartetfs.pivot.live.core.shared.cmd.impl.ASessionIdAction;

public class ConfigAction extends ASessionIdAction<ConfigResult> {
	public ConfigAction() {}
}
