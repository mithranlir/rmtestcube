package com.quartetfs.pivot.live.sandbox.client.openhtmlpanel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.http.client.UrlBuilder;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.*;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.session.ISessionDynamicProvider;
import com.quartetfs.pivot.live.sandbox.shared.config.impl.ConfigConsts;
import com.quartetfs.pivot.live.sandbox.shared.config.impl.ConfigResultHolder;

public class OpenApPageInPanelCommand implements Command {

	protected final IEventBus eventBus;
	protected final ISessionDynamicProvider sessionDynamicProvider;
	protected final ConfigResultHolder configResultHolder;
	protected GridPopup popup;

	public OpenApPageInPanelCommand(IEventBus eventBus, ConfigResultHolder configResultHolder, ISessionDynamicProvider sessionDynamicProvider) {
		this.eventBus = eventBus;
		this.sessionDynamicProvider = sessionDynamicProvider;
		this.configResultHolder = configResultHolder;
	}

	@Override
	public void execute() {
		final String url = buildUrl();
		this.popup = new GridPopup(url);
		popup.center();
		popup.show();
	}

	public static native void forceReload() /*-{
        $wnd.location.reload(true);
    }-*/;

	public class GridPopup extends PopupPanel {
		public GridPopup(String url) {
			super(false, true);

			addStyleName("borderlessPopup");

			final Image closeButton = new Image(GWT.getHostPageBaseURL()+"resources/images/close.gif");
			closeButton.addClickHandler(new ClickHandler() {
				public void onClick(ClickEvent event) {
					GridPopup.this.hide();
				}
			});

			final Image reloadButton = new Image(GWT.getHostPageBaseURL()+"resources/images/reload.png");
			reloadButton.addClickHandler(new ClickHandler() {
				public void onClick(ClickEvent event) {
					GridPopup.this.hide();
					forceReload();
				}
			});

			// get host and port
			final Frame frame = new Frame(url);

			final String width = "1200px";
			final String height = "800px";

			frame.setWidth(width);
			frame.setHeight(height);
			frame.getElement().getStyle().setBorderWidth(0, Style.Unit.PX);

			final HorizontalPanel hpanel2 = new HorizontalPanel ();
			hpanel2.setWidth("20px");
			hpanel2.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
			hpanel2.setSpacing(2);
			hpanel2.add(closeButton);
			hpanel2.add(reloadButton);

			final HorizontalPanel hpanel = new HorizontalPanel ();
			hpanel.setWidth(width);
			hpanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
			hpanel.add(hpanel2);

			final VerticalPanel vpanel = new VerticalPanel ();
			vpanel.setHorizontalAlignment(HasAlignment.ALIGN_CENTER);
			vpanel.add(hpanel);
			vpanel.add(frame);


			setWidget(vpanel);
		}
	}

	public String buildUrl() {
		final String userId = sessionDynamicProvider.getSessionId().getUserId();
		final boolean sameContainer = "true".equals(getPropertyValue(ConfigConsts.SAME_CONTAINER));
		final String apLocalUrl = getPropertyValue(ConfigConsts.AP_LOCAL_URL);
		final String lastPart = apLocalUrl + "?" + "user=" + userId;

		if(sameContainer) {
			final UrlBuilder urlBuilder = new UrlBuilder();
			urlBuilder.setHost(Window.Location.getHost());
			urlBuilder.setPath(lastPart);
			final String port = Window.Location.getPort();
			if (!port.isEmpty()) {
				urlBuilder.setPort(Integer.parseInt(port));
			}

			return urlBuilder.buildString();
		}

		final String removeServerUrl = getPropertyValue(ConfigConsts.REMOTE_SERVER_URL);
		return removeServerUrl + "/" + lastPart;
	}


	private String getPropertyValue(String key) {
		return configResultHolder.getConfigResult().getConfig().get(key);
	}

	public GridPopup getPopup() {
		return popup;
	}
}
