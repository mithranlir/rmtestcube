/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client;

import com.quartetfs.pivot.live.client.desktop.IDesktopApplicationConstants;

/**
 * This Constants interface allows to override the constants used by the main application.
 * 
 * @author Quartet Financial Systems
 *
 */
public interface ISandBoxMainApplicationConstants extends IDesktopApplicationConstants {

	/**
	 * The info addin title
	 */
	@DefaultStringValue("More info ...")
	String infoTitle();

	/**
	 * The info addin tooltip
	 */
	@DefaultStringValue("Click for more information")
	String infoTooltip();

	/**
	 * the Quartet FS URL used by the info addin
	 */
	@DefaultStringValue("http://www.quartetfs.com")
	String quartetFSURL();

	/**
	 * the SandBox information message title
	 */
	@DefaultStringValue("SandBox Info")
	String sandBoxInfoTitle();

	/**
	 * the SandBox information message
	 */
	@DefaultStringValue("The SandBox project shows you the customizable part of ActivePivot Live application.")
	String sandBoxInfo();
}
