/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.open.event;

import com.google.gwt.event.shared.EventHandler;

/**
 * OpenWindowEvent handler interface for mapping within the main event bus.
 * 
 * @see OpenWindowEvent
 * 
 * @author Quartet Financial Systems
 *
 */
public interface IOpenWindowHandler extends EventHandler {

	/**
	 * the handler signature
	 * @param event the OpenWindowEvent dispatched
	 */
	void onOpenWindow(OpenWindowEvent event);
}
