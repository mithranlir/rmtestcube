package com.quartetfs.pivot.live.sandbox.client.filter.impl;

import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.RadioButton;
import com.quartetfs.pivot.live.client.utils.UserInputGridView;
import com.quartetfs.pivot.live.core.client.widget.IListBox;
import com.quartetfs.pivot.live.core.client.widget.impl.ListBoxAsTakesValue;
import com.quartetfs.pivot.live.sandbox.client.filter.IHeadTailPluginView;
import com.quartetfs.pivot.live.shared.model.definition.impl.FunctionDefinition;

public class HeadTailPluginView extends UserInputGridView implements IHeadTailPluginView{

	/**
	 * All widgets used in the view
	 */
	protected ListBoxAsTakesValue measures;
	protected RadioButton head;
	protected RadioButton tail;

	/**
	 * Build all ui element, in this case, two radio buttons and one list box containing
	 * all measures available
	 */
	@Override
	public void buildContent(){
		head = this.addRadio("function", "Head", "Head", true, false);
		tail = this.addRadio("function", "Tail", "Tail", true, false);

		ListBox listBox = new ListBox();
		measures = new ListBoxAsTakesValue(listBox);
		this.addRow(listBox);
	}

	/**
	 * Update the radio buttons state in particular, what the one need to be checked
	 */
	@Override
	public void updateContent(String functionDefinitionName){
		boolean a = functionDefinitionName.equals(FunctionDefinition.TAIL.getName());
		tail.setValue(a);
		head.setValue(!a);
	}

	/**
	 * Simple getter to have access to the list box in the presenter, the widget getters have always to return
	 * an interface
	 */
	@Override
	public IListBox getMeasuresListBox(){
		return measures;
	}

	@Override
	public String getCheckedRadioButtonValue(){
		return tail.getValue() ? FunctionDefinition.TAIL.getName() : FunctionDefinition.HEAD.getName();
	}
}
