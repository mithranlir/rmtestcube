package com.quartetfs.pivot.live.sandbox.server.paging.impl;

import com.quartetfs.pivot.live.core.server.cmd.IActionContext;
import com.quartetfs.pivot.live.core.server.utils.impl.ASessionHandler;
import com.quartetfs.pivot.live.core.shared.cmd.ActionException;
import com.quartetfs.pivot.live.sandbox.server.paging.IPagingService;
import com.quartetfs.pivot.live.sandbox.shared.paging.impl.PagingAction;
import com.quartetfs.pivot.live.sandbox.shared.paging.impl.PagingResult;

public class PagingHandler extends ASessionHandler<PagingAction, PagingResult> {
	@Override
	public PagingResult executeSession(PagingAction action, IActionContext context) throws ActionException {
		final IPagingService service = this.getSessionService(IPagingService.class);
		final Long resultSize = service.getResultSize();
		if(resultSize == null) {
			return new PagingResult(-1L);
		}
		return new PagingResult(resultSize);
	}
}
