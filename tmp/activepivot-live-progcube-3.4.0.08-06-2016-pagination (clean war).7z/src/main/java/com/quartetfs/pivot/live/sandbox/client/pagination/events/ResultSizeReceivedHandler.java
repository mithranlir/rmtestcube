package com.quartetfs.pivot.live.sandbox.client.pagination.events;


import com.google.gwt.event.shared.EventHandler;

public interface ResultSizeReceivedHandler extends EventHandler {
    void onResultSizeReceived(ResultSizeReceivedEvent event);
}
