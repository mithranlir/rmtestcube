package com.quartetfs.pivot.live.sandbox.shared.config.impl;

import java.io.Serializable;

public class ConfigConsts implements Serializable{
    public static final String REMOTE_SERVER_URL = "remoteServer.url";
    public static final String AP_LOCAL_URL = "ap.local.url";
    public static final String SAME_CONTAINER = "same.container";
}
