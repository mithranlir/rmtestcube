package com.quartetfs.pivot.live.sandbox.client.pagination.events;

import com.google.gwt.event.shared.GwtEvent;

public class CurrentPageEvent extends GwtEvent<CurrentPageHandler> {

    public static final Type<CurrentPageHandler> TYPE = new Type<>();

    private final Integer currentPage;

    public CurrentPageEvent(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public static Type<CurrentPageHandler> getType() {
        return TYPE;
    }

    public Integer getCurrentPage() {
        return currentPage;
    }

    @Override
    protected void dispatch(CurrentPageHandler handler) {
        handler.onCurrentPageChange(this);
    }

    @Override
    public Type<CurrentPageHandler> getAssociatedType() {
        return TYPE;
    }
}