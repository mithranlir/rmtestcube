package com.quartetfs.pivot.live.sandbox.shared.config.impl;

import com.quartetfs.pivot.live.core.shared.cmd.IResult;

import java.util.Map;

public class ConfigResult implements IResult {

	private static final long serialVersionUID = -5719163218095676886L;

	protected Map<String, String> config;

	protected ConfigResult() {}

	public ConfigResult(Map<String, String> config) {
		this.config = config;
	}

	public Map<String, String> getConfig() {
		return this.config;
	}
}
