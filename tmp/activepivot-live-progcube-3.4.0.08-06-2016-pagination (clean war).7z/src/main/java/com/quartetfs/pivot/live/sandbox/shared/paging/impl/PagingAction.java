package com.quartetfs.pivot.live.sandbox.shared.paging.impl;

import com.quartetfs.pivot.live.core.shared.cmd.impl.ASessionIdAction;

public class PagingAction extends ASessionIdAction<PagingResult> {
	public PagingAction() {}
}
