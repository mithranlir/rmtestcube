/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.open.impl;

import com.google.gwt.user.client.Command;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.sandbox.client.open.event.OpenWindowEvent;

/**
 * This command permits callers to open a new window pointing to a specific URL
 * with a list of options. It abstracts the OpenWindowEvent creation and
 * firing on the main event bus. Once fired this event is catched up by the
 * OpenWindowPresenter which is in charge of actually opening the window.
 * 
 * @see OpenWindowEvent
 * @see OpenWindowPresenter
 * 
 * @author Quartet Financial Systems
 *
 */
public class OpenWindowCommand implements Command {

	/**
	 * The main event bus
	 */
	protected final IEventBus eventBus;
	/**
	 * The url to point to
	 */
	protected String url;
	/**
	 * The name of the window
	 */
	protected String windowName;
	/**
	 * The configuration string for the new window features
	 */
	protected String features;

	/**
	 * Constructor with default list of window features.
	 * 
	 * @param url the url to point to.
	 * @param windowName the window name
	 * @param eventBus the main event bus
	 */
	public OpenWindowCommand(String url, String windowName, IEventBus eventBus) {
		this(url, windowName, null, eventBus);
	}
	/**
	 * Constructor with parametric list of window features.
	 * 
	 * @param url the url to point to.
	 * @param windowName the window name
	 * @param eventBus the main event bus
	 */
	public OpenWindowCommand(String url, String windowName, String features, IEventBus eventBus) {
		this.url = url;
		this.windowName = windowName;
		this.features = features;
		this.eventBus = eventBus;
	}

	/**
	 * THe execute method wich instantiates and fires an {@link OpenWindowEvent}
	 */
	@Override
	public void execute() {
		if(null != this.features)
			eventBus.fireEvent(new OpenWindowEvent(this.url, this.windowName, this.features));
		else
			eventBus.fireEvent(new OpenWindowEvent(this.url, this.windowName));
	}

}
