package com.quartetfs.pivot.live.sandbox.shared.config.impl;

public class ConfigResultHolder {

    private ConfigResult configResult;

    public ConfigResult getConfigResult() {
        return configResult;
    }

    public void setConfigResult(ConfigResult configResult) {
        this.configResult = configResult;
    }
}
