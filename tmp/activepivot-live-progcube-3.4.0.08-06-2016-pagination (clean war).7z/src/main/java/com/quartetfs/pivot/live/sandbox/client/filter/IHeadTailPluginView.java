package com.quartetfs.pivot.live.sandbox.client.filter;

import com.quartetfs.pivot.live.core.client.widget.IListBox;
import com.quartetfs.pivot.live.core.client.widget.IWidgetView;

public interface IHeadTailPluginView extends IWidgetView{

	void buildContent();

	void updateContent(String functionDefinitionName);

	IListBox getMeasuresListBox();

	String getCheckedRadioButtonValue();
}
