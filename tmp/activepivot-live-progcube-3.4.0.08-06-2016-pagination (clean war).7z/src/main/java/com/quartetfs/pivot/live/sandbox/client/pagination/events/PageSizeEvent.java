package com.quartetfs.pivot.live.sandbox.client.pagination.events;

import com.google.gwt.event.shared.GwtEvent;

public class PageSizeEvent extends GwtEvent<PageSizeHandler> {

    public static final Type<PageSizeHandler> TYPE = new Type<>();

    private final Long pageSize;

    public PageSizeEvent(Long pageSize) {
        this.pageSize = pageSize;
    }

    public static Type<PageSizeHandler> getType() {
        return TYPE;
    }

    public Long getPageSize() {
        return pageSize;
    }

    @Override
    protected void dispatch(PageSizeHandler handler) {
        handler.onPageSizeChange(this);
    }

    @Override
    public Type<PageSizeHandler> getAssociatedType() {
        return TYPE;
    }
}