package com.quartetfs.pivot.live.sandbox.client.pagination.events;

import com.google.gwt.event.shared.GwtEvent;

public class HidePagingEvent extends GwtEvent<HidePagingHandler> {

    public static final Type<HidePagingHandler> TYPE = new Type<>();

    public HidePagingEvent() {
    }

    public static Type<HidePagingHandler> getType() {
        return TYPE;
    }

    @Override
    protected void dispatch(HidePagingHandler handler) {
        handler.onHidePaging(this);
    }

    @Override
    public Type<HidePagingHandler> getAssociatedType() {
        return TYPE;
    }
}