package com.quartetfs.pivot.live.sandbox.client.pagination.events;


import com.google.gwt.event.shared.EventHandler;

public interface CurrentPageHandler extends EventHandler {
    void onCurrentPageChange(CurrentPageEvent event);
}
