package com.quartetfs.pivot.live.sandbox.server.paging;

import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

@WebService(
        targetNamespace = "http://www.quartetfs.com"
)
@SOAPBinding(
        style = SOAPBinding.Style.DOCUMENT,
        use = SOAPBinding.Use.LITERAL
)
public interface IPagingService {
    @WebMethod
    @WebResult(
            name = "resultSize"
    )
    Long getResultSize();
}
