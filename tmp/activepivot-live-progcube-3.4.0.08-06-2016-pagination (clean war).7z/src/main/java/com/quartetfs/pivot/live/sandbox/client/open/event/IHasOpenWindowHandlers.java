/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.open.event;

import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.event.shared.HasHandlers;

/**
 * Interface to fire event on the appropriate handler
 * 
 * @see HasHandlers
 * 
 * @author Quartet Financial Systems
 *
 */
public interface IHasOpenWindowHandlers extends HasHandlers {

	HandlerRegistration addOpenWindowHandler(IOpenWindowHandler handler);
}
