package com.quartetfs.pivot.live.sandbox.client.impl;


import com.google.inject.Inject;
import com.quartetfs.pivot.live.client.content.impl.ClientBookmarkRepository;
import com.quartetfs.pivot.live.client.mdx.IMdxLoadingHandler;
import com.quartetfs.pivot.live.client.mdx.impl.ClientDefaultMembersRepository;
import com.quartetfs.pivot.live.client.mdx.impl.ClientMemberCaptionRepository;
import com.quartetfs.pivot.live.client.mdx.impl.MdxModelPresenter;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.IRemoteEventPipe;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.settting.ISettingProvider;
import com.quartetfs.pivot.live.core.shared.session.impl.FeedClearEvent;
import com.quartetfs.pivot.live.core.shared.session.impl.FeedFailureEvent;
import com.quartetfs.pivot.live.core.shared.session.impl.FeedInterruptedEvent;
import com.quartetfs.pivot.live.sandbox.client.pagination.events.HidePagingEvent;
import com.quartetfs.pivot.live.sandbox.client.pagination.ResultSizeCommand;
import com.quartetfs.pivot.live.shared.mdx.IColorProvider;
import com.quartetfs.pivot.live.shared.mdx.QueryStateRemoteEvent;

public class CustomMdxModelPresenter extends MdxModelPresenter {

    private IEventBus mainBus;

    @Inject
    public CustomMdxModelPresenter(@Main IEventBus mainBus,
                                   IEventBus eventBus,
                                   ICommandExecutorAsync commandExecutorAsync,
                                   IRemoteEventPipe remoteEventPipe,
                                   ISettingProvider settingsProvider,
                                   IMdxLoadingHandler queryLoadingHandler,
                                   IColorProvider colorProvider,
                                   ClientMemberCaptionRepository memberCaptionRepository,
                                   ClientBookmarkRepository bookmarkRepository,
                                   ClientDefaultMembersRepository defaultMemberRepository) {
        super(mainBus, eventBus, commandExecutorAsync, remoteEventPipe, settingsProvider, queryLoadingHandler, colorProvider, memberCaptionRepository, bookmarkRepository, defaultMemberRepository);
        this.mainBus = mainBus;
    }

    @Override
    public void bind() {
        super.bind();
    }

    @Override
    public void onQueryState(QueryStateRemoteEvent event) {
        if(event.getFinished()) {
            System.out.println("execute ResultSizeCommand");
            final ResultSizeCommand command = new ResultSizeCommand(mainBus, commandExecutorAsync);
            command.execute();
        }
        super.onQueryState(event);
    }

    @Override
    public void onClear(FeedClearEvent event) {
        eventBus.fireEvent(new HidePagingEvent());
        super.onClear(event);
    }

    @Override
    public void onInterrupted(FeedInterruptedEvent event) {
        super.onInterrupted(event);
    }

    @Override
    public void onFailure(FeedFailureEvent event) {
        super.onFailure(event);
    }
}
