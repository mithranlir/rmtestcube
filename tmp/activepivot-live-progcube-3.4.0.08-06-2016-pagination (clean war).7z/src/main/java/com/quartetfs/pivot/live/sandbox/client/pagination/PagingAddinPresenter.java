package com.quartetfs.pivot.live.sandbox.client.pagination;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.HandlerRegistration;
import com.quartetfs.pivot.live.client.contextvalues.ContextValueClientSetEvent;
import com.quartetfs.pivot.live.client.contextvalues.IContextValueClientSetHandler;
import com.quartetfs.pivot.live.client.mdx.impl.MdxModelPresenter;
import com.quartetfs.pivot.live.client.storage.impl.HistoryStorageEvent;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.mvp.impl.AViewPresenter;
import com.quartetfs.pivot.live.core.client.widget.impl.LivePushButton;
import com.quartetfs.pivot.live.sandbox.client.pagination.events.*;
import com.quartetfs.pivot.live.shared.contextvalues.impl.FlatContextValue;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class PagingAddinPresenter extends AViewPresenter<IPagingAddinView>
        implements IPagingAddinPresenter, ClickHandler, ResultSizeReceivedHandler, IContextValueClientSetHandler, HidePagingHandler, PageSizeHandler, CurrentPageHandler {

    public static final String CURRENT_PAGE_CXTVALUE_NAME = "currentPage";

    private HandlerRegistration clickRegistration;
    private IEventBus eventBus;
    private Collection<HandlerRegistration> handlerRegistrations;
    private String streamType;

    protected int currentPage = 0;
    protected long resultSize = 0;
    protected long pagingSize = -1; // pagination disabled by default...

    public PagingAddinPresenter(IEventBus eventBus) {
        this.eventBus = eventBus;
        this.streamType = MdxModelPresenter.FEED_TYPE;
    }

    public void bind() {
        this.assertView();
        super.bind();
        this.clickRegistration = this.view.getActionTrigger().addClickHandler(this);
        this.view.update();

        this.addHandlerRegistration(this.eventBus.addHandler(ResultSizeReceivedEvent.TYPE, this));
        this.addHandlerRegistration(this.eventBus.addHandler(ContextValueClientSetEvent.TYPE, this));
        this.addHandlerRegistration(this.eventBus.addHandler(HidePagingEvent.TYPE, this));
        this.addHandlerRegistration(this.eventBus.addHandler(PageSizeEvent.TYPE, this));
        this.addHandlerRegistration(this.eventBus.addHandler(CurrentPageEvent.TYPE, this));
    }

    @Override
    public void unbind() {
        super.unbind();
        unbindClickRegistration();
        unbindHandlerRegistrations();
    }

    @Override
    public void onClick(ClickEvent clickEvent) {
        if(pagingSize>0) {
            final PageNavigationCommandDisplay pageNavigationCommandDisplay = (PageNavigationCommandDisplay) view;
            if (isEventFromButton(clickEvent, pageNavigationCommandDisplay.getStartButton())) {
                currentPage = 0;
                applyCurrentPageChanges();
            } else if (isEventFromButton(clickEvent, pageNavigationCommandDisplay.getPreviousButton())) {
                if (currentPage > 0) {
                    currentPage -= 1;
                    applyCurrentPageChanges();
                }
            } else if (isEventFromButton(clickEvent, pageNavigationCommandDisplay.getNextButton())) {
                if ((currentPage + 1) * pagingSize < resultSize) {
                    currentPage += 1;
                    applyCurrentPageChanges();
                }
            } else if (isEventFromButton(clickEvent, pageNavigationCommandDisplay.getEndButton())) {
                currentPage = (int) (resultSize / pagingSize);
                applyCurrentPageChanges();
            }
        }
    }

    @Override
    public void onResultSizeReceived(ResultSizeReceivedEvent event) {
        System.out.println("onResultSizeReceived " + event.getResultSize());
        resultSize = event.getResultSize();
        if(resultSize ==-1 ||  pagingSize==-1) {
            getView().hideButtonsAndTextbox();
        }
        else {
            updateTextBox();
            getView().showButtonsAndTextbox();
        }
    }

    @Override
    public void onValueChanged(ContextValueClientSetEvent contextValueClientSetEvent) {
        if(isPageSizeReceived(contextValueClientSetEvent)) {
            pagingSize = Integer.parseInt(contextValueClientSetEvent.getContextValue().getValue());
            updateTextBox();
        }
    }

    @Override
    public void onHidePaging(HidePagingEvent event) {
        getView().hideButtonsAndTextbox();
        currentPage = 0;
        updateTextBox();
    }

    @Override
    public void onPageSizeChange(PageSizeEvent event) {
        pagingSize = event.getPageSize();
        processPagingDisplay();
        updateTextBox();
    }

    @Override
    public void onCurrentPageChange(CurrentPageEvent event) {
        currentPage = event.getCurrentPage();
        processPagingDisplay();
        updateTextBox();
    }

    @Override
    public IPagingAddinView getView() {
        this.assertView();
        return super.getView();
    }

    private void processPagingDisplay() {
        if(mustHideButtons()) {
            currentPage = 0;
            getView().hideButtonsAndTextbox();
        }
        else {
            updateTextBox();
            getView().showButtonsAndTextbox();
        }
    }

    private boolean mustHideButtons() {
        return pagingSize<=0;
    }

    private Collection<HandlerRegistration> createHandlerRegistrationsCollection() {
        return new ArrayList();
    }

    private void addHandlerRegistration(HandlerRegistration hR) {
        if(null == this.handlerRegistrations) {
            this.handlerRegistrations = this.createHandlerRegistrationsCollection();
        }
        this.handlerRegistrations.add(hR);
    }

    private void unbindClickRegistration() {
        if (clickRegistration != null) {
            clickRegistration.removeHandler();
        }
        clickRegistration = null;
    }

    private void unbindHandlerRegistrations() {
        if(null != this.handlerRegistrations) {
            final Iterator iter = this.handlerRegistrations.iterator();
            while(iter.hasNext()) {
                HandlerRegistration hR = (HandlerRegistration)iter.next();
                hR.removeHandler();
            }
            this.handlerRegistrations.clear();
        }
    }

    protected void assertView() {
        if(this.view == null) {
            final PageNavigationCommandDisplay v = new PageNavigationCommandDisplay();
            this.setView(v);
        }
    }

    public void setMaximumHeight(int maximumHeight) {
        this.getView().setMaxHeight(maximumHeight);
    }

    private void applyCurrentPageChanges() {
        final FlatContextValue contextValue = new FlatContextValue(CURRENT_PAGE_CXTVALUE_NAME, currentPage+"");
        this.eventBus.fireEvent(new HistoryStorageEvent("Change context value \'" + CURRENT_PAGE_CXTVALUE_NAME + "\' to \'" + currentPage + "\'"));
        this.eventBus.fireEvent(new ContextValueClientSetEvent(contextValue, this.streamType));
        updateTextBox();
    }

    private boolean isEventFromButton(ClickEvent clickEvent, LivePushButton button) {
        return button.equals(clickEvent.getSource());
    }

    private void updateTextBox() {
        getView().getTextBox().setHTML(
                PagingHelper.createText(currentPage, resultSize, pagingSize));
    }

    private boolean isPageSizeReceived(ContextValueClientSetEvent contextValueClientSetEvent) {
        return contextValueClientSetEvent.getContextValue()!=null &&  PageSizeSelectorPresenter.PAGE_SIZE_KEY.equals(contextValueClientSetEvent.getContextValue().getName());
    }

}
