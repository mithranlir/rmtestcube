/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.impl;

import com.google.inject.Inject;
import com.quartetfs.pivot.live.client.drillthrough.DrillthroughContextEvent;
import com.quartetfs.pivot.live.client.drillthrough.IDrillthroughContextHandler;
import com.quartetfs.pivot.live.client.drillthrough.IDrillthroughDataCell;
import com.quartetfs.pivot.live.client.mdx.table.PivotCellContextEvent;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.mvp.impl.AEventPresenter;
import com.quartetfs.pivot.live.core.client.widget.IContextMenuEntry;
import com.quartetfs.pivot.live.core.client.widget.impl.ContextMenuEntry;
import com.quartetfs.pivot.live.sandbox.client.message.IMessage;
import com.quartetfs.pivot.live.sandbox.client.message.impl.MessageCommand;

/**
 * The SandBoxDrillthroughCellCommandPresenter listens for IDrillthroughContextHandler events propagated
 * by the drillthrough when a cell is right clicked.
 * 
 * This allows to add new entries to the contextual menu associated with custom commands.
 * 
 * @author Quartet Financial Systems
 *
 */
public class SandBoxDrillthroughCellCommandPresenter extends AEventPresenter implements IDrillthroughContextHandler {

	/**
	 * The higher level 'SandBox' menu entry
	 */
	protected final IContextMenuEntry contextMenuEntrySandBox = new ContextMenuEntry("SANDBOX_MENU", "[SandBox] Drillthrough cell details");

	/**
	 * We rely on Gin injection for instantiating this Presenter.
	 * 
	 * @param eventBus the main event bus
	 */
	@Inject
	public SandBoxDrillthroughCellCommandPresenter(@Main IEventBus eventBus) {
		super(eventBus);
	}

	/**
	 * At binding we register as handler of the DrillthroughContextEvent
	 * 
	 * @see PivotCellContextEvent
	 */
	@Override
	public void bind() {
		super.bind();
		addHandlerRegistration(eventBus.addHandler(DrillthroughContextEvent.TYPE, this));
	}

	@Override
	public void onDrillthroughContext(DrillthroughContextEvent event) {
		if(event.getDrillthroughCell() != null){
			//Add separator
			event.getContextMenuBuilder().addSeparator();

			// We add the Dummy Command
			MessageCommand dCmd = new MessageCommand(new DrillthroughCellMessage(event));

			//We add entry to execute command
			event.getContextMenuBuilder().addEntry(contextMenuEntrySandBox, dCmd);
		}
	}

	/**
	 * Compute an DrillthroughContextEvent event into a human readable message
	 * 
	 * @author Quartet Financial Systems
	 */
	public class DrillthroughCellMessage implements IMessage {

		final DrillthroughContextEvent event;

		public DrillthroughCellMessage(DrillthroughContextEvent event) {
			this.event = event;
		}

		@Override
		public String computeBody() {
			IDrillthroughDataCell cell = event.getDrillthroughCell();

			StringBuilder messageBuilder = new StringBuilder("<b>IDrillthroughDataCell :</b><br/>");

			//Header
			messageBuilder.append(cell.getHeaderName());
			messageBuilder.append(" : ");
			messageBuilder.append(cell.getValue());

			return messageBuilder.toString();
		}

		@Override
		public String computeHeader() {
			return "Drillthrough Cell Details";
		}

	}
}
