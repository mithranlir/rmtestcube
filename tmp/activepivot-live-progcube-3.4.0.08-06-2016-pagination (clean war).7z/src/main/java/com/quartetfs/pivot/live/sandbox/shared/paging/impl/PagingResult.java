package com.quartetfs.pivot.live.sandbox.shared.paging.impl;

import com.quartetfs.pivot.live.core.shared.cmd.IResult;

import java.util.Map;

public class PagingResult implements IResult {
	private static final long serialVersionUID = -5406455680715926700L;
	protected Long resultSize;
	public PagingResult() {}
	public PagingResult(Long resultSize) {
		this.resultSize = resultSize;
	}
	public Long getResultSize() {
		return this.resultSize;
	}
}
