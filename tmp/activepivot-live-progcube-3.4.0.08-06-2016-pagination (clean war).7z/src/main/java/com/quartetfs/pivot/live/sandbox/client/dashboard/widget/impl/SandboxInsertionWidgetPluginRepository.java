package com.quartetfs.pivot.live.sandbox.client.dashboard.widget.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.IInsertionWidgetPluginRepository;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.comments.impl.InsertionCommentsPlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.drillthrough.impl.InsertionDrillthroughPlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.iframe.impl.InsertionIframePlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.impl.InsertionWidgetPluginRepository;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.pivot.impl.InsertionPivotViewPlugin;
import com.quartetfs.pivot.live.sandbox.client.dashboard.widget.mdx.impl.CustomMdxWidgetPlugin;

/**
 * New {@link InsertionWidgetPluginRepository}. Here we add our new widget
 * to the original list. Don't forget to rebind
 * with Gin {@link IInsertionWidgetPluginRepository} to this implementation.
 * @author Quartet F.S
 */
public class SandboxInsertionWidgetPluginRepository extends InsertionWidgetPluginRepository {

	public final static String SANDBOX_GROUP = "Sandbox widgets";

	@Inject
	public SandboxInsertionWidgetPluginRepository(
			Provider<InsertionPivotViewPlugin> insertionPivotTablePluginProvider,
			InsertionDrillthroughPlugin insertionDrillthroughPlugin,
			InsertionCommentsPlugin insertionCommentsPlugin,
			InsertionIframePlugin insertionIframePlugin,
			CustomMdxWidgetPlugin mdxWidgetPlugin) {
		super(insertionPivotTablePluginProvider, insertionDrillthroughPlugin,
				insertionCommentsPlugin, insertionIframePlugin);

		insertionWidgetPlugin.add(mdxWidgetPlugin.group(SANDBOX_GROUP));
	}

}
