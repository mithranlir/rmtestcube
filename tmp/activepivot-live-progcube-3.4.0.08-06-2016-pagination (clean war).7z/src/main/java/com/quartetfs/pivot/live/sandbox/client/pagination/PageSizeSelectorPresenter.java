package com.quartetfs.pivot.live.sandbox.client.pagination;

import com.quartetfs.pivot.live.client.contextvalues.ContextValueEnabledEvent;
import com.quartetfs.pivot.live.client.contextvalues.ContextValueValueChangedEvent;
import com.quartetfs.pivot.live.client.contextvalues.impl.AContextValueAddinPresenter;
import com.quartetfs.pivot.live.client.mdx.impl.MdxModelPresenter;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.widget.addin.impl.ListBoxAddinView;
import com.quartetfs.pivot.live.sandbox.client.pagination.events.CurrentPageEvent;
import com.quartetfs.pivot.live.sandbox.client.pagination.events.PageSizeEvent;
import com.quartetfs.pivot.live.shared.contextvalues.IFlatContextValue;

import java.util.Arrays;
import java.util.List;

public class PageSizeSelectorPresenter extends AContextValueAddinPresenter<ListBoxAddinView> {

	public final static String PAGE_SIZE_KEY = "pageSize";

	public PageSizeSelectorPresenter(IEventBus mainEventBus) {
		super(mainEventBus, MdxModelPresenter.FEED_TYPE, PAGE_SIZE_KEY);
		assertView();
	}

	@Override
	public void bind() {
		super.bind();
		//Configure view
		this.getView().setLabel("");
		this.getView().clearValues();
		this.getView().addValues(getAvailableValues());
	}

	private List<String[]> getAvailableValues() {
		return Arrays.asList(
				new String[]{"-1", "no pag."},
				new String[]{"50", "50"},
				new String[]{"100", "100"},
				new String[]{"200", "200"},
				new String[]{"400", "400"},
				new String[]{"500", "500"}
		);
	}

	protected void assertView(){
		if(this.getView() == null){
			ListBoxAddinView v = new ListBoxAddinView();
			setView(v);
		}
	}

	@Override
	public void onEnabled(ContextValueEnabledEvent event) {
		processContextValueIPageSize(event.getContextValue());
		processContextValueIfCurrentPage(event.getContextValue());
		super.onEnabled(event);
	}

	@Override
	public void onValueChanged(ContextValueValueChangedEvent event) {
		processContextValueIPageSize(event.getContextValue());
		//processContextValueIfCurrentPage(event.getContextValue());
		super.onValueChanged(event);
	}

	private void processContextValueIPageSize(IFlatContextValue contextValue) {
		if (contextValue.getName().equals(this.contextValueName)
				&& contextValue.getValue()!=null
				&& !contextValue.getValue().isEmpty()) {
			final String initialPageSizeStr = contextValue.getValue();
			final Long initialPageSize = Long.parseLong(initialPageSizeStr);
			this.eventBus.fireEvent(new PageSizeEvent(initialPageSize));
		}
	}

	private void processContextValueIfCurrentPage(IFlatContextValue contextValue) {
		if(contextValue.getName().equals(PagingAddinPresenter.CURRENT_PAGE_CXTVALUE_NAME)) {
			final String currentPageStr = contextValue.getValue();
			final Integer currentPage = Integer.parseInt(currentPageStr);
			this.eventBus.fireEvent(new CurrentPageEvent(currentPage));
		}

	}
}
