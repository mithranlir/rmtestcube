package com.quartetfs.pivot.live.sandbox.client.dashboard.widget.mdx.impl;

import com.google.gwt.user.client.ui.HasValue;
import com.google.gwt.user.client.ui.Image;
import com.google.inject.Inject;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.IDashboardWidget;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.impl.AInsertionPlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.impl.DashboardWidget;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.impl.MdxBusSwitch;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.impl.MdxPluginSelectHandler;
import com.quartetfs.pivot.live.client.mdx.IMdxModelSwitch;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.impl.ValueWrapper;
import com.quartetfs.pivot.live.core.client.settting.ISettingProvider;
import com.quartetfs.pivot.live.core.shared.util.GenericCommand;

/**
 * @author Quartet F.S
 */
public class CustomMdxWidgetPlugin extends AInsertionPlugin{

	/**
	 * Unique plugin identifier
	 */
	public final static String CUSTOM_MDX_WIDGET_PLUGIN_ID = "CUSTOM_MDX_WIDGET_PLUGIN_ID";

	protected final static String TITLE = "Custom Mdx Widget";

	protected final IMdxModelSwitch mdxModelSwitch;
	protected final ISettingProvider settingProvider;
	protected final MdxBusSwitch mdxBusSwitch;

	@Inject
	public CustomMdxWidgetPlugin(@Main IEventBus eventBus, ISettingProvider settingProvider, IMdxModelSwitch mdxModelSwitch) {
		super(eventBus);
		this.settingProvider = settingProvider;
		this.mdxModelSwitch = mdxModelSwitch;
		this.mdxBusSwitch = new MdxBusSwitch(eventBus, mdxModelSwitch);
	}

	@Override
	public String getKey() {
		return CUSTOM_MDX_WIDGET_PLUGIN_ID;
	}

	@Override
	public void createWidget(GenericCommand<IDashboardWidget> callback) {
		CustomMdxWidgetPresenter presenter = new CustomMdxWidgetPresenter(eventBus, mdxModelSwitch);

		HasValue<String> titleWrapper = new ValueWrapper<String>(TITLE);
		presenter.setTitleWrapper(titleWrapper);
		presenter.setView(new CustomMdxWidgetView());

		IDashboardWidget dashboardWidget = new DashboardWidget(getKey(), titleWrapper, presenter.getView(), presenter)
		.withWidgetSelector(presenter)
		.withSelectedCallback(new MdxPluginSelectHandler<CustomMdxWidgetPresenter>(getKey(), getTitle(), eventBus, settingProvider, mdxBusSwitch, presenter));

		callback.execute(dashboardWidget);
	}

	@Override
	public String getTitle() {
		return TITLE;
	}

	@Override
	protected Image getImageResource() {
		return null;
	}

}
