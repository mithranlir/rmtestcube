/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.message;

/**
 * Interface provided to compute a string message only when needed
 * 
 * @author Quartet Financial Systems
 */
public interface IMessage {

	/** Compute a String body message */
	String computeBody();

	/** Compute a String header message */
	String computeHeader();
}
