/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.impl;

import com.google.inject.Inject;
import com.quartetfs.pivot.live.client.content.ContentContextEvent;
import com.quartetfs.pivot.live.client.content.IContentContextHandler;
import com.quartetfs.pivot.live.content.shared.IContent;
import com.quartetfs.pivot.live.content.shared.impl.GroupFolder;
import com.quartetfs.pivot.live.content.shared.impl.UserFolder;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.mvp.impl.AEventPresenter;
import com.quartetfs.pivot.live.core.client.widget.IContextMenuEntry;
import com.quartetfs.pivot.live.core.client.widget.impl.ContextMenuEntry;
import com.quartetfs.pivot.live.sandbox.client.message.IMessage;
import com.quartetfs.pivot.live.sandbox.client.message.impl.MessageCommand;
import com.quartetfs.pivot.live.shared.content.impl.DrillthroughBookmark;
import com.quartetfs.pivot.live.shared.content.impl.FolderBookmark;
import com.quartetfs.pivot.live.shared.content.impl.MDXBookmark;

/**
 * The SandBoxContentCommandPresenter listens for ContentContextHandler events propagated
 * by the bookmark when an element of the tree is right clicked.
 * 
 * This allows to add new entries to the contextual menu associated with custom commands.
 * 
 * @author Quartet Financial Systems
 *
 */
public class SandBoxContentCommandPresenter extends AEventPresenter implements IContentContextHandler{

	/**
	 * The higher level 'SandBox' menu entry
	 */
	protected final IContextMenuEntry contextMenuEntrySandBox = new ContextMenuEntry("SANDBOX_MENU", "[SandBox] Content details");

	/**
	 * We rely on Gin injection for instantiating this Presenter.
	 * @param eventBus the main event bus
	 */
	@Inject
	public SandBoxContentCommandPresenter(	@Main IEventBus eventBus) {
		super(eventBus);
	}

	/**
	 * At binding we register as handler of the ContentContextEvent
	 * 
	 * @see ContentContextEvent
	 */
	@Override
	public void bind() {
		super.bind();
		addHandlerRegistration(eventBus.addHandler(ContentContextEvent.TYPE, this));
	}

	@Override
	public void onContentContext(ContentContextEvent event) {
		if(event.getContent() != null){
			//Add separator
			event.getContextMenuBuilder().addSeparator();

			// We add the Dummy Command
			MessageCommand dCmd = new MessageCommand(new ContentContextMessage(event));

			//We add entry to execute command
			event.getContextMenuBuilder().addEntry(contextMenuEntrySandBox, dCmd);
		}
	}

	/**
	 * Compute an ContentContextEvent event into a human readable message
	 * 
	 * @author Quartet Financial Systems
	 */
	public class ContentContextMessage implements IMessage {

		final ContentContextEvent event;

		public ContentContextMessage(ContentContextEvent event) {
			this.event = event;
		}

		@Override
		public String computeBody() {
			StringBuilder messageBuilder = new StringBuilder();

			//Retrieve content
			IContent content = event.getContent();

			//Add title
			messageBuilder.append("'<b>");
			messageBuilder.append(content.getTitle());
			messageBuilder.append("</b>'");

			//Check type
			if(content instanceof DrillthroughBookmark)
				messageBuilder.append(" is a Drillthrough Bookmark.");
			else if(content instanceof MDXBookmark)
				messageBuilder.append(" is a MDX Bookmark.");
			else if(content instanceof FolderBookmark)
				messageBuilder.append(" is a Bookmark Folder.");
			else if(content instanceof UserFolder)
				messageBuilder.append(" is a User Folder.");
			else if(content instanceof GroupFolder)
				messageBuilder.append(" is a Group Folder.");
			else
				messageBuilder.append(" is of unknown type.");

			return messageBuilder.toString();
		}

		@Override
		public String computeHeader() {
			return "Content Details";
		}

	}
}
