/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.gin;

import com.google.gwt.inject.client.GinModules;
import com.quartetfs.pivot.live.client.desktop.gin.IDesktopGinjector;
import com.quartetfs.pivot.live.sandbox.client.ISandBoxMainApplicationConstants;
import com.quartetfs.pivot.live.sandbox.client.gin.impl.SandBoxGinModule;

/**
 * The APL SandBox Ginjector. Allows retrieval of the main classes of the application
 * as well as resources and constants
 * 
 * @author Quartet Financial Systems
 */
@GinModules({
	SandBoxGinModule.class
})
public interface ISandBoxGinjector extends IDesktopGinjector {

	/**
	 * The constants
	 */
	@Override
	ISandBoxMainApplicationConstants constants();

}
