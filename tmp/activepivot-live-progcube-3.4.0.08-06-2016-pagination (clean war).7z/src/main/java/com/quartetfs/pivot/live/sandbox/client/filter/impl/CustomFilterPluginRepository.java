package com.quartetfs.pivot.live.sandbox.client.filter.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.quartetfs.pivot.live.client.mdx.filter.impl.FilterPluginRepository;
import com.quartetfs.pivot.live.client.mdx.filter.impl.date.ReferenceDatePresenter;
import com.quartetfs.pivot.live.client.utils.ListBoxGenerator;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.sandbox.client.filter.impl.HeadTailPluginPresenter;

public class CustomFilterPluginRepository extends FilterPluginRepository{

	@Inject
	public CustomFilterPluginRepository(@Main IEventBus eventBus,
			ICommandExecutorAsync commandExecutorAsync,
			ListBoxGenerator listBoxGenerator,
			Provider<ReferenceDatePresenter> referenceDatePresenterProvider) {
		super(eventBus, commandExecutorAsync, listBoxGenerator,
				referenceDatePresenterProvider);

		//add the presenter in the list of available plugins by instantiating a new presenter
		addPlugin(new HeadTailPluginPresenter(eventBus, listBoxGenerator, "Head/Tail plugin", 6));
	}

}
