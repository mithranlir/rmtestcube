package com.quartetfs.pivot.live.sandbox.client.dashboard.template.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.ITemplatePlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.ITemplatePluginRepository;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.impl.RectangularGridTemplatePlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.impl.SplitHorizontalTemplatePlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.impl.SplitVerticalTemplatePlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.impl.SquareGridTemplatePlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.impl.StackedHorizontalTemplatePlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.impl.StackedVerticalTemplatePlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.impl.TabTemplatePlugin;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.impl.TemplatePluginRepository;

/**
 * New {@link TemplatePluginRepository}. Here we add our new template
 * to the original list. Don't forget to rebind
 * with Gin {@link ITemplatePluginRepository} to this implementation.
 * @author Quartet F.S
 */
public class MyTemplatePluginRepository extends TemplatePluginRepository{

	@Inject
	public MyTemplatePluginRepository(Provider<StackedHorizontalTemplatePlugin> stackedHorizontalTemplatePluginProvider,
			Provider<SplitHorizontalTemplatePlugin> splitHorizontalTemplatePluginProvider,
			Provider<StackedVerticalTemplatePlugin> stackedVerticalTemplatePluginProvider,
			Provider<SplitVerticalTemplatePlugin> splitVerticalTemplatePluginProvider,
			Provider<TabTemplatePlugin> tabTemplatePluginProvider,
			Provider<SquareGridTemplatePlugin> squareGridTemplatePluginProvider,
			Provider<RectangularGridTemplatePlugin> rectangularGridTemplatePluginProvider,
			Provider<MyAwesomeTemplate> myAwesomeTemplateProvider) {

		super(stackedHorizontalTemplatePluginProvider,
                splitHorizontalTemplatePluginProvider,
                stackedVerticalTemplatePluginProvider,
                splitVerticalTemplatePluginProvider,
                tabTemplatePluginProvider,
                squareGridTemplatePluginProvider,
                rectangularGridTemplatePluginProvider);

		ITemplatePlugin myAwesomeTemplate = myAwesomeTemplateProvider.get().group("My templates");//add it to My Templates group,

		templatePlugins.add(myAwesomeTemplate);//add it to the plugin repository
	}

}
