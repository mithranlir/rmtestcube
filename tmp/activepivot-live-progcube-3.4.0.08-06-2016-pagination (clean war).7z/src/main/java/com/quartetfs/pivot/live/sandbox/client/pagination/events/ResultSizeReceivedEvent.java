package com.quartetfs.pivot.live.sandbox.client.pagination.events;

import com.google.gwt.event.shared.GwtEvent;

public class ResultSizeReceivedEvent extends GwtEvent<ResultSizeReceivedHandler> {

    public static final Type<ResultSizeReceivedHandler> TYPE = new Type<>();

    private final Long resultSize;

    public ResultSizeReceivedEvent(Long resultSize) {
        this.resultSize = resultSize;
    }

    public static Type<ResultSizeReceivedHandler> getType() {
        return TYPE;
    }

    public Long getResultSize() {
        return resultSize;
    }

    @Override
    protected void dispatch(ResultSizeReceivedHandler handler) {
        handler.onResultSizeReceived(this);
    }

    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<ResultSizeReceivedHandler> getAssociatedType() {
        return TYPE;
    }
}