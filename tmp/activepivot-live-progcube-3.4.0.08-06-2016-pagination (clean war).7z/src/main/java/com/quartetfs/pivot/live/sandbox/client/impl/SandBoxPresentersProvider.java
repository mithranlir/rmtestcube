/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.impl;

import com.google.inject.Inject;
import com.quartetfs.pivot.live.client.desktop.impl.DesktopApplicationPresentersProvider;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.settting.ISettingProvider;
import com.quartetfs.pivot.live.sandbox.client.gin.impl.SandBoxGinModule;
import com.quartetfs.pivot.live.sandbox.client.open.impl.OpenWindowPresenter;

/**
 * The standard main application presenters provider. This Presenter Provided is injected by Gin to
 * the main application presenter. The main application presenter will call bind on each of these
 * presenters. The binding of this PresenterProviders is done in the SandBoxGinModule
 * 
 * This presenter provider extends the StandardMainAppPresentersProvider which list all the presenters
 * required by Active Pivot Live. It adds the custom presenters designed for the SandBox
 * 
 * @see SandBoxPivotCellCommandPresenter
 * @see OpenWindowPresenter
 * @see DesktopApplicationPresentersProvider
 * @see SandBoxGinModule
 * 
 * @author Quartet Financial Systems
 */
public class SandBoxPresentersProvider extends DesktopApplicationPresentersProvider {

	@Inject
	public SandBoxPresentersProvider(@Main IEventBus eventBus, ISettingProvider settingProvider) {
		super(eventBus, settingProvider);
	}

	/**
	 * Adds by injection the SandBoxPivotCellCommandPresenter to the list of presenters
	 * used by the Active Pivot Live SandBox application
	 * 
	 * @param sandBoxPivotCellCommandPresenter {@link SandBoxPivotCellCommandPresenter}
	 */
	@Inject
	public void setSandBoxPivotCellCommandPresenter(SandBoxPivotCellCommandPresenter sandBoxPivotCellCommandPresenter) {
		this.presenters.add(sandBoxPivotCellCommandPresenter);
	}

	/**
	 * Adds by injection the SandBoxContentCommandPresenter to the list of presenters
	 * used by the Active Pivot Live SandBox application
	 * 
	 * @param sandBoxContentCommandPresenter {@link SandBoxContentCommandPresenter}
	 */
	@Inject
	public void setSandBoxContentCommandPresenter(SandBoxContentCommandPresenter sandBoxContentCommandPresenter) {
		this.presenters.add(sandBoxContentCommandPresenter);
	}

	/**
	 * Adds by injection the SandBoxDrillthroughCellCommandPresenter to the list of presenters
	 * used by the Active Pivot Live SandBox application
	 * 
	 * @param sandBoxDrillthroughCellCommandPresenter {@link SandBoxDrillthroughCellCommandPresenter}
	 */
	@Inject
	public void setSandBoxDrillthroughCellCommandPresenter(SandBoxDrillthroughCellCommandPresenter sandBoxDrillthroughCellCommandPresenter) {
		this.presenters.add(sandBoxDrillthroughCellCommandPresenter);
	}

	/**
	 * Adds by injection the OpenWindowPresenter to the list of presenters
	 * used by the Active Pivot Live SandBox application
	 * 
	 * @param openWindowPresenter {@link OpenWindowPresenter}
	 */
	@Inject
	public void setOpenWindowPresenter(OpenWindowPresenter openWindowPresenter) {
		this.presenters.add(openWindowPresenter);
	}
}
