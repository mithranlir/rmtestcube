package com.quartetfs.pivot.live.sandbox.client.pagination.events;


import com.google.gwt.event.shared.EventHandler;

public interface HidePagingHandler extends EventHandler {
    void onHidePaging(HidePagingEvent event);
}
