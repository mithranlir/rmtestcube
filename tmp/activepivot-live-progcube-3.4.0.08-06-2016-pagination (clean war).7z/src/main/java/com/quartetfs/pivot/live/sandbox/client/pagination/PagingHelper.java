package com.quartetfs.pivot.live.sandbox.client.pagination;

public class PagingHelper {

    public static String createText(int currentPage, long resultSize, long pagingSize) {
        if(pagingSize == -1) {
            return "";
        }
        else {
            if(pagingSize == 0) {
                return createText(0, 0);
            }
            long nbPage = resultSize / pagingSize;
            if(resultSize % pagingSize > 0) {
                nbPage+=1;
            }

            if(nbPage == 0) {
                nbPage = 1;
            }
            return createText(currentPage, nbPage);
        }
    }

    private static String createText(int currentPage, long nbPage) {
        return (currentPage + 1)  + " / " + nbPage;
    }

}
