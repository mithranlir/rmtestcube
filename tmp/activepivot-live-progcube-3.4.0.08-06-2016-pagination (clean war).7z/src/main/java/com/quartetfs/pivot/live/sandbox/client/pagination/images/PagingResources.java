package com.quartetfs.pivot.live.sandbox.client.pagination.images;

import com.google.gwt.core.shared.GWT;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

public interface PagingResources extends ClientBundle {

    PagingResources INSTANCE = GWT.create(PagingResources.class);

    ImageResource arrowLeft();
    ImageResource arrowRight();
    ImageResource doubleArrowLeft();
    ImageResource doubleArrowRight();

    ImageResource arrowLeftW();
    ImageResource arrowRightW();
    ImageResource doubleArrowLeftW();
    ImageResource doubleArrowRightW();

}
