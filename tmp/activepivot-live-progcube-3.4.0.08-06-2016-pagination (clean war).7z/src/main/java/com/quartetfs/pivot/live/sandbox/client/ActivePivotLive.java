/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client;

import com.google.gwt.core.client.EntryPoint;
import com.quartetfs.pivot.live.client.IBootstrapper;
import com.quartetfs.pivot.live.sandbox.client.gin.impl.SandBoxGinBootstrapper;

/**
 * The top level application
 * 
 * @author Quartet Financial Systems
 */
public final class ActivePivotLive implements EntryPoint {

	/**
	 * This is the entry-point method.
	 */
	@Override
	public void onModuleLoad() {
		//Create the SandBox bootstrapper
		IBootstrapper bootstrapper = new SandBoxGinBootstrapper();

		//Run it
		bootstrapper.run();
	}
}
