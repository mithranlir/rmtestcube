package com.quartetfs.pivot.live.sandbox.server.config.impl;

import com.quartetfs.pivot.live.core.server.cmd.IActionContext;
import com.quartetfs.pivot.live.core.server.utils.impl.ASessionHandler;
import com.quartetfs.pivot.live.core.shared.cmd.ActionException;
import com.quartetfs.pivot.live.sandbox.shared.config.impl.ConfigAction;
import com.quartetfs.pivot.live.sandbox.shared.config.impl.ConfigResult;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.quartetfs.pivot.live.sandbox.shared.config.impl.ConfigConsts.*;

public class ConfigHandler extends ASessionHandler<ConfigAction, ConfigResult> implements ApplicationContextAware {

	public static final List<String> ALL_CONF = Arrays.asList(REMOTE_SERVER_URL, AP_LOCAL_URL, SAME_CONTAINER);

	private static ApplicationContext applicationContext;

	@Override
	public void setApplicationContext(ApplicationContext ac) throws BeansException {
		applicationContext = ac;
	}

	@Override
	public ConfigResult executeSession(ConfigAction action, IActionContext context) throws ActionException {
		try {
			final Map<String, String> configMap = readConfig(ALL_CONF);
			return new ConfigResult(configMap);
		}
		catch (Exception e) {
			throw new ActionException(e);
		}
	}

	private Map<String, String> readConfig(List<String>  keys) {
		final Map<String, String> map = new HashMap<>();
		final ConfigurableListableBeanFactory beanFactory = ((ConfigurableApplicationContext)applicationContext).getBeanFactory();
		for(String key : keys) {
			String value = beanFactory.resolveEmbeddedValue("${" + key + "}");
			map.put(key, value);
		}
		return map;
	}

}
