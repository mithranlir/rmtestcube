/*
 * (C) Quartet FS 2013
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.dashboard.widget.mdx.impl;

import java.util.HashMap;
import java.util.Map;

import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.user.client.impl.GwtUtils;
import com.quartetfs.pivot.live.client.desktop.dashboard.impl.AMdxDashboardWidgetPresenter;
import com.quartetfs.pivot.live.client.impl.QueryLoadingEvent.QueryLoadingState;
import com.quartetfs.pivot.live.client.mdx.IMdxModelSwitch;
import com.quartetfs.pivot.live.client.mdx.MdxCellsUpdatedEvent;
import com.quartetfs.pivot.live.client.mdx.MdxFailureEvent;
import com.quartetfs.pivot.live.client.mdx.MdxModelModifiedEvent;
import com.quartetfs.pivot.live.client.mdx.widget.IMdxWizardWidget;
import com.quartetfs.pivot.live.core.client.event.FailureEvent;
import com.quartetfs.pivot.live.core.client.event.FailureType;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.shared.Cell;
import com.quartetfs.pivot.live.shared.HierarchyWrapper;
import com.quartetfs.pivot.live.shared.mdx.IHumanReadableCellCursor;
import com.quartetfs.pivot.live.shared.mdx.IMdxModel;
import com.quartetfs.pivot.live.shared.mdx.IMdxModel.ICellProcedure;
import com.quartetfs.pivot.live.shared.mdx.grid.render.impl.LayeredStringBuilder;
import com.quartetfs.pivot.live.shared.mdx.impl.CellCursor;

/**
 * Presenter that displays a pivot table based on current MDX & a given color<br/>
 * Automatically save all parameters (MDX & color in our case)
 * @author Quartet FS
 */
public class CustomMdxWidgetPresenter extends AMdxDashboardWidgetPresenter<CustomMdxWidgetView> implements
IMdxWizardWidget, /*implement this interface if you need the wizard to be enabled when widget is selected. Remove it to hide wizard*/
ValueChangeHandler<String>{

	public CustomMdxWidgetPresenter(IEventBus eventBus, IMdxModelSwitch mdxModelSwitch) {
		super(eventBus, mdxModelSwitch);
	}

	/* TO UPDATE COLOR */
	@Override
	public void bind() {
		super.bind();

		this.getView().getColor().setValue("black"/*default color*/);
		this.getView().getColor().addValueChangeHandler(this);
	}

	@Override
	public void onValueChange(ValueChangeEvent<String> event) {
		if(currentBk != null) {
			String storedColor = GwtUtils.toMap(currentBk.getContent()).get("color");
			if(!getColor().equals(storedColor)) {
				loadBookmark(null);
			}
		}

		buildView();
	}
	public void setColor(String color){
		this.getView().getColor().setValue(color);
	}
	public String getColor(){
		return this.getView().getColor().getValue();
	}
	/* TO UPDATE COLOR */

	@Override
	public void onMdxFailure(MdxFailureEvent event) {
		getView().getContent().setText(event.getMessage());
	}

	@Override
	public void onMdxModelModified(MdxModelModifiedEvent event) {
		if(currentBk != null) {
			String storedMdx = GwtUtils.toMap(currentBk.getContent()).get("mdx");
			if(!mdxModelPresenter.getMdxModel().getMdxQuery().equals(storedMdx)) {
				loadBookmark(null);
			}
		}
		buildView();

		//remove loading message
		mdxModelPresenter.setMdxLoadingState(QueryLoadingState.STOPPED);
	}

	/**
	 * Build widget content based on MDX & color
	 */
	protected void buildView(){
		final IMdxModel mdxModel = mdxModelPresenter.getMdxModel();

		final StringBuilder message = new StringBuilder();
		message.append("<span style=\"color:"+getColor()+"\">");

		final IHumanReadableCellCursor cc = new CellCursor(mdxModel);
		final LayeredStringBuilder columnHeaderBuilder = new LayeredStringBuilder();
		final LayeredStringBuilder contentBuilder = new LayeredStringBuilder();
		try{
			mdxModel.forEachCellPerOrdinal(new ICellProcedure() {
				@Override
				public boolean execute(Cell cell) throws Exception {
					cc.setup(cell);

					int rowIdx = cc.getRowIndex();
					int colIdx = cc.getColumnIndex();

					if(rowIdx == 0 && colIdx == 0){
						Map<HierarchyWrapper, String[]> rows = cc.getRowHeaderNode() != null ? cc.getRowHeaderNode().buildCaptions() : new HashMap<HierarchyWrapper, String[]>();
						Map<HierarchyWrapper, String[]> cols = cc.getColumnHeaderNode() != null ? cc.getColumnHeaderNode().buildCaptions() : new HashMap<HierarchyWrapper, String[]>();
						int rowSize = rows.size();
						int colSize = cols.size();
						if(rowSize > 0){
							columnHeaderBuilder.getLayer(0).append("<th colspan=").append(rowSize).append(" rowspan=").append(colSize).append("></th>");
						}
					}

					if(rowIdx == 0 && colIdx >= 0){
						Map<HierarchyWrapper, String[]> cols = cc.getColumnHeaderNode() != null ? cc.getColumnHeaderNode().buildCaptions() : new HashMap<HierarchyWrapper, String[]>();
						int k=0;
						for(String[] cs : cols.values()){
							columnHeaderBuilder.getLayer(k).append("<th>").append(cs[cs.length-1]).append("</th>");
							k++;
						}
					}

					if(rowIdx >= 0 && !contentBuilder.hasLayer(rowIdx)){
						Map<HierarchyWrapper, String[]> rows = cc.getRowHeaderNode() != null ? cc.getRowHeaderNode().buildCaptions() : new HashMap<HierarchyWrapper, String[]>();
						for(String[] cs : rows.values()){
							contentBuilder.getLayer(rowIdx).append("<th>").append(cs[cs.length-1]).append("</th>");
						}
					}

					contentBuilder.getLayer(rowIdx).append("<td>").append(cell.getFormattedValue()).append("</td>");
					return true;
				}
			});
		}catch(Exception e){
			eventBus.fireEvent(new FailureEvent(FailureType.MAJOR, "Please contact your administrator", e));
		}
		message.append("<table>");
		for(int i=0; i<=columnHeaderBuilder.getLayerNb(); i++){
			message.append("<tr>").append(columnHeaderBuilder.getLayer(i).toString()).append("</tr>");
		}
		for(int i=0; i<=contentBuilder.getLayerNb(); i++){
			message.append("<tr>").append(contentBuilder.getLayer(i).toString()).append("</tr>");
		}
		message.append("</table>");

		message.append("</span>");

		getView().getContent().setHTML(message.toString());
	}

	@Override
	public void onCellsUpdated(MdxCellsUpdatedEvent event) {
		// TODO Auto-generated method stub

	}

	/* save parameters for bookmark, history, ...*/
	@Override
	public Map<String, String> getParameters() {
		Map<String, String> map = super.getParameters();
		map.put("color", getColor());
		return map;
	}

	@Override
	public void setParameters(Map<String, String> parameters) {
		this.setColor(parameters.get("color"));
		super.setParameters(parameters);
	}
	/* save parameters for bookmark, history, ... */

	@Override
	protected String getDefaultTitle() {
		return CustomMdxWidgetPlugin.TITLE;
	}

	@Override
	protected String getKey() {
		return CustomMdxWidgetPlugin.CUSTOM_MDX_WIDGET_PLUGIN_ID;
	}
}