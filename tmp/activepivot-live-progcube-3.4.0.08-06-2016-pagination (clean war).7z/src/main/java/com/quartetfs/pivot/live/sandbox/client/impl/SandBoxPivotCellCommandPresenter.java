/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.impl;

import java.util.Map;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.quartetfs.pivot.live.client.mdx.table.IPivotCellContextHandler;
import com.quartetfs.pivot.live.client.mdx.table.IPivotDataCell;
import com.quartetfs.pivot.live.client.mdx.table.IPivotFilterCell;
import com.quartetfs.pivot.live.client.mdx.table.IPivotHeaderCell;
import com.quartetfs.pivot.live.client.mdx.table.PivotCellContextEvent;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.IRemoteEventPipe;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.mvp.impl.AEventPresenter;
import com.quartetfs.pivot.live.core.client.widget.IContextMenuEntry;
import com.quartetfs.pivot.live.core.client.widget.impl.ContextMenuEntry;
import com.quartetfs.pivot.live.sandbox.client.message.IMessage;
import com.quartetfs.pivot.live.sandbox.client.message.impl.MessageCommand;
import com.quartetfs.pivot.live.shared.HierarchyWrapper;

/**
 * The SandBoxPivotCellCommandPresenter listens for PivotCellContextHandler events propagated
 * by the pivot table when a cell is right clicked.
 * 
 * This allows to add new entries to the contextual menu associated with custom commands.
 * 
 * @author Quartet Financial Systems
 *
 */
public class SandBoxPivotCellCommandPresenter extends AEventPresenter implements IPivotCellContextHandler {

	/**
	 * The higher level 'SandBox' menu entry
	 */
	protected final IContextMenuEntry contextMenuEntrySandBox = new ContextMenuEntry("SANDBOX_MENU", "SandBox");

	/**
	 * The Ping Command menu entry
	 */
	protected final IContextMenuEntry contextMenuEntryPing = new ContextMenuEntry("PING", "Ping");
	/**
	 * The message Command menu entry
	 */
	protected final IContextMenuEntry contextMenuEntryMessage = new ContextMenuEntry("MESSAGE", "Pivot Cell Details");

	protected final ICommandExecutorAsync commandExecutor;
	protected final IRemoteEventPipe remoteEventPipe;

	/**
	 * We rely on Gin injection for instantiating this Presenter. A PingCommandProvider as well
	 * as the DummyCommandProvider are injeted so that it is possible to instantiate the commands
	 * required for each menu entry.
	 * 
	 * @param eventBus the main event bus
	 * @param commandExecutorAsync the command executor
	 * @param remoteEventPipe the remove event type
	 */
	@Inject
	public SandBoxPivotCellCommandPresenter(	@Main IEventBus eventBus,
			ICommandExecutorAsync commandExecutorAsync,
			IRemoteEventPipe remoteEventPipe) {
		super(eventBus);
		this.commandExecutor = commandExecutorAsync;
		this.remoteEventPipe = remoteEventPipe;
	}

	/**
	 * At binding we register as handler of the PivotCellContextEvent
	 * 
	 * @see PivotCellContextEvent
	 */
	@Override
	public void bind() {
		super.bind();
		addHandlerRegistration(eventBus.addHandler(PivotCellContextEvent.TYPE, this));
	}

	/**
	 * The handler that adds the menu entry we defined above and associates them as needed
	 * with the Ping and Dummy Commands.
	 */
	@Override
	public void onPivotCellContext(final PivotCellContextEvent event) {

		//Add separator
		event.getContextMenuBuilder().addSeparator();

		// For every cases we add the highler level entry 'SandBox'
		event.getContextMenuBuilder().addEntry(contextMenuEntrySandBox, null);

		if(event.getPivotCell() != null){
			// We add the Message Command
			MessageCommand dCmd = new MessageCommand(new PivotCellMessage(event));

			// And adds its associated entry
			event.getContextMenuBuilder().addEntry(contextMenuEntryMessage, dCmd, "SANDBOX_MENU", -1);
		}
	}

	/**
	 * Compute an PivotCellContextEvent event into a human readable message
	 * 
	 * @author Quartet Financial Systems
	 */
	public class PivotCellMessage implements IMessage {

		final PivotCellContextEvent event;

		public PivotCellMessage(PivotCellContextEvent event) {
			this.event = event;
		}

		@Override
		public String computeBody() {
			StringBuilder message = new StringBuilder();

			// Handles the first case when the cell is a IPivotDataCell
			if(event.getPivotCell() instanceof IPivotDataCell) {
				// Casts and retrieves the column and row header cells
				IPivotDataCell pivotDataCell = (IPivotDataCell) event.getPivotCell();
				final IPivotHeaderCell columnHeader = pivotDataCell.getColumnHeaderCell();
				final IPivotHeaderCell rowHeader = pivotDataCell.getRowHeaderCell();

				message.append("<b>IPivotDataCell :</b><br/>");

				Map<HierarchyWrapper, String[]> filterPaths = null;

				// If the column header is non-null; we extract the filterPathes and
				// reformat them in the result string. These filter paths contain
				// the paths to the (eventually multiple (cross-join)) dimensions
				// members represented by the header
				message.append("ON COLUMNS: ");
				if(columnHeader != null) {
					filterPaths = columnHeader.extractAllFilterPathes();
					for(HierarchyWrapper hier: filterPaths.keySet()) {
						message.append(hier).append(" : [");
						for(int i = 0; i < filterPaths.get(hier).length; i ++)
							message.append((i != 0)?", ":"").append(filterPaths.get(hier)[i].toString());
						message.append("] ");
					}
				}

				// Same for the rows.
				message.append("<br/>ON ROWS: ");
				if(rowHeader != null) {
					filterPaths = rowHeader.extractAllFilterPathes();
					for(HierarchyWrapper hier: filterPaths.keySet()) {
						message.append(hier).append(" : [");
						for(int i = 0; i < filterPaths.get(hier).length; i ++)
							message.append((i != 0)?", ":"").append(filterPaths.get(hier)[i].toString());
						message.append("] ");
					}
				}
			}
			// Handles the case of a IPivotHeaderCell
			else if(event.getPivotCell() instanceof IPivotHeaderCell) {
				IPivotHeaderCell pivotFieldCell = (IPivotHeaderCell) event.getPivotCell();

				message.append("<b>IPivotHeaderCell :</b><br/>");

				// Here we have only one header the cell itself. The same way
				// we extract the paths to the dimnension members represented
				// by this header cell.
				Map<HierarchyWrapper, String[]> filterPaths = null;
				message.append("ON ").append(pivotFieldCell.getCellSetAxis().name()).append(" : ");
				if(pivotFieldCell != null) {
					filterPaths = pivotFieldCell.extractAllFilterPathes();
					for(HierarchyWrapper hier: filterPaths.keySet()) {
						message.append(hier).append(" : [");
						for(int i = 0; i < filterPaths.get(hier).length; i ++)
							message.append((i != 0)?", ":"").append(filterPaths.get(hier)[i].toString());
						message.append("] ");
					}
				}
			}else if(event.getPivotCell() instanceof IPivotFilterCell) {
				IPivotFilterCell pivotFilterCell = (IPivotFilterCell) event.getPivotCell();

				message.append("<b>IPivotFilterCell :</b><br/>");
				message.append(pivotFilterCell.getDimension()).append(" - ").append(pivotFilterCell.getCaptionValue());
			}

			return message.toString();
		}

		@Override
		public String computeHeader() {
			return "Pivot Cell Details";
		}

	}
}
