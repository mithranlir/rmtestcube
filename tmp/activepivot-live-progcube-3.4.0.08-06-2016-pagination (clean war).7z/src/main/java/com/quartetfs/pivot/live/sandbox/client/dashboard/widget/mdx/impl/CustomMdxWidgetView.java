/*
 * (C) Quartet FS 2013
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.dashboard.widget.mdx.impl;

import com.google.gwt.dom.client.Style.Overflow;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHTML;
import com.google.gwt.user.client.ui.HasValue;
import com.google.gwt.user.client.ui.RequiresResize;
import com.google.gwt.user.client.ui.SimplePanel;
import com.google.gwt.user.client.ui.TextBox;
import com.quartetfs.pivot.live.client.utils.UserInputGridView;
import com.quartetfs.pivot.live.core.client.mvp.IView;
import com.quartetfs.pivot.live.core.client.widget.IBoundContext;
import com.quartetfs.pivot.live.core.client.widget.IRequireBoundContext;

/**
 * View that contains :
 * <ul>
 * 	<li>an input to define content color</li>
 * 	<li>a content area to se some HTML</li>
 * </ul>
 * @author Quartet FS
 */
public class CustomMdxWidgetView extends SimplePanel implements
	IView,
	IRequireBoundContext,//required to get the exact size to set to our widget
	RequiresResize{//to resize ourself automatically

	/* used for sizing */
	protected IBoundContext boundContext;
	protected String defaultWidth = "200px";
	protected String defaultHeight = "200px";
	/* used for sizing */

	protected final TextBox color;
	protected final HTML content;

	public CustomMdxWidgetView() {
		//enable scrollbars
		this.getElement().getStyle().setOverflow(Overflow.AUTO);

		UserInputGridView uigv = new UserInputGridView();
		this.add(uigv);

		//add first field
		this.color = uigv.addTextBox("Color", "Pivot Table color", "", false);

		//add content
		uigv.addLabel("Table", "Table");
		this.content = new HTML();
		uigv.addRow(content);
	}

	public HasValue<String> getColor() {
		return color;
	}

	public HasHTML getContent() {
		return content;
	}

	/* resizing method */
	@Override
	public void setBoundContext(IBoundContext boundContext) {
		this.boundContext = boundContext;

		onResize();
	}

	@Override
	public IBoundContext getBoundContext() {
		return boundContext;
	}

	@Override
	public void onResize() {
		if(boundContext != null) {
			if(boundContext.isWidthConstrained())
				this.setWidth(boundContext.getContainerWidth() > 0 ? boundContext.getContainerWidth()+"px" : defaultWidth);
			else {
				this.setWidth(defaultWidth);
			}

			if(boundContext.isHeightConstrained())
				this.setHeight(boundContext.getContainerHeight() > 0 ? boundContext.getContainerHeight()+"px" : defaultHeight);
			else
				this.setHeight(defaultHeight);
		}
	}
	/* resizing method */
}