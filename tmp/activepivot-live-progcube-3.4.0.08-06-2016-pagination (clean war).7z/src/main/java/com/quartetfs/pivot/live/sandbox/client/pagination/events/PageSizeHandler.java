package com.quartetfs.pivot.live.sandbox.client.pagination.events;


import com.google.gwt.event.shared.EventHandler;

public interface PageSizeHandler extends EventHandler {
    void onPageSizeChange(PageSizeEvent event);
}
