/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.open.impl;

import com.google.gwt.user.client.Window;
import com.google.inject.Inject;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.mvp.impl.AEventPresenter;
import com.quartetfs.pivot.live.sandbox.client.open.event.IOpenWindowHandler;
import com.quartetfs.pivot.live.sandbox.client.open.event.OpenWindowEvent;

/**
 * The OpenWindow presenter listens for OpenWindowEvents on the main event bus.
 * As soon as an event is received (the OpenWindowEvent contains an url,
 * a window name and a window configuration string), It executes the window open
 * command.
 * 
 * This class aim at showing how to provide new functionality to the application
 * by relying on the main event bus.
 * 
 * @see OpenWindowEvent
 * @see OpenWindowCommand
 * 
 * @author Quartet Financial Systems
 *
 */
public class OpenWindowPresenter extends AEventPresenter implements IOpenWindowHandler {

	/**
	 * Gin Injected constructor expecting the main event bus
	 * 
	 * @param eventBus the main event bus
	 */
	@Inject
	public OpenWindowPresenter(@Main IEventBus eventBus) {
		// We pass the eventBus to the constructor of AEventPresenter
		// which abstract most of the event related functionalities
		super(eventBus);
	}

	/**
	 * The bind command in charge of registering the presenter's onOpenWindow
	 * handler for OpenWindowEvents
	 */
	@Override
	public void bind() {
		super.bind();
		// Call to EventBus.addHandler method with the type of event this presenter
		// wants to register for. From this point all OpenWindowEvents fired on the
		// main event Bus will trigger a call to the onOpenWindow handler.
		addHandlerRegistration(eventBus.addHandler(OpenWindowEvent.TYPE, this));
	}

	/**
	 * The handler in charge of calling Window.open with the provided parameters
	 * 
	 * @see Window
	 */
	@Override
	public void onOpenWindow(OpenWindowEvent event) {
		Window.open(event.getUrl(), event.getWindowName(), event.getFeatures());
	}
}
