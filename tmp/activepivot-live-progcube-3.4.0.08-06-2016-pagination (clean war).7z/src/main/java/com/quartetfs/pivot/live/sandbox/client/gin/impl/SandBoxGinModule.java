/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.gin.impl;

import com.google.gwt.inject.client.AbstractGinModule;
import com.quartetfs.pivot.live.client.desktop.IDesktopAsyncPresentersProvider;
import com.quartetfs.pivot.live.client.desktop.dashboard.template.ITemplatePluginRepository;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.IInsertionWidgetPluginRepository;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.pivot.IPivotViewPluginAddinProvider;
import com.quartetfs.pivot.live.client.mdx.IMdxModelPresenter;
import com.quartetfs.pivot.live.client.mdx.filter.IFilterPluginRepository;
import com.quartetfs.pivot.live.sandbox.client.dashboard.template.impl.MyTemplatePluginRepository;
import com.quartetfs.pivot.live.sandbox.client.dashboard.widget.impl.SandboxInsertionWidgetPluginRepository;
import com.quartetfs.pivot.live.sandbox.client.dashboard.widget.pivot.impl.MyCustomPivotViewPluginProvider;
import com.quartetfs.pivot.live.sandbox.client.filter.impl.CustomFilterPluginRepository;
import com.quartetfs.pivot.live.sandbox.client.impl.CustomMdxModelPresenter;
import com.quartetfs.pivot.live.sandbox.client.impl.SandBoxPresentersProvider;

/**
 * The SandBox Gin Module. It is a pure GIN Module, and adds
 * the necessary Gin binding used in the Sandbox Application
 * 
 * @author Quartet Financial Systems
 */
public class SandBoxGinModule extends AbstractGinModule {

	/**
	 * Gin configure method for binding configuration
	 */
	@Override
	protected void configure() {

		bind(IMdxModelPresenter.class).to(CustomMdxModelPresenter.class);

		//Configure the PresenterProvider used to inject the MainApplication presenters
		bind(IDesktopAsyncPresentersProvider.class).to(SandBoxPresentersProvider.class);

		//rebind the filter plugin repository with the custom one with in the sandbox
		bind(IFilterPluginRepository.class).to(CustomFilterPluginRepository.class);

		//rebind the template plugin repository with the custom one defined in the sandbox
		bind(ITemplatePluginRepository.class).to(MyTemplatePluginRepository.class);

		//rebind the addins provider with the custom one defined in this sandbox
		bind(IPivotViewPluginAddinProvider.class).to(MyCustomPivotViewPluginProvider.class);

		//rebind the widget plugin repository with the custom one defined in the sandbox
		bind(IInsertionWidgetPluginRepository.class).to(SandboxInsertionWidgetPluginRepository.class);
	}

}