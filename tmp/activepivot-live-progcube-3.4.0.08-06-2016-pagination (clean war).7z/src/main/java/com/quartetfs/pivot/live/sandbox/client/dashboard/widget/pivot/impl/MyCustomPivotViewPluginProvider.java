package com.quartetfs.pivot.live.sandbox.client.dashboard.widget.pivot.impl;

import com.google.inject.Inject;
import com.quartetfs.pivot.live.client.desktop.dashboard.mdx.impl.StorableMdxWidgetSelectorPresenter;
import com.quartetfs.pivot.live.client.desktop.dashboard.widget.pivot.impl.PivotViewPluginAddinProvider;
import com.quartetfs.pivot.live.client.realtime.IRealtimeConstants;
import com.quartetfs.pivot.live.client.realtime.IRealtimeResources;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.settting.ISettingProvider;
import com.quartetfs.pivot.live.core.client.widget.addin.IAddinPresenter;
import com.quartetfs.pivot.live.core.client.widget.addin.IAddinView;
import com.quartetfs.pivot.live.sandbox.client.impl.CustomMdxModelPresenter;
import com.quartetfs.pivot.live.sandbox.client.pagination.PageSizeSelectorPresenter;
import com.quartetfs.pivot.live.sandbox.client.pagination.PagingAddinPresenter;

import java.util.ArrayList;
import java.util.List;

public class MyCustomPivotViewPluginProvider extends PivotViewPluginAddinProvider {

	@Inject
	public MyCustomPivotViewPluginProvider(@Main IEventBus eventBus,
			ICommandExecutorAsync cmdExecutor,
			ISettingProvider settingProvider,
			IRealtimeResources realtimeResources,
			IRealtimeConstants realtimeConstants) {
		super(eventBus, cmdExecutor, settingProvider, realtimeResources, realtimeConstants);
	}

	@Override
	public List<IAddinPresenter<? extends IAddinView>> createAddins(StorableMdxWidgetSelectorPresenter presenter) {
		final List<IAddinPresenter<? extends IAddinView>> addins = new ArrayList<>();
		final IEventBus eventBus = presenter.getMdxModelPresenter().getEventBus();
		addins.add(new PageSizeSelectorPresenter(eventBus));
		addins.add(new PagingAddinPresenter(eventBus));
		addins.addAll(super.createAddins(presenter));// add existing addins defined in the core product
		return addins;
	};

}
