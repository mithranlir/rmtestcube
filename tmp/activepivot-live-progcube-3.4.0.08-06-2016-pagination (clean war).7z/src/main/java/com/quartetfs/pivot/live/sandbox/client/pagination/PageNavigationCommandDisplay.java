package com.quartetfs.pivot.live.sandbox.client.pagination;

import com.google.gwt.dom.client.Style;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.HasClickHandlers;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.ui.*;
import com.quartetfs.pivot.live.core.client.utils.impl.MultipleHandlerRegistration;
import com.quartetfs.pivot.live.core.client.widget.impl.LivePushButton;
import com.quartetfs.pivot.live.sandbox.client.pagination.images.PagingResources;

public class PageNavigationCommandDisplay extends HorizontalPanel implements IPagingAddinView, HasClickHandlers {

    protected LivePushButton startButton = createLivePushButton();
    protected LivePushButton previousButton = createLivePushButton();
    protected LivePushButton nextButton = createLivePushButton();
    protected LivePushButton endButton = createLivePushButton();
    protected HTML textBox = createTextBox();
    protected int maxHeight = -1;

    private HTML createTextBox() {
        return new HTML() {
            public void onBrowserEvent(Event event) {
                int type = DOM.eventGetType(event);
                if(type == 4 && event.getButton() == 1) {
                    event.stopPropagation();
                }

                super.onBrowserEvent(event);
            }
        };
    }

    private LivePushButton createLivePushButton() {
        return new LivePushButton() {
            @Override
            public void onBrowserEvent(Event event) {
                //We stop the propagation of the event because we don't want this click to do something else than the action of the button
                int type = DOM.eventGetType(event);
                if (type == Event.ONMOUSEDOWN) {
                    if (event.getButton() == Event.BUTTON_LEFT) {
                        event.stopPropagation();
                    }
                }
                super.onBrowserEvent(event);

            }
        };
    }

    public PageNavigationCommandDisplay() {
        startButton = createLivePushButton();
        previousButton = createLivePushButton();
        nextButton = createLivePushButton();
        endButton = createLivePushButton();
    }

    public void setVisibleOnButtons(boolean visible) {
        startButton.setVisible(visible);
        previousButton.setVisible(visible);
        nextButton.setVisible(visible);
        endButton.setVisible(visible);
    }

    private void configureButton(LivePushButton button, ImageResource imageResource) {
        button.getUpFace().setImage(new Image(imageResource));
        button.setHTML(AbstractImagePrototype.create(imageResource).getHTML());
        button.setHeight(imageResource.getHeight()+"px");
        button.getElement().getStyle().setPadding(2, Style.Unit.PX);
        configureBorderOnButton();
        this.add(button);
    }

    private void configureBorderOnButton() {
        //button.getElement().getStyle().setBorderWidth(1, Style.Unit.PX);
        //button.getElement().getStyle().setBorderColor("#FFF");
        //button.getElement().getStyle().setBorderStyle(Style.BorderStyle.SOLID);
    }

    @Override
    public void update() {
        this.clear();
        configureButton(startButton, PagingResources.INSTANCE.doubleArrowLeftW());
        configureButton(previousButton, PagingResources.INSTANCE.arrowLeftW());
        configureButton(nextButton, PagingResources.INSTANCE.arrowRightW());
        configureButton(endButton, PagingResources.INSTANCE.doubleArrowRightW());

        textBox.setWidth("55px");
        textBox.getElement().getStyle().setFontWeight(Style.FontWeight.BOLD);
        textBox.getElement().getStyle().setFontSize(0.8D, Style.Unit.EM);
        this.add(textBox);

        textBox.setHTML("");
        hideButtonsAndTextbox();

        this.setSpacing(5);
    }

    public void hideButtonsAndTextbox() {
        setVisibleOnButtons(false);
        textBox.setVisible(false);
    }

    public void showButtonsAndTextbox() {
        if(!textBox.isVisible()) {
            setVisibleOnButtons(true);
            textBox.setVisible(true);
        }
    }

    @Override
    public void setMaxHeight(int maxHeight) {
        this.maxHeight = maxHeight;
    }

    @Override
    public HasClickHandlers getActionTrigger() {
        return this;
    }

    @Override
    public HandlerRegistration addClickHandler(ClickHandler handler) {
        return new MultipleHandlerRegistration(
                new HandlerRegistration[]{
                        this.startButton.addClickHandler(handler),
                        this.previousButton.addClickHandler(handler),
                        this.nextButton.addClickHandler(handler),
                        this.endButton.addClickHandler(handler)
                }
        );
    }

    public LivePushButton getStartButton() {
        return startButton;
    }

    public LivePushButton getPreviousButton() {
        return previousButton;
    }

    public LivePushButton getNextButton() {
        return nextButton;
    }

    public LivePushButton getEndButton() {
        return endButton;
    }

    @Override
    public HTML getTextBox() {
        return textBox;
    }

}
