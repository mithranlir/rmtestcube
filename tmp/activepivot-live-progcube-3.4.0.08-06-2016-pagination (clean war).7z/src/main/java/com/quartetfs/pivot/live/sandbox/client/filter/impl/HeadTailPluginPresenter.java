package com.quartetfs.pivot.live.sandbox.client.filter.impl;

import com.google.gwt.user.client.ui.IsWidget;
import com.quartetfs.biz.pivot.cube.dimension.IDimension.DimensionType;
import com.quartetfs.pivot.live.client.mdx.filter.IFilterPluginRepository;
import com.quartetfs.pivot.live.client.mdx.filter.impl.FilterPluginRepository;
import com.quartetfs.pivot.live.client.model.IEditMdxPluginProvider;
import com.quartetfs.pivot.live.client.model.IFilterEditMdxPlugin;
import com.quartetfs.pivot.live.client.model.impl.FilterMdxExpressionContext;
import com.quartetfs.pivot.live.client.utils.ListBoxGenerator;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.mvp.impl.AEventViewPresenter;
import com.quartetfs.pivot.live.core.shared.util.GenericCommand;
import com.quartetfs.pivot.live.sandbox.client.filter.IHeadTailPluginView;
import com.quartetfs.pivot.live.shared.HierarchyWrapper;
import com.quartetfs.pivot.live.shared.model.IMdxExpression;
import com.quartetfs.pivot.live.shared.model.IMdxFunction;
import com.quartetfs.pivot.live.shared.model.IMdxMemberExpression;
import com.quartetfs.pivot.live.shared.model.definition.impl.FunctionDefinition;
import com.quartetfs.pivot.live.shared.model.executor.impl.ExecutorUtils;
import com.quartetfs.pivot.live.shared.model.executor.impl.MdxReaderExecutor.SECTION;
import com.quartetfs.pivot.live.shared.model.impl.MdxFunction;
import com.quartetfs.pivot.live.shared.model.impl.MdxLevelExpression;
import com.quartetfs.pivot.live.shared.model.impl.MdxMemberExpression;
import com.quartetfs.pivot.live.shared.model.visitor.IMdxVisitorContext;
import com.quartetfs.pivot.live.shared.model.visitor.accumulator.impl.StaticMembersAccumlator;
import com.quartetfs.pivot.live.shared.model.visitor.retriever.impl.FunctionRetriever;
import com.quartetfs.pivot.live.shared.olap.impl.Dimension;
import com.quartetfs.pivot.live.shared.olap.impl.Level;

import java.util.Collection;
import java.util.List;

/**
 * This presenter contains all the logic behind mdx handling and presenter-view binding. It offers a way to generate mdx filter such as
 * <p>
 * Tail(NonEmpty([Underlyings].[Products].[ProductType].Members,[Measures].[contributors.COUNT])).
 * </p>
 * User is invited for practice to propose an addition parameter (via the UI) to set a second argument to Tail and Head function (see mdx function reference link below)
 * with a text box. Both {@link HeadTailPluginPresenter#fill(FilterMdxExpressionContext, IMdxExpression)} and {@link HeadTailPluginPresenter#apply(FilterMdxExpressionContext, GenericCommand)}
 * methods need to be updated in this case. The mdx generated requests would look like
 * <p>
 * Tail(NonEmpty([Underlyings].[Products].[ProductType].Members,[Measures].[contributors.COUNT]), 5)
 * </p>
 * It would return the 5 last non-empty members when evaluated against the measure contributors.COUNT. Note if there is no second argument, the default value is 1.
 * 
 * @see <a href="http://technet.microsoft.com/en-us/library/ms145988.aspx">Mdx NonEmpty function reference</a>
 * @see <a href="http://technet.microsoft.com/en-us/library/ms144859.aspx">Mdx Head function reference</a>
 * @see <a href="http://technet.microsoft.com/en-us/library/ms146056.aspx">Mdx Tail function reference</a>
 * @author Quartet FS
 */
public class HeadTailPluginPresenter extends AEventViewPresenter<IHeadTailPluginView> implements IFilterEditMdxPlugin, IEditMdxPluginProvider<FilterMdxExpressionContext, IFilterEditMdxPlugin>{

	/**
	 * Attributes to store informations about the entity we are working with
	 */
	protected String dimension;
	protected String hierarchy;
	protected String level;

	protected String title;
	protected int group;

	/**
	 * Object that give us all available measures in the cube in addition to the calculated formulas
	 */
	protected final ListBoxGenerator listBoxGenerator;

	/**
	 * THis constructor is the one use in the {@link FilterPluginRepository} or the class that will extend it
	 */
	public HeadTailPluginPresenter(IEventBus eventBus, ListBoxGenerator listBoxGenerator, String title, int group){
		this(eventBus, listBoxGenerator, title, group, new HeadTailPluginView());
	}

	/**
	 * This constructor is not meant to be used directly in the project, it's here to simplify unit testing procedure
	 * It's convenient to test the presenter, especially the {@link HeadTailPluginPresenter#fill(FilterMdxExpressionContext, IMdxExpression)} and
	 * {@link HeadTailPluginPresenter#apply(FilterMdxExpressionContext, GenericCommand)} methods which could be tricky
	 */
	public HeadTailPluginPresenter(IEventBus eventBus, ListBoxGenerator listBoxGenerator, String title, int group, IHeadTailPluginView view) {
		super(eventBus);

		this.listBoxGenerator = listBoxGenerator;
		this.title = title;
		this.group = group;

		if(view != null){
			setView(view);
		}

		//build the view
		getView().buildContent();
	}

	/**
	 * Fill current plugin view with the expression to edit. There is a lot of mdx handling this is why
	 * one has to pay attention to what this method does for a right behavior
	 * @param mdxExpressionContext the mdx plugin context
	 * @param expressionToEdit the expression to edit that will be parsed
	 * @return true if plugin matches the expression so that the UI will give focus on it
	 */
	@Override
	public boolean fill(FilterMdxExpressionContext mdxExpressionContext, IMdxExpression expressionToEdit) {
		//fill measures
		listBoxGenerator.setMeasures(getView().getMeasuresListBox(), mdxExpressionContext.getMdxSelect());

		dimension = mdxExpressionContext.getDimension().getName();
		hierarchy = mdxExpressionContext.getHierarchy().getName();
		level = mdxExpressionContext.getLevel().getName();
		IMdxVisitorContext mdxVisitorContext = mdxExpressionContext.getMdxVisitorContext();

		//look for a tail mdx function or head mdx function
		IMdxFunction headOrTailFunc = expressionToEdit.accept(new FunctionRetriever(mdxVisitorContext, FunctionDefinition.TAIL.getName(), FunctionDefinition.HEAD.getName()));
		if(headOrTailFunc != null){
			List<IMdxExpression> args = headOrTailFunc.getArguments();
			//always check arguments size and nullity
			if(args != null && args.size() > 0){
				IMdxExpression nonEmptyExpression = args.get(0);
				//loof for a NonEmpty mdx function
				IMdxFunction nonEmptyFunc = nonEmptyExpression.accept(new FunctionRetriever(mdxVisitorContext, FunctionDefinition.NONEMPTY.getName()));
				//always check arguments size and nullity
				if(nonEmptyFunc != null && nonEmptyFunc.getArguments() != null && nonEmptyFunc.getArguments().size() == 2){
					IMdxExpression membersExpression = nonEmptyFunc.getArguments().get(0);
					IMdxExpression measuresExpression = nonEmptyFunc.getArguments().get(1);

					/**
					 * retrieve hierarchy and dimension (through a {@link HierarchyWrapper})
					 */
					HierarchyWrapper hierarchyWrapper = ExecutorUtils.getSingleHierarchy(mdxVisitorContext, membersExpression);
					//check dimension and hierarchy equality
					if(hierarchyWrapper != null && hierarchyWrapper.getDimension().equals(dimension) && hierarchyWrapper.getHierarchy().equals(hierarchy)){
						//retrieve the level
						Level levelFound = ExecutorUtils.getLevel(mdxExpressionContext.getCube(), dimension, hierarchy, membersExpression, mdxVisitorContext);
						//check level
						if(levelFound != null && levelFound.getName().equals(level)){
							//everything is ok, inspect measuresExpression now
							Collection<IMdxMemberExpression> m = measuresExpression.accept(new StaticMembersAccumlator(mdxVisitorContext));
							if(m!= null && m.size() > 0){
								IMdxMemberExpression measure = m.iterator().next();
								if(Dimension.MEASURES.equals(measure.getDimension())){
									doFill(headOrTailFunc.getName(), measure.getLast().getValue());
									return true;
								}
							}
						}
					}
				}
			}
		}
		return false;
	}

	/**
	 * Fill the UI (the view). It is a been extracted from the {@link HeadTailPluginPresenter#fill(FilterMdxExpressionContext, IMdxExpression)}
	 * to clarify the code
	 */
	protected void doFill(String functionDefinitionName, String measure){
		getView().updateContent(functionDefinitionName);
		getView().getMeasuresListBox().setValue(measure);
	}

	/**
	 * Generate a IMdxExpression which shape is
	 * Tail(NonEmpty([Underlyings].[Products].[ProductType].Members,[Measures].[contributors.COUNT]))
	 * This will create a editable filter in {@link SECTION#FILTERS} wizard section
	 */
	@Override
	public void apply(FilterMdxExpressionContext mdxExpressionContext, GenericCommand<IMdxExpression> command) {
		IMdxExpression filteredSet = new MdxFunction(FunctionDefinition.MEMBERS, new MdxLevelExpression(this.dimension, this.hierarchy, this.level));

		//set the FunctionDefinition to use by retrieving user input parameter
		FunctionDefinition funcDef =  getView().getCheckedRadioButtonValue().equals("Head") ? FunctionDefinition.HEAD : FunctionDefinition.TAIL;

		// execute the command with the expression we need to create. We don't care what the command will actually do, we just need to build the query and pass it
		command.execute(new MdxFunction(funcDef,
				new MdxFunction(FunctionDefinition.NONEMPTY,
						filteredSet,
						MdxMemberExpression.createMeasure(getView().getMeasuresListBox().getValue())//the measure is retrieved from the list box
						)));
	}

	/**
	 * One can set a condition whether or not the current plugin can be used to edit the current mdxExpression.
	 * For instance, for date plugin, the requirement will be to work with a dimension which {@link DimensionType} would
	 * be equal to {@link DimensionType#TIME}. However, with most of plugins, it's simply return true
	 */
	@Override
	public boolean accept(FilterMdxExpressionContext mdxPluginContext, IMdxExpression mdxExpression) {
		return true;
	}


	@Override
	public IFilterEditMdxPlugin create() {
		return this;
	}

	/**
	 * The plugin title, what will be display in the listbox listing all available plugins
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * @return the plugin view
	 */
	@Override
	public IsWidget getWidget() {
		return getView();
	}

	@Override
	public String getCategory() {
		return IFilterPluginRepository.VALUE_CATEGORY;
	}

	/**
	 * Define the group in which this plugin belongs. Plugins are gathered together in the list box according to
	 * their group, a dashed-line separates groups between them
	 *  ________________________
	 * | Plugin title 1 group 1 |
	 * | Plugin title 2 group 1 |
	 * | ---------------------- |
	 * | Plugin title 1 group 2 |
	 * | Plugin title 2 group 2 |
	 * | Plugin title 3 group 3 |
	 * |________________________|
	 */
	@Override
	public Integer getGroup() {
		return group;
	}

}
