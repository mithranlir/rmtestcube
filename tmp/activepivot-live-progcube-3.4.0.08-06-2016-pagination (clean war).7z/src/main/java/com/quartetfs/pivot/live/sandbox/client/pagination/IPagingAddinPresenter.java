package com.quartetfs.pivot.live.sandbox.client.pagination;

import com.quartetfs.pivot.live.core.client.widget.addin.IAddinPresenter;

public interface IPagingAddinPresenter extends IAddinPresenter<IPagingAddinView> {
}
