package com.quartetfs.pivot.live.sandbox.client.pagination;

import com.google.gwt.user.client.Command;
import com.google.inject.Inject;
import com.quartetfs.pivot.live.core.client.cmd.ICommandExecutorAsync;
import com.quartetfs.pivot.live.core.client.event.FailureType;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.event.Main;
import com.quartetfs.pivot.live.core.client.impl.DefaultAsyncCallback;
import com.quartetfs.pivot.live.sandbox.client.pagination.events.ResultSizeReceivedEvent;
import com.quartetfs.pivot.live.sandbox.shared.paging.impl.PagingAction;
import com.quartetfs.pivot.live.sandbox.shared.paging.impl.PagingResult;

public class ResultSizeCommand implements Command {

	protected final IEventBus eventBus;
	protected final ICommandExecutorAsync commandExecutor;

	@Inject
	public ResultSizeCommand(@Main IEventBus eventBus,
							 ICommandExecutorAsync commandExecutorAsync) {
		this.eventBus = eventBus;
		this.commandExecutor = commandExecutorAsync;
	}

	@Override
	public void execute() {
		commandExecutor.execute(
				new PagingAction(),
				new DefaultAsyncCallback<PagingResult> (eventBus, "Paging Failed", FailureType.MAJOR) {
			@Override
			public void onFailure(Throwable reason) {
				super.onFailure(reason);
				// Nothing to do
			}
			@Override
			public void onSuccess(PagingResult result) {
				System.out.println("onSuccess " + result.getResultSize());
				System.out.println("fireEvent ResultSizeReceivedEvent");
				eventBus.fireEvent(new ResultSizeReceivedEvent(result.getResultSize()));
			}
		});
	}

}
