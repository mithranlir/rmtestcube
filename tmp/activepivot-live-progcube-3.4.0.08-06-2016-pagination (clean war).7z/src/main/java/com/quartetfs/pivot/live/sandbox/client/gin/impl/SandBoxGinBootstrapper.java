/*
 * (C) Quartet FS 2012
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.quartetfs.pivot.live.sandbox.client.gin.impl;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.Window.ClosingHandler;
import com.quartetfs.pivot.live.client.desktop.IDashboardMenuBar;
import com.quartetfs.pivot.live.client.desktop.MainMenuLayoutEvent;
import com.quartetfs.pivot.live.client.desktop.gin.impl.DesktopGinBootstrapper;
import com.quartetfs.pivot.live.core.client.event.IEventBus;
import com.quartetfs.pivot.live.core.client.widget.impl.PopupServices;
import com.quartetfs.pivot.live.core.shared.util.GenericCommand;
import com.quartetfs.pivot.live.sandbox.client.config.impl.ConfigCommand;
import com.quartetfs.pivot.live.sandbox.client.gin.ISandBoxGinjector;
import com.quartetfs.pivot.live.sandbox.client.open.impl.OpenWindowCommand;
import com.quartetfs.pivot.live.sandbox.client.openhtmlpanel.OpenApPageInPanelCommand;
import com.quartetfs.pivot.live.sandbox.shared.config.impl.ConfigResultHolder;

/**
 * The SandBox Bootstrapper based on the SandBox Ginjector
 * 
 * @author Quartet Financial Systems
 * 
 */
public class SandBoxGinBootstrapper extends DesktopGinBootstrapper<ISandBoxGinjector> {

	/**
	 * Sets the Ginjector to rely on for this boostrapper
	 */
	public SandBoxGinBootstrapper() {
		super((ISandBoxGinjector) GWT.create(ISandBoxGinjector.class), "ActivePivot Live is loading ...");
	}

	/**
	 * Called after the application is loaded. We use it here to add a addins to panels. The addin executes
	 * 
	 * @see OpenWindowCommand
	 */
	@Override
	protected void afterApplicationLoaded() {
		super.afterApplicationLoaded();

		final IEventBus eventBus = prerequisites.getMainEventBus();

		// The command we rely on is the OpenWindowCommand which opens a new window pointing
		// on the Quartet FS website (Popup must be allowed)
		eventBus.fireEvent(MainMenuLayoutEvent.trigger(new GenericCommand<IDashboardMenuBar>() {
			@Override
			public void execute(IDashboardMenuBar menuBar) {
				menuBar.getUserMenuBar().getMenu(IDashboardMenuBar.USER_MENU).createItem(injector.constants().infoTitle(), new OpenWindowCommand(injector.constants().quartetFSURL(), "_info", eventBus));
			}
		}));

        // COMMENT -> sandbox title is located at the top right of the screen...

		// Adding a custom command (button with an action) in the application menu bar, next to the existing ones (Bookmark, Wizard...)
		eventBus.fireEvent(MainMenuLayoutEvent.trigger(new GenericCommand<IDashboardMenuBar>() {
			@Override
			public void execute(IDashboardMenuBar menuBar) {
				menuBar.getApplicationMenuBar().createItem(injector.constants().sandBoxInfoTitle(),
						new Command() {
							@Override
							public void execute() {
								PopupServices.create().setTitle(injector.constants().sandBoxInfoTitle()).setContent(injector.constants().sandBoxInfo()).isClosable().isModal().isAutoHide().center();
							}
						}
				);
			}
		}));


		final ConfigResultHolder configResultHolder = new ConfigResultHolder();

		final OpenApPageInPanelCommand command = new OpenApPageInPanelCommand(eventBus, configResultHolder, injector.getSessionDynamicProvider());

		// Adding a custom command (button with an action) in the application menu bar, next to the existing ones (Bookmark, Wizard...)
		eventBus.fireEvent(MainMenuLayoutEvent.trigger(new GenericCommand<IDashboardMenuBar>() {
			@Override
			public void execute(IDashboardMenuBar menuBar) {
				menuBar.getApplicationMenuBar().createItem("Cube Reload", command);
			}
		}));

		final ConfigCommand configCommand = new ConfigCommand(eventBus, injector.getCommandExecutorAsync(), configResultHolder);
		configCommand.execute();

		HandlerRegistration registration = Window.addWindowClosingHandler(new ClosingHandler() {
			@Override
			public void onWindowClosing(Window.ClosingEvent closingEvent) {
				if(command.getPopup()!=null) {
					command.getPopup().hide();
				}
			}
		});
	}

}
