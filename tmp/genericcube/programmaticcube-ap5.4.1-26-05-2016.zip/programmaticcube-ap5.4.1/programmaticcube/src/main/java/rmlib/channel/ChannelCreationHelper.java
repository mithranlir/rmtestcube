package rmlib.channel;

import com.qfs.msg.IColumnCalculator;
import com.qfs.msg.IMessageChannel;
import com.qfs.source.IStoreChannelFactory;
import com.qfs.source.ITuplePublisher;
import com.qfs.source.impl.AutoCommitTuplePublisher;
import com.qfs.source.impl.POJOMessageChannelFactory;
import com.qfs.source.impl.TuplePublisher;
import com.qfs.store.IDatastoreSchemaMetadata;
import com.qfs.store.IStoreFormat;
import com.qfs.store.IStoreMetadata;
import com.qfs.store.impl.Datastore;
import com.qfs.store.impl.StoreUtils;
import com.qfs.store.record.IByteRecordFormat;
import com.qfs.store.record.IRecordFormat;

import java.util.List;
import java.util.Map;

public class ChannelCreationHelper {

    public static IMessageChannel<String, Object> createAndConfigurePOJOChannel(
            POJOMessageChannelFactory factory,
            Datastore datastore,
            String topicName,
            String storeName,
            boolean autoCommit,
            List<IColumnCalculator<Object>> calculatedColumns) {

        configurePOJOMessageChannelFactory(
                datastore.getSchemaMetadata(), factory, topicName, storeName, calculatedColumns);

        return createChannel(
                factory, datastore, topicName, storeName, autoCommit);
    }

    public static IMessageChannel<String, Object> createChannel(
            IStoreChannelFactory<String, Object, Object> factory,
            Datastore datastore,
            String topicName,
            String storeName,
            boolean autoCommit) {

        if(autoCommit) {
            final ITuplePublisher<String> publisher =
                    new AutoCommitTuplePublisher<>(new TuplePublisher<String>(datastore, storeName));
            return factory.createChannel(topicName, storeName, publisher);
        }
        else {
            return factory.createChannel(topicName, storeName);
        }
    }

    public static POJOMessageChannelFactory configurePOJOMessageChannelFactory(
            IDatastoreSchemaMetadata datastoreSchemaMetadata,
            POJOMessageChannelFactory factory,
            String topicName,
            String storeName,
            List<IColumnCalculator<Object>> calculatedColumns) {

        final IStoreMetadata storeMetadata = datastoreSchemaMetadata.getStoreMetadata(storeName);
        final IByteRecordFormat recordFormat = storeMetadata.getStoreFormat().getRecordFormat();

        factory.setSourceColumn(
                topicName,
                storeName,
                StoreUtils.getFieldNamesAndIndexes(recordFormat));

        if(calculatedColumns!=null && !calculatedColumns.isEmpty()) {
            factory.setCalculatedColumns(topicName, storeName, calculatedColumns);
        }

        return factory;
    }
}
