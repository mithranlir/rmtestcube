package rmlib.cubebuilder.subbuilder;

public interface ComponentBuilder<T> {
    T build();
}
