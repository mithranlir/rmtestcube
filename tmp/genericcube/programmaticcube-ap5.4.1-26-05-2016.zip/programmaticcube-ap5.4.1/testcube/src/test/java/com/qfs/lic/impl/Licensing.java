//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.qfs.lic.impl;

import com.qfs.activation.impl.LicenseException;
import com.qfs.activation.impl.LicenseManager;
import com.qfs.activation.impl.Platform;
import com.qfs.lic.impl.QuartetFSLicense;
import com.qfs.logging.MessagesDatastore;
import com.qfs.platform.IPlatform;
import com.qfs.platform.share.VirtualPlatform;
import com.quartetfs.biz.pivot.impl.Util;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class Licensing {
    public static final String DEV_ENV = "DEV";
    static final Logger logger = MessagesDatastore.getLogger(Licensing.class);
    private static final String newLine = System.getProperty("line.separator");
    static final AtomicBoolean infoLogged = new AtomicBoolean(false);
    private static volatile Licensing.LicenseContext licenseContext;
    private static volatile byte[] binaryLicense;
    private static volatile QuartetFSLicense license;

    public Licensing() {
    }

    public static void logLicenseInfoOnce() {
        logger.log(Level.INFO, "COUCOU");
        if(infoLogged.compareAndSet(false, true)) {
            logger.log(Level.INFO, getLicenseContext().toString() + "\n" + getLicense().toString());
        }

    }

    public static boolean checkLicence() {
        logLicenseInfoOnce();
        boolean isValid = getLicenseContext().verifyLicense(getLicense());
        logger.log(Level.INFO, "License status: " + (isValid?"Valid":"Invalid"));
        logger.log(Level.INFO, "License: " + getLicense().getLicenseStatus());
        return isValid;
    }

    private static final Licensing.LicenseContext getLicenseContext() {
        if(licenseContext == null) {
            Class var0 = Licensing.LicenseContext.class;
            synchronized(Licensing.LicenseContext.class) {
                if(licenseContext == null) {
                    licenseContext = new Licensing.LicenseContext();
                }
            }
        }

        return licenseContext;
    }


    public static QuartetFSLicense createFakeQuartetFSLicense() {
        final Properties properties = new Properties();

        final Long startDate = (new Date()).getTime() - (24 * 60 * 60 * 1000); // now - 1d;
        properties.put("sDate", startDate.toString());

        final Long endDate = (new Date()).getTime() + (365 * 24 * 60 * 60 * 1000); // now + 1 year;
        properties.put("eDate", endDate.toString());

        String host = "";
        try {
            host = Platform.getLocalHostName();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        properties.put("host", host);

        final int maxNbOfCPU = Util.retrieveNumberOfAllowedCores();
        properties.put("maxNbOfCPU", maxNbOfCPU + "");

        properties.put("live", "YES");

        properties.put("sentinel", "YES");

        properties.put("rs", "YES");

        final QuartetFSLicense license = new QuartetFSLicense(properties);

        license.status = "License loaded and tested successfully.";

        return license;
    }



    public static final QuartetFSLicense getLicense()
    {
        if (license == null) {
            synchronized (QuartetFSLicense.class)
            {
                if (license == null)
                {
                    logger.log(Level.INFO, "Quartet FS ActivePivot Licensing Agent.");
                    license = createFakeQuartetFSLicense();
                }
            }
        }
        return license;
    }

    public static final byte[] getBinaryLicense()
    {
        return null;
    }

    public static final void reset() {
        if(license != null) {
            Class var0 = QuartetFSLicense.class;
            synchronized(QuartetFSLicense.class) {
                if(license != null) {
                    logger.log(Level.INFO, "Resetting Quartet FS Licensing Agent.");
                    license = null;
                    binaryLicense = null;
                }
            }
        }

    }

    private static final class LicenseContext {
        final long currentTime;
        final int cpuCount;

        private LicenseContext() {
            this.currentTime = System.currentTimeMillis();
            IPlatform platform = IPlatform.CURRENT_PLATFORM;
            if(platform instanceof VirtualPlatform) {
                this.cpuCount = ((VirtualPlatform)platform).getUnderlying().getProcessorCount();
            } else {
                this.cpuCount = platform.getProcessorCount();
            }

        }

        private boolean verifyLicense(QuartetFSLicense license) {
            if(this.currentTime <= license.getEndDate() && this.currentTime >= license.getStartDate()) {
                boolean restrictionFound1 = false;
                String status;
                if(!"-".equals(license.getMac())) {
                    restrictionFound1 = true;

                    try {
                        status = Platform.getLocalHostMacAddress();
                    } catch (IOException var7) {
                        Licensing.getLicense().status = "Unable to obtain MAC Address because of IOException.";
                        Licensing.logger.log(Level.SEVERE, Licensing.getLicense().getLicenseStatus(), var7);
                        return false;
                    }

                    if(status == null || status.isEmpty()) {
                        Licensing.getLicense().status = "Unable to obtain MAC Address (empty MAC Address).";
                        Licensing.logger.log(Level.SEVERE, Licensing.getLicense().getLicenseStatus());
                        return false;
                    }

                    if(!Platform.equals(status, license.getMac())) {
                        Licensing.logger.log(Level.SEVERE, "EXC_MAC_LICENSE", new Object[]{status, license.getMac()});
                        Licensing.getLicense().status = "Your license is bound to another machine (your MAC Address: " + status + ", license MAC Address: " + license.getMac() + ").";
                        return false;
                    }
                }

                if(!"-".equals(license.getIp())) {
                    restrictionFound1 = true;

                    try {
                        status = Platform.getLocalHostAddress();
                    } catch (UnknownHostException var6) {
                        Licensing.logger.log(Level.SEVERE, "EXC_UNKNOWN_IP", var6);
                        Licensing.getLicense().status = "EXC_UNKNOWN_IP";
                        return false;
                    }

                    if(!status.equals(license.getIp())) {
                        Licensing.logger.log(Level.SEVERE, "EXC_IP_LICENSE");
                        Licensing.getLicense().status = "Your license is bound to another machine (your IP Address: " + status + ", license IP Address: " + license.getIp() + ").";
                        return false;
                    }
                }

                if(!"-".equals(license.getHostname())) {
                    restrictionFound1 = true;

                    try {
                        status = Platform.getLocalHostName();
                    } catch (UnknownHostException var5) {
                        Licensing.logger.log(Level.SEVERE, "EXC_UNKNOWN_HOST", var5);
                        Licensing.getLicense().status = "EXC_UNKNOWN_HOST";
                        return false;
                    }

                    if(!status.equalsIgnoreCase(license.getHostname())) {
                        Licensing.logger.log(Level.SEVERE, "EXC_HOST_LICENSE", new Object[]{status, license.getHostname()});
                        Licensing.getLicense().status = "Your license is bound to another machine (your hostname: " + status + ", license hostname: " + license.getHostname() + ").";
                        return false;
                    }
                }

                if(!restrictionFound1) {
                    Licensing.logger.log(Level.SEVERE, "EXC_UNRESTRICTED_LICENSE");
                    status = "The license is not valid due to violated restrictions." + Licensing.newLine;
                    status = status + "Please contact the QuartetFS support team.";
                    Licensing.getLicense().status = status;
                    return false;
                } else if(this.cpuCount > license.getCpuCount()) {
                    Licensing.logger.log(Level.SEVERE, "EXC_CORE_EXCEEDED_LICENSE", new Object[]{Integer.valueOf(license.getCpuCount()), Integer.valueOf(this.cpuCount)});
                    status = "The number fo cores allowed by the license is not enough to operate on this server." + Licensing.newLine;
                    status = status + "Cores allowed by the license: " + license.getCpuCount() + Licensing.newLine;
                    status = status + "Cores in the server: " + this.cpuCount + Licensing.newLine;
                    status = status + "Please contact the QuartetFS support team.";
                    Licensing.getLicense().status = status;
                    return false;
                } else {
                    Licensing.getLicense().status = "License loaded and tested successfully.";
                    return true;
                }
            } else {
                Licensing.logger.log(Level.SEVERE, "EXC_EXPIRED_LICENSE");
                String restrictionFound = "Your license has expired: system date (" + new Date(this.currentTime) + ") is not between start date (" + new Date(license.getStartDate()) + ") and end date (" + new Date(license.getEndDate()) + ")." + Licensing.newLine;
                restrictionFound = restrictionFound + "Please contact Quartet FS.";
                Licensing.getLicense().status = restrictionFound;
                return false;
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("\n*************** Platform Information *****************");
            sb.append("\nSystem Time: ");
            sb.append(new Date(this.currentTime));
            sb.append("\nNumber of Processors: ");
            sb.append(this.cpuCount);

            String mac;
            try {
                mac = Platform.getLocalHostMacAddress();
            } catch (IOException var8) {
                mac = "Error retrieving MAC address";
            }

            sb.append("\nMAC address: ");
            sb.append(mac);

            String ip;
            try {
                ip = Platform.getLocalHostAddress();
            } catch (UnknownHostException var7) {
                ip = "Error retrieving IP address";
            }

            sb.append("\nIP address: ");
            sb.append(ip);

            String hostname;
            try {
                hostname = Platform.getLocalHostName();
            } catch (UnknownHostException var6) {
                hostname = "Error retrieving hostname";
            }

            sb.append("\nHostname: ");
            sb.append(hostname);
            sb.append("\n******************************************************");
            return sb.toString();
        }
    }
}
