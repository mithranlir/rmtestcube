package gencube.web.action;

import gencube.meta.model.HierarchyData;
import gencube.web.form.HierarchyForm;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;

public class HierarchyActionProcessorTest {

    @Test
    public void testAddDim() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.ADD_DIM);
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(8);
        assertThat(form.getHierarchies().get(7).getDimensionName()).isEmpty();
        assertThat(form.getHierarchies().get(7).getHierarchyName()).isEmpty();
        assertThat(form.getHierarchies().get(7).getHierarchyFolder()).isNull();
        assertThat(form.getHierarchies().get(7).getDefaultHierarchy()).isFalse();
        assertThat(form.getHierarchies().get(7).getLevelNames()).isEmpty();
    }

    @Test
    public void testAddHierarchy_on_first_dim() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.ADD_HIER);
        form.setPosition("1");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(8);
        assertThat(form.getHierarchies().get(2).getDimensionName()).isEqualTo("dim1");
        assertThat(form.getHierarchies().get(2).getHierarchyName()).isNull();
        assertThat(form.getHierarchies().get(2).getHierarchyFolder()).isNull();
        assertThat(form.getHierarchies().get(2).getDefaultHierarchy()).isFalse();
        assertThat(form.getHierarchies().get(2).getLevelNames()).hasSize(1);
        assertThat(form.getHierarchies().get(2).getLevelNames().get(0)).isEmpty();

    }

    @Test
    public void testAddHierarchy_on_middle_dim() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.ADD_HIER);
        form.setPosition("4");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(8);
        assertThat(form.getHierarchies().get(5).getDimensionName()).isEqualTo("dim2");
        assertThat(form.getHierarchies().get(5).getHierarchyName()).isNull();
        assertThat(form.getHierarchies().get(5).getHierarchyFolder()).isNull();
        assertThat(form.getHierarchies().get(5).getDefaultHierarchy()).isFalse();
        assertThat(form.getHierarchies().get(5).getLevelNames()).hasSize(1);
        assertThat(form.getHierarchies().get(5).getLevelNames().get(0)).isEmpty();
    }

    @Test
    public void testAddHierarchy_on_last_dim() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.ADD_HIER);
        form.setPosition("6");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(8);
        assertThat(form.getHierarchies().get(7).getDimensionName()).isEqualTo("dim3");
        assertThat(form.getHierarchies().get(7).getHierarchyName()).isNull();
        assertThat(form.getHierarchies().get(7).getHierarchyFolder()).isNull();
        assertThat(form.getHierarchies().get(7).getDefaultHierarchy()).isFalse();
        assertThat(form.getHierarchies().get(7).getLevelNames()).hasSize(1);
        assertThat(form.getHierarchies().get(7).getLevelNames().get(0)).isEmpty();
    }

    @Test
    public void testDelDim_on_last_dim() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.DEL_DIM);
        form.setPosition("6");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(6);
    }

    @Test
    public void testDelDim_on_middle_dim() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.DEL_DIM);
        form.setPosition("2");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(4);
        for(int i=0;i<form.getHierarchies().size();i++) {
            if(i>=0 && i<=1) {
                assertThat(form.getHierarchies().get(i).getDimensionName()).isEqualTo("dim1");
            }
            if(i>=2 && i<=3) {
                assertThat(form.getHierarchies().get(i).getDimensionName()).isEqualTo("dim3");
            }
        }
    }

    @Test
    public void testDelDim_on_first_dim() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.DEL_DIM);
        form.setPosition("0");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(5);
        for(int i=0;i<form.getHierarchies().size();i++) {
            if(i>=0 && i<=2) {
                assertThat(form.getHierarchies().get(i).getDimensionName()).isEqualTo("dim2");
            }
            if(i>=3 && i<=4) {
                assertThat(form.getHierarchies().get(i).getDimensionName()).isEqualTo("dim3");
            }
        }
    }


    @Test
    public void testDelHierarchy_first_hierarchy() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.DEL_HIER);
        form.setPosition("5");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(6);
        assertThat(form.getHierarchies().get(5).getHierarchyName()).isEqualTo("hier3-2");
    }

    @Test
    public void testDelHierarchy_middle_hierarchy() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.DEL_HIER);
        form.setPosition("3");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(6);
        assertThat(form.getHierarchies().get(3).getHierarchyName()).isEqualTo("hier2-3");
    }

    @Test
    public void testDelHierarchy_last_hierarchy() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.DEL_HIER);
        form.setPosition("4");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(6);
        assertThat(form.getHierarchies().get(4).getHierarchyName()).isEqualTo("hier3-1");
    }

    @Test
    public void testAddLevel() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.ADD_LEVEL);
        form.setPosition("5");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(7);
        assertThat(form.getHierarchies().get(5).getLevelNames()).hasSize(3);
        assertThat(form.getHierarchies().get(5).getLevelNames()).isEqualTo(Arrays.asList("level_10", "level_11", ""));
    }

    @Test
    public void testDelLevel() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.DEL_LEVEL);
        form.setPosition("5");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(7);
        assertThat(form.getHierarchies().get(5).getLevelNames()).hasSize(1);
        assertThat(form.getHierarchies().get(5).getLevelNames()).isEqualTo(Arrays.asList("level_10"));
    }

    @Test
    public void testMoveUpHierarchy() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.MOVE_UP_HIER);
        form.setPosition("1");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(7);
        assertThat(form.getHierarchies().get(0).getHierarchyName()).isEqualTo("hier1-2");
        assertThat(form.getHierarchies().get(1).getHierarchyName()).isEqualTo("hier1-1");
    }

    @Test
    public void testMoveDownHierarchy() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.MOVE_DOWN_HIER);
        form.setPosition("0");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(7);
        assertThat(form.getHierarchies().get(0).getHierarchyName()).isEqualTo("hier1-2");
        assertThat(form.getHierarchies().get(1).getHierarchyName()).isEqualTo("hier1-1");
    }

    @Test
    public void testMoveUpDimension() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.MOVE_UP_DIM);
        form.setPosition("2");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(7);
        assertThat(form.getHierarchies().get(0).getDimensionName()).isEqualTo("dim2");
        assertThat(form.getHierarchies().get(0).getHierarchyName()).isEqualTo("hier2-1");
        assertThat(form.getHierarchies().get(1).getDimensionName()).isEqualTo("dim2");
        assertThat(form.getHierarchies().get(1).getHierarchyName()).isEqualTo("hier2-2");
        assertThat(form.getHierarchies().get(2).getDimensionName()).isEqualTo("dim2");
        assertThat(form.getHierarchies().get(2).getHierarchyName()).isEqualTo("hier2-3");
        assertThat(form.getHierarchies().get(3).getDimensionName()).isEqualTo("dim1");
        assertThat(form.getHierarchies().get(3).getHierarchyName()).isEqualTo("hier1-1");
        assertThat(form.getHierarchies().get(4).getDimensionName()).isEqualTo("dim1");
        assertThat(form.getHierarchies().get(4).getHierarchyName()).isEqualTo("hier1-2");
    }

    @Test
    public void testMoveDownDimension() {
        final HierarchyActionProcessor actionProcessor = new HierarchyActionProcessor();
        final HierarchyForm form = createFakeHierarchyForm();
        form.setActionName(HierarchyActionProcessor.MOVE_DOWN_DIM);
        form.setPosition("0");
        actionProcessor.applyAction(form);
        assertThat(form.getHierarchies()).hasSize(7);
        assertThat(form.getHierarchies().get(0).getDimensionName()).isEqualTo("dim2");
        assertThat(form.getHierarchies().get(0).getHierarchyName()).isEqualTo("hier2-1");
        assertThat(form.getHierarchies().get(1).getDimensionName()).isEqualTo("dim2");
        assertThat(form.getHierarchies().get(1).getHierarchyName()).isEqualTo("hier2-2");
        assertThat(form.getHierarchies().get(2).getDimensionName()).isEqualTo("dim2");
        assertThat(form.getHierarchies().get(2).getHierarchyName()).isEqualTo("hier2-3");
        assertThat(form.getHierarchies().get(3).getDimensionName()).isEqualTo("dim1");
        assertThat(form.getHierarchies().get(3).getHierarchyName()).isEqualTo("hier1-1");
        assertThat(form.getHierarchies().get(4).getDimensionName()).isEqualTo("dim1");
        assertThat(form.getHierarchies().get(4).getHierarchyName()).isEqualTo("hier1-2");
    }

    private HierarchyData create(String dimensionName, String hierarchyName, String... levels) {
        final HierarchyData hierarchyData = new HierarchyData();
        hierarchyData.setDimensionName(dimensionName);
        hierarchyData.setHierarchyName(hierarchyName);
        hierarchyData.setHierarchyFolder("folder3");
        hierarchyData.setDefaultHierarchy(true);
        hierarchyData.setLevelNames(new ArrayList<>(Arrays.asList(levels)));
        return hierarchyData;
    }

    public HierarchyForm createFakeHierarchyForm() {
        final HierarchyForm hierarchyForm = new HierarchyForm();
        hierarchyForm.getHierarchies().add(create("dim1", "hier1-1", "level_1"));
        hierarchyForm.getHierarchies().add(create("dim1", "hier1-2", "level_2", "level_3"));
        hierarchyForm.getHierarchies().add(create("dim2", "hier2-1", "level_4", "level_5"));
        hierarchyForm.getHierarchies().add(create("dim2", "hier2-2", "level_6", "level_7"));
        hierarchyForm.getHierarchies().add(create("dim2", "hier2-3", "level_8", "level_9"));
        hierarchyForm.getHierarchies().add(create("dim3", "hier3-1", "level_10", "level_11"));
        hierarchyForm.getHierarchies().add(create("dim3", "hier3-2", "level_12"));
        return hierarchyForm;
    }

}
