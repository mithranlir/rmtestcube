package gencube;

import gencube.loadinghistory.FileLoading;
import gencube.meta.model.HierarchyData;
import gencube.meta.model.MetaDataColumn;
import gencube.validation.ColumnValidationResult;
import gencube.validation.ValidationResult;
import gencube.web.form.ColumnForm;
import gencube.web.form.FileLoadingForm;
import gencube.web.form.HierarchyForm;
import rmlib.typevalidator.model.TypeValidatorValidResult;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class FakeDataHelper {

    public static List<Integer> createIntegerList() {
        final List<Integer> intList = new ArrayList<>();
        for(int i=1; i<500; i++) {
            intList.add(i);
        }
        return intList;
    }

    public static List<String> getFakeLevels() {
        return Arrays.asList("level1", "level2", "level3", "level4", "level5", "level6");
    }


    public static ValidationResult createFakeValidationResult() {

        final TypeValidatorValidResult typeValidatorValidResult1 = new TypeValidatorValidResult();
        final MetaDataColumn metaColumn1 = new MetaDataColumn();
        metaColumn1.setLevelName("field1");
        metaColumn1.setType("string");
        metaColumn1.setFormat(null);
        final ColumnValidationResult column1 = new ColumnValidationResult(typeValidatorValidResult1, metaColumn1);

        final TypeValidatorValidResult typeValidatorValidResult2 = new TypeValidatorValidResult();
        typeValidatorValidResult2.setInvalidDateFormat(true);
        typeValidatorValidResult2.setErrorSample("10-01-2016");
        final MetaDataColumn metaColumn2 = new MetaDataColumn();
        metaColumn2.setLevelName("field2");
        metaColumn2.setType("date");
        metaColumn2.setFormat("YYYY-MM-DD");
        final ColumnValidationResult column2 = new ColumnValidationResult(typeValidatorValidResult2, metaColumn2);

        final ValidationResult validationResult = new ValidationResult();
        validationResult.getColumnValidationResultList().add(column1);
        validationResult.getColumnValidationResultList().add(column2);

        return validationResult;
    }


    public static ColumnForm createFakeColumnForm() {

        final ColumnForm columnForm = new ColumnForm();
        columnForm.setDataSeparator("|");
        columnForm.setSkipFirstLines("0");

        final MetaDataColumn metaColumn1 = new MetaDataColumn();
        metaColumn1.setLevelName("field1");
        metaColumn1.setType("string");
        metaColumn1.setFormat(null);
        metaColumn1.setMeasure(false);
        metaColumn1.setAllMembersEnabled(true);
        columnForm.getColumns().add(metaColumn1);

        final MetaDataColumn metaColumn2 = new MetaDataColumn();
        metaColumn2.setLevelName("field2");
        metaColumn2.setType("date");
        metaColumn2.setFormat("yyyy-MM-dd");
        metaColumn2.setMeasure(false);
        metaColumn2.setAllMembersEnabled(false);
        columnForm.getColumns().add(metaColumn2);

        final MetaDataColumn metaColumn3 = new MetaDataColumn();
        metaColumn3.setLevelName("field3");
        metaColumn3.setType("float");
        metaColumn3.setFormat(null);
        metaColumn3.setMeasure(true);
        metaColumn3.setAllMembersEnabled(false);
        columnForm.getColumns().add(metaColumn3);

        return columnForm;
    }

    public static HierarchyForm createFakeHierarchyForm() {

        final HierarchyForm hierarchyForm = new HierarchyForm();

        final HierarchyData hierarchyData1 = new HierarchyData();
        hierarchyData1.setDimensionName("dim1");
        hierarchyData1.setHierarchyName("hier1");
        hierarchyData1.setHierarchyFolder("folder1");
        hierarchyData1.setDefaultHierarchy(true);
        final List<String> levels1 = new ArrayList<>();
        levels1.add("level1");
        hierarchyData1.setLevelNames(levels1);
        hierarchyForm.getHierarchies().add(hierarchyData1);

        final HierarchyData hierarchyData2 = new HierarchyData();
        hierarchyData2.setDimensionName("dim1");
        hierarchyData2.setHierarchyName("hier2");
        hierarchyData2.setHierarchyFolder("folder2");
        hierarchyData2.setDefaultHierarchy(true);
        final List<String> levels2 = new ArrayList<>();
        levels2.add("level2");
        levels2.add("level3");
        hierarchyData2.setLevelNames(levels2);
        hierarchyForm.getHierarchies().add(hierarchyData2);

        final HierarchyData hierarchyData3 = new HierarchyData();
        hierarchyData3.setDimensionName("dim2");
        hierarchyData3.setHierarchyName("hier3");
        hierarchyData3.setHierarchyFolder("folder3");
        hierarchyData3.setDefaultHierarchy(true);
        final List<String> levels3 = new ArrayList<>();
        levels3.add("level4");
        levels3.add("level5");
        levels3.add("level6");
        hierarchyData3.setLevelNames(levels3);
        hierarchyForm.getHierarchies().add(hierarchyData3);

        return hierarchyForm;
    }

    public static FileLoadingForm createFakeFileLoadingForm() {
        final FileLoadingForm fileLoadingForm = new FileLoadingForm();
        final List<FileLoading> fileLoadingList = new ArrayList<>();

        final FileLoading fileLoading1 = new FileLoading();
        fileLoading1.setDataFileName("data1.csv");
        fileLoading1.setMetaFileName("data1.meta.csv");
        fileLoading1.setStartDate(new Date());
        fileLoading1.setEndDate(new Date());
        fileLoading1.setErrorLogFileName("cube-1462737161791.log.txt");
        fileLoading1.setHasError(true);
        fileLoadingList.add(fileLoading1);

        final FileLoading fileLoading2 = new FileLoading();
        fileLoading2.setDataFileName("data2.csv");
        fileLoading2.setMetaFileName("data2.meta.csv");
        fileLoading2.setStartDate(new Date());
        fileLoading2.setEndDate(new Date());
        fileLoading2.setErrorLogFileName("cube-1462737161791.log.txt");
        fileLoading2.setHasError(true);
        fileLoadingList.add(fileLoading2);

        fileLoadingForm.setFileLoadingList(fileLoadingList);
        return fileLoadingForm;
    }

}
