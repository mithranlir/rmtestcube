package gencube;

import gencube.meta.MetaCsvWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Random;

public class GenerateBigFile {

    public static final String SEP = "|";

    public final static void main(String... args) throws IOException {

        //int n = 2_700_000;
        //int n = 2_400_000; 420M
        int n = 2_000_000;
        //int n = 700_000;

        final File file1 = new File("D:\\dev\\tmp\\bigfile.metadata.csv");
        final File file2 = new File("D:\\dev\\tmp\\bigfile.csv");

        Random random = new Random();

        FileWriter fw = new FileWriter(file1);
        fw.write(
                MetaCsvWriter.FIELD_DEF_HEADER + "\n" +
                "DATA_SEP_DEF||\n" +
                "SKIPLINES_DEF|0\n" +
                "FIELD_DEF|VAL2_DATE|date|yyyy.MM.dd-HH:mm:ss.SSS|yyyy.MM.dd-HH:mm:ss.SSS|false|true\n" +
                "FIELD_DEF|VAL2_AMOUNT|double|||true|true\n" +
                "FIELD_DEF|VAL2_ID|long||false||true\n" +
                "FIELD_DEF|VAL2_AMOUNT2|double|||true|true\n" +
                "FIELD_DEF|VAL2_STR1|string|||false|true\n" +
                "FIELD_DEF|VAL2_STR2|string|||false|true\n" +
                "FIELD_DEF|VAL2_STR3|string|||false|true\n"+
                "FIELD_DEF|VAL2_STR4|string|||false|true\n"+
                "FIELD_DEF|VAL2_ID2|long|||false|true\n"
        );
        fw.flush();
        fw.close();

        final FileOutputStream fileOutputStream = new FileOutputStream(file2, false);
        final FileChannel fileChannel = fileOutputStream.getChannel();
        ByteBuffer byteBuffer = null;
        String messageToWrite = null;
        int blockDate = 10;

        for (int i = 0; i < n; i++) {

            // VAL2_DATE
            messageToWrite = "2015.03." + String.format(Locale.US, "%02d", ((i % blockDate) + 1)) + "-01:00:00.000" + SEP;
             // VAL2_AMOUNT
            messageToWrite += String.format(Locale.US, "%.2f", 100000455.0 + i) + SEP;
            // VAL2_ID
            messageToWrite += (01550 + i + + random.nextInt(10)) + SEP;
            // VAL2_AMOUNT2
            messageToWrite += String.format(Locale.US, "%.2f", 200000455.0 + i) + SEP;
            // VAL2_STR1
            messageToWrite += "AAAA AAA" + i + random.nextInt(10) + SEP;
            // VAL2_STR2
            messageToWrite += "B BBBBBBBBBBBBBBBB" + i + SEP;
            // VAL2_STR3
            messageToWrite += "C CCCCCCCCAAAAAAAAAAAAAAAAAAC" + i + SEP;
            // VAL2_STR4
            messageToWrite += "C CCCCCCCCAAAAAAAAAAAAAAAAAAC" + i + SEP;
            // VAL2_ID2
            messageToWrite += (i + 4551115500l + + random.nextInt(10));
            messageToWrite += "\n";

            byteBuffer = ByteBuffer.wrap(messageToWrite.getBytes(Charset.forName("UTF-8")));
            fileChannel.write(byteBuffer);
        }
        fileChannel.close();
    }

}