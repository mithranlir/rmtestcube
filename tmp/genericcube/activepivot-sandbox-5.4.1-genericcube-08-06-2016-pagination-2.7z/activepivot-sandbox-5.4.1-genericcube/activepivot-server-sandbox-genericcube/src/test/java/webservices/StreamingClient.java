/*
 * (C) Quartet FS 2012-2015
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package webservices;

import com.qfs.QfsWebUtils;
import com.qfs.webservices.*;

import java.net.URL;

import static com.qfs.sandbox.server.SandboxServer.DEFAULT_PORT;
import static com.qfs.server.cfg.impl.ActivePivotServicesConfig.*;
import static com.qfs.server.cfg.impl.CxfServletConfig.CXF_WEB_SERVICES;

/**
 *
 * An ActivePivot client that connects to ActivePivot Web Services
 * using java classes generated with the Apache CXF wsdl2java tool.
 * <p>
 * This client expects by default that an ActivePivot application
 * with anonymous access runs at<pre>http://localhost:9090</pre>
 *
 * @author Quartet FS
 *
 */
public class StreamingClient {

	/** Default url */
	public static final String URL = QfsWebUtils.url(true, "http://localhost:" + DEFAULT_PORT, CXF_WEB_SERVICES);

	public void run() throws Exception {
		// Instantiate service
		System.out.println("Connecting to ActivePivot Streaming Services at " + URL);

		IIdGenerator ig = new IdGenerator(new URL(URL + ID_GENERATOR_SERVICE + "?wsdl")).getIdGeneratorPort();
		IStreamingService ss = new StreamingService(new URL(URL + STREAMING_SERVICE + "?wsdl")).getStreamingServicePort();
		ILongPollingService lps = new LongPollingService(new URL(URL + LONG_POLLING_SERVICE + "?wsdl")).getLongPollingServicePort();

		// Register a continuous MDX query
		final String domain = "myDomain";
		final String streamId = ig.generateStreamIds(1).get(0);
		StreamProperties props = new StreamProperties();
		props.setStreamId(streamId);
		props.setPublicationDomain(domain);
		props.setPushData(true);
		props.setInitialState(InitialState.STARTED);

		final String listenerId = ig.generateListenerIds(1).get(0);
		lps.addListener(domain, listenerId);

		// MDX query to retrieve the total pnl.
		MdxQuery query = new MdxQuery();
		query.setContent("SELECT {[Measures].[pnl.SUM]} ON ROWS FROM [EquityDerivativesCube]");
		ss.createStream(query, props);

		// Long polling listener loop
		try {
			for (int i = 0; i < 5; i++) {
				System.out.print("Listening to real-time events of stream " + streamId + " ... ");
				BulkedEvents events = lps.listen(listenerId);
				if (events == null)
					continue;
				System.out.println(events.getDomainEvents().getDomainEvent().size() + " domain event(s) received:");

				for (DomainEvent domainEvent : events.getDomainEvents().getDomainEvent()) {
					for (StreamEvent streamEvent : domainEvent.getEvents()
							.getActivePivotEventOrFailureEventOrDrillthroughEvent()) {
						String eventStreamId = streamEvent.getStreamId();
						if (streamId.equalsIgnoreCase(eventStreamId)) {
							if (streamEvent instanceof CellEvent) {
								CellEvent cellEvent = (CellEvent) streamEvent;
								if (cellEvent.getCells().isEmpty()) {
									System.out.println("Received empty cell event");
								} else {
									for (Cell cell : cellEvent.getCells()) {
										System.out.println("Cell update: before=" + cell.getPreviousValue() + ", after=" + cell.getFormattedValue());
									}
								}
							} else {
								System.out.println("Received stream event: " + streamEvent);
							}
						} else {
							System.out.println("Received stream event from another stream (" + eventStreamId + ")");
						}
					}
				}

				System.out.println();
			}

		} finally {
			// Remove listener to avoid wasting server side resources.
			lps.removeListener(domain, listenerId);
		}

	}

	/**
	 *
	 * Launch the client and perform a series of tests.
	 *
	 * @param parameters the parameters
	 * @throws Exception the exception
	 */
	public static void main(String[] parameters) throws Exception {
		HTTPAuthenticator.install();
		new StreamingClient().run();
	}

}
