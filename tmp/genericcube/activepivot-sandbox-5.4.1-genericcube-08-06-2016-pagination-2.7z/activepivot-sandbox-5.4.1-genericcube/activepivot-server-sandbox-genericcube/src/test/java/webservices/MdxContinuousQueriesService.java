package webservices;

import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.dto.CellDTO;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.query.impl.MDXQuery;
import com.quartetfs.biz.pivot.streaming.ICellEvent;
import com.quartetfs.biz.pivot.streaming.ICellSetEvent;
import com.quartetfs.biz.pivot.streaming.impl.MdxStream;
import com.quartetfs.biz.pivot.streaming.impl.MdxStreamRegister;
import com.quartetfs.fwk.AgentException;
import com.quartetfs.tech.streaming.IStreamEvent;
import com.quartetfs.tech.streaming.IStreamListener;
import com.quartetfs.tech.streaming.IStreamProperties.InitialState;
import com.quartetfs.tech.streaming.impl.StreamProperties;
import com.quartetfs.tech.streaming.impl.StreamPublisher;

import java.util.List;

/**
 * <b>MdxContinuousQueriesService</b>
 * <p>
 *
 * @author Quartet Financial Systems
 * @see
 */
public class MdxContinuousQueriesService {

    protected IActivePivotManager manager;

    public MdxContinuousQueriesService(IActivePivotManager manager) {
        this.manager = manager;
    }
    public void startQuery(final String name, String mdx) {
        MdxStreamRegister register = new MdxStreamRegister();
        register.setActivePivotManager(manager);
        IMDXQuery query = new MDXQuery(mdx);
        StreamProperties props = new StreamProperties("1", "test-dom", InitialState.STARTED, true);
        StreamPublisher publisher = new StreamPublisher();
        try {
            publisher.addListener("test-dom", new IStreamListener() {
                /** serialVersionUID */
                private static final long serialVersionUID = -7288431439068071528L;

                @Override
                public void onEvent(String domain, List<IStreamEvent> events) {
                    for(IStreamEvent event : events) {
                        if(event instanceof ICellSetEvent) {
                            System.out.print(name + " ICellSetEvent: ");
                            ICellSetEvent e = (ICellSetEvent) event;
                            System.out.println(e.getCellSet().toString());
                        } else if(event instanceof ICellEvent) {
                            System.out.print(name + " ICellEvent: ");
                            ICellEvent e = (ICellEvent) event;
                            for(CellDTO dto : e.getCells())
                                System.out.println(name + " " +dto.toString());
                        } else {
                            System.out.println(name + " onEvent: " + domain);
                        }
                    }
                }
            });

            MdxStream stream = new MdxStream(query, props, publisher);
            stream.setMdxStreamRegister(register);
            stream.setActivePivotManager(manager);
            //start is called in init because 'initial state' in the StreamProperties is STARTED
            stream.init(null);
        } catch (AgentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
    }
}