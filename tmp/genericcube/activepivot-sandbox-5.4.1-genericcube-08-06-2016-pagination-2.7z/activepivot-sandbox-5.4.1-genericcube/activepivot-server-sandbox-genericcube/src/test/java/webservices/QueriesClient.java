/*
 * (C) Quartet FS 2012-2015
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package webservices;

import com.qfs.QfsWebUtils;
import com.qfs.webservices.*;
import com.qfs.webservices.DrillthroughQuery.Locations;
import com.qfs.webservices.DrillthroughResult.Rows;
import com.quartetfs.biz.pivot.ILocation;
import org.junit.Assert;

import java.net.URL;
import java.util.List;

import static com.qfs.sandbox.server.SandboxServer.DEFAULT_PORT;
import static com.qfs.server.cfg.impl.ActivePivotServicesConfig.QUERY_SERVICE;
import static com.qfs.server.cfg.impl.CxfServletConfig.CXF_WEB_SERVICES;

/**
 *
 * An ActivePivot client that connects to ActivePivot Web Services
 * using java classes generated with the Apache CXF wsdl2java tool.
 * <p>
 * This client expects by default that an ActivePivot application
 * with anonymous access runs at<pre>http://localhost:9090</pre>
 *
 * @author Quartet FS
 *
 */
public class QueriesClient {

	/** Default url */
	public static final String URL = QfsWebUtils.url("http://localhost:" + DEFAULT_PORT, CXF_WEB_SERVICES, QUERY_SERVICE, "?wsdl");

	/**
	 *
	 * Launch the client and perform a series of tests.
	 *
	 * @param parameters the parameters
	 * @throws Exception the exception
	 */
	public static void main(String[] parameters) throws Exception {
		HTTPAuthenticator.install();
		new QueriesClient().run();
	}

	public void run() throws Exception {

		// Instantiate service
		System.out.println("Connecting to ActivePivot Queries Service at " + URL);
		IQueriesService qs = new QueriesService(new URL(URL)).getQueriesServicePort();

		// Retrieve the default members of each hierarchies
		retrieveDefaultMembers(qs, "cube");

		System.out.println("----------------------------------------------");

		String mdx = "SELECT NON EMPTY Hierarchize(\n" +
				"  [default].[VAL2_DATE].[VAL2_DATE].Members\n" +
				") ON COLUMNS,\n" +
				"NON EMPTY Hierarchize(\n" +
				"  [default].[VAL2_STR1].[VAL2_STR1].Members\n" +
				") ON ROWS \n" +
				"FROM [cube] \n" +
				"WHERE [Measures].[contributors.COUNT]";

		String mdx2 = "SELECT NON EMPTY Hierarchize(\n" +
				"  [default].[VAL2_DATE].[VAL2_DATE].Members\n" +
				") ON COLUMNS,\n" +
				"NON EMPTY CrossJoin(\n" +
				"  Hierarchize(\n" +
				"    [default].[VAL2_ID].[VAL2_ID].Members\n" +
				"  ),\n" +
				"  Hierarchize(\n" +
				"    [default].[VAL2_STR1].[VAL2_STR1].Members\n" +
				"  )\n" +
				") ON ROWS \n" +
				"FROM [cube] \n" +
				"WHERE [Measures].[contributors.COUNT]";

		executeMDX(qs, mdx2);

		System.out.println("----------------------------------------------");

		// Return the existing flat context values properties
		getFlatContextValueProperties(qs);

		System.out.println("----------------------------------------------");

		executeGetAggregates("cube",qs,
				ILocation.WILDCARD + "|" + ILocation.WILDCARD + "|" + ILocation.WILDCARD + "|" + ILocation.WILDCARD,
				"contributors.COUNT");

		System.out.println();
	}


	protected static void retrieveDefaultMembers(IQueriesService qs, String pivotId) {
		System.out.println("Retrieving default members for each hierarchy in " + pivotId);
		List<HierarchyDTO> hierarchies = qs.retrieveAllHierarchies(pivotId);
		List<MemberDTO> defaultMembers = qs.retrieveDefaultMembers(pivotId);
		for (int h = 0; h < hierarchies.size(); h++) {
			HierarchyDTO hier = hierarchies.get(h);
			MemberDTO dm = defaultMembers.get(h);
			System.out.println("   " + hier + ": " + dm);
		}
	}

	protected static void executeMDX(IQueriesService qs, String mdx) {
		MdxQuery query = new MdxQuery();
		query.setContent(mdx);
		CellSet cellSet = qs.executeMDX(query);

		new CellSetPrinter(cellSet).print(System.out);
	}

	protected static void getFlatContextValueProperties(final IQueriesService qs) {
		List<StringProperty> properties = qs.getFlatContextValueProperties();
		for (StringProperty property : properties) {
			System.out.println(property.getKey() + "=" + property.getValue());
		}
	}

	protected void executeGetAggregates(String cubeName, final IQueriesService qs, String locationString, String measuresString) {
		GetAggregatesQuery gaQuery = new GetAggregatesQuery();
		gaQuery.getLocations().add(locationString);
		gaQuery.getMeasureSelections().add(measuresString);
		gaQuery.setPivotId(cubeName);
		qs.executeGetAggregates(gaQuery);

		List<Aggregate> result = qs.executeGetAggregates(gaQuery);
		System.out.println("GetAggregates returned " + result.size() + " results");
		for (Aggregate agg : result) {
			System.out.println("Location:" + agg.getLocation() + ", aggregates: ");

			for (MapEntry entry : agg.getAggregates().getEntry())
				System.out.print(entry.getKey() + ":" + entry.getValue() + " ");
			System.out.println("");
		}
	}
}
