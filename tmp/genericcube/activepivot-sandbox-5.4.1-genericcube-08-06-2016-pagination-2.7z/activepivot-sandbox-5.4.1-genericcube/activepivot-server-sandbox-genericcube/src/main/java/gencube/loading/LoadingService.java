package gencube.loading;

import com.qfs.store.log.impl.LogWriteException;
import com.quartetfs.fwk.AgentException;
import com.quartetfs.fwk.query.QueryException;
import gencube.build.CubeReloader;
import gencube.loadinghistory.FileLoadingHistoryService;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class LoadingService {

    private CubeReloader cubeReloader;
    private FileLoadingHistoryService fileLoadingHistoryService;

    private final ScheduledExecutorService service = Executors.newScheduledThreadPool(1);

    public LoadingService(CubeReloader cubeReloader, FileLoadingHistoryService fileLoadingHistoryService) {
        this.cubeReloader = cubeReloader;
        this.fileLoadingHistoryService = fileLoadingHistoryService;
    }

    public void startAsyncCsvLoading() throws Exception {
        cubeReloader.rebuildCube();
        cubeReloader.initAndStartManager();
        service.submit(createRunnableToStartLoading());
    }

    public boolean isCurrentFileLoadingFinished() {
        if(cubeReloader==null) {
            return true;
        }
        return cubeReloader.getCurrentFileLoading().isFinished();
    }

    private Runnable createRunnableToStartLoading() {
        return new Runnable() {
            @Override
            public void run() {
                startLoading();
            }
        };
    }

    private void startLoading() {
        try {
            cubeReloader.csvLoad();
        }
        catch (LogWriteException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        try {
            cubeReloader.postLoading();
        }
        catch (QueryException e) {
            e.printStackTrace();
        }
    }



}
