package gencube.csv;

import com.qfs.msg.IMessage;
import com.qfs.msg.csv.IFileInfo;
import com.qfs.msg.csv.ILineReader;
import com.qfs.msg.csv.impl.LineReader;
import com.qfs.msg.csv.impl.Parser;
import gnu.trove.list.array.TIntArrayList;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class CustomParser extends Parser {

    private static int MAX_ERROR = 2;

    private AtomicInteger cpt = new AtomicInteger();
    private StopParsingListener stopParsingListener;

    public CustomParser(StopParsingListener stopParsingListener) {
        this.stopParsingListener = stopParsingListener;
    }

    @Override
    protected void onParsingFailed(Throwable t, ILineReader currentReader, char[] parsedData, int lineStart, int lineEnd, int currentLine, IMessage<IFileInfo, ILineReader> message) {
        processError(currentReader);
        super.onParsingFailed(t, currentReader, parsedData, lineStart, lineEnd, currentLine, message);
    }

    @Override
    protected void onTranslationFailure(Exception e, ILineReader currentReader, IMessage<IFileInfo, ILineReader> message) {
        processError(currentReader);
        super.onTranslationFailure(e, currentReader, message);
    }

    private void processError(ILineReader currentReader) {
        final int nbErrors = cpt.incrementAndGet();
        if(nbErrors > MAX_ERROR) {
            final String currentFileName = currentReader.getCurrentFile().getName();
            // notify information listener
            stopParsingListener.onMaxParsingErrorReached(currentFileName);
            // stop parsing
            throw new StopParsingException("Max errors reached. Stop Parsing on " + currentFileName);
        }
    }

    @Override
    protected void computeRemovalChars(LineReader lineReader, TIntArrayList[] doubleQuotes) {
        if(stopParsingListener.isStopParsingRequested()) {
            throw new StopParsingException("Stop Parsing requested");
        }
        super.computeRemovalChars(lineReader, doubleQuotes);
    }
}
