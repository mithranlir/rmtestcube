package gencube.csv;

import com.qfs.msg.IMessageChannel;
import com.qfs.msg.csv.*;
import com.qfs.msg.csv.impl.Parser;
import com.qfs.msg.csv.impl.ParserContext;
import com.qfs.msg.csv.impl.ParserThreadPool;
import com.qfs.msg.csv.impl.PublicationQueue;

public class CustomParserContext extends ParserContext {

    private PublicationQueue currentPublicationQueue;

    private StopParsingListener stopParsingListener;

    public CustomParserContext(
            ICSVSource parentSource,
            ICSVParserConfiguration cfg,
            ParserThreadPool threadPool,
            IMessageChannel<IFileInfo, ILineReader> messageChannel,
            StopParsingListener stopParsingListener) {
        super(parentSource, cfg, threadPool, messageChannel);
        this.stopParsingListener = stopParsingListener;
    }

    @Override
    protected PublicationQueue getPublicationQueue(IFileInfo fileInfo) {
        final PublicationQueue publicationQueue = super.getPublicationQueue(fileInfo);
        this.currentPublicationQueue = publicationQueue;
        return publicationQueue;
    }

    public long getReadSize() {
        if(currentPublicationQueue!=null) {
            final IParsingInfo parsingInfo = currentPublicationQueue.getParsingInfo();
            return parsingInfo.getByteCount();
        }
        return 0;
    }

    @Override
    public Parser createParser() {
        return new CustomParser(stopParsingListener);
    }
}
