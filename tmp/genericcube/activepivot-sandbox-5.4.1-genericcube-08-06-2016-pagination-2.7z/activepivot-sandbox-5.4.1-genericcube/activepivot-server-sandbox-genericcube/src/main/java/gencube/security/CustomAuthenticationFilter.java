package gencube.security;

import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.NullRememberMeServices;
import org.springframework.security.web.authentication.RememberMeServices;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.util.StringUtils;
import org.springframework.web.util.HtmlUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CustomAuthenticationFilter extends BasicAuthenticationFilter {

    private AuthenticationManager authenticationManager;
    private AuthenticationEntryPoint authenticationEntryPoint;
    private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = new WebAuthenticationDetailsSource();
    private RememberMeServices rememberMeServices = new NullRememberMeServices();

    public CustomAuthenticationFilter(AuthenticationManager authenticationManager, AuthenticationEntryPoint authenticationEntryPoint) {
        super(authenticationManager, authenticationEntryPoint);
        this.authenticationManager = authenticationManager;
        this.authenticationEntryPoint = authenticationEntryPoint;
    }

    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        final boolean debug = this.logger.isDebugEnabled();
        final String header = request.getHeader("Authorization");
        final String usernameInUrl = HtmlUtils.htmlUnescape(request.getParameter("user"));
        if(!StringUtils.isEmpty(usernameInUrl) && (header ==null || !header.startsWith("Basic "))) {
            try {
                final String token = HtmlUtils.htmlUnescape(request.getParameter("token"));
                if(debug) {
                    this.logger.debug("Authentication Authorization token found for user \'" + usernameInUrl + "\'");
                }

                if(this.authenticationIsRequired(usernameInUrl)) {
                    final UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(usernameInUrl, token);
                    authRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
                    final Authentication authResult = this.authenticationManager.authenticate(authRequest);
                    if(debug) {
                        this.logger.debug("Authentication success: " + authResult);
                    }

                    SecurityContextHolder.getContext().setAuthentication(authResult);
                    this.rememberMeServices.loginSuccess(request, response, authResult);
                    this.onSuccessfulAuthentication(request, response, authResult);
                }
            } catch (AuthenticationException var12) {
                SecurityContextHolder.clearContext();
                if(debug) {
                    this.logger.debug("Authentication request for failed: " + var12);
                }

                this.rememberMeServices.loginFail(request, response);
                this.onUnsuccessfulAuthentication(request, response, var12);
                if(this.isIgnoreFailure()) {
                    chain.doFilter(request, response);
                } else {
                    this.authenticationEntryPoint.commence(request, response, var12);
                }

                return;
            }
            chain.doFilter(request, response);
        }
        else {
            super.doFilter(request, response, chain);
        }

    }

    private boolean authenticationIsRequired(String username) {
        Authentication existingAuth = SecurityContextHolder.getContext().getAuthentication();
        return existingAuth != null && existingAuth.isAuthenticated()?(existingAuth instanceof UsernamePasswordAuthenticationToken
                && !existingAuth.getName().equals(username)?true:existingAuth instanceof AnonymousAuthenticationToken):true;
    }
}
