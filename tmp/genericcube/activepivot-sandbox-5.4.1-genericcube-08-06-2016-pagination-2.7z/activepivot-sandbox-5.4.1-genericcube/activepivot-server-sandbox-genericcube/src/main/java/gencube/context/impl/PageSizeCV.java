package gencube.context.impl;

import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.impl.AContextValue;
import gencube.context.IPageSizeCV;

public class PageSizeCV extends AContextValue implements IPageSizeCV {

	private static final long serialVersionUID = 6430111605013329739L;

	protected String pageSize;

	/** constructor */
	protected PageSizeCV() {}

	public PageSizeCV(String pageSize) {
		this.pageSize = pageSize;
	}

	@Override
	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	@Override
	public String toString() {
		return "PageSize: " + pageSize;
	}

	@Override
	public Class<? extends IContextValue> getContextInterface() {
		return IPageSizeCV.class;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		PageSizeCV that = (PageSizeCV) o;

		return !(pageSize != null ? !pageSize.equals(that.pageSize) : that.pageSize != null);

	}

	@Override
	public int hashCode() {
		return pageSize != null ? pageSize.hashCode() : 0;
	}
}
