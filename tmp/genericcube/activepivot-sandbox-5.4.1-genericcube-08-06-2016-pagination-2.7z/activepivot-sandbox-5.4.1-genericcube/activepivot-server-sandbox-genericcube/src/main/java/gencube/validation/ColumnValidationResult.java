package gencube.validation;

import gencube.meta.model.MetaDataColumn;
import rmlib.typevalidator.model.TypeValidatorValidResult;

public class ColumnValidationResult {

    private MetaDataColumn column;
    private TypeValidatorValidResult typeValidatorValidResult;

    public ColumnValidationResult(TypeValidatorValidResult typeValidatorValidResult, MetaDataColumn column) {
        this.typeValidatorValidResult = typeValidatorValidResult;
        this.column = column;
    }

    public String getLevelName() {
        return column.getLevelName();
    }

    public String getDisplayFormat() {
        return column.getDisplayFormat();
    }

    public String getType() {
        return column.getType();
    }

    public String getFormat() {
        return column.getFormat();
    }

    public boolean isValid() {
        return typeValidatorValidResult.isValid();
    }

    public boolean isDecimalSeparatorWarning() {
        return typeValidatorValidResult.isDecimalSeparatorWarning();
    }

    public boolean isSpaceFoundError() {
        return typeValidatorValidResult.isSpaceFoundError();
    }

    public boolean isInvalidDateFormat() {
        return typeValidatorValidResult.isInvalidDateFormat();
    }

    public String getErrorSample() {
        return typeValidatorValidResult.getErrorSample();
    }

}
