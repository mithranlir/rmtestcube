package gencube.meta;

import java.util.ArrayList;
import java.util.List;

public class BadMetaDataException extends RuntimeException {

    private List<String> errors = new ArrayList<>();

    public BadMetaDataException(String description, List<String> errors) {
        super(description);
        setErrors(errors);
    }

    public void addError(String error) {
        getErrors().add(error);
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }
}
