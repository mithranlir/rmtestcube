package gencube.meta.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Romain on 02/05/2016.
 */
public class HierarchyData {

    private String dimensionName;
    private String hierarchyName;
    private boolean defaultHierarchy;
    private String hierarchyFolder;
    private List<String> levelNames = new ArrayList<>();

    public String getDimensionName() {
        return dimensionName;
    }

    public void setDimensionName(String dimensionName) {
        this.dimensionName = dimensionName;
    }

    public String getHierarchyName() {
        return hierarchyName;
    }

    public void setHierarchyName(String hierarchyName) {
        this.hierarchyName = hierarchyName;
    }

    public boolean getDefaultHierarchy() {
        return defaultHierarchy;
    }

    public void setDefaultHierarchy(boolean defaultHierarchy) {
        this.defaultHierarchy = defaultHierarchy;
    }

    public String getHierarchyFolder() {
        return hierarchyFolder;
    }

    public void setHierarchyFolder(String hierarchyFolder) {
        this.hierarchyFolder = hierarchyFolder;
    }

    public List<String> getLevelNames() {
        return levelNames;
    }

    public void setLevelNames(List<String> levelNames) {
        this.levelNames = levelNames;
    }
}
