package gencube.web.form;

import gencube.validation.FileValidator;
import gencube.web.combo.select.ISelectValue;
import gencube.web.helper.ColumnDataSelectHelper;
import rmlib.typevalidator.model.CubeTypes;

import java.util.List;

import static gencube.web.helper.ColumnDataSelectHelper.*;

public class ColumnFormSelectHelper {

    public static List<ISelectValue<Integer>> getSelectFormatList(ColumnForm columnForm, FileValidator fileValidator) {
        final List<ISelectValue<Integer>> formatValues =
                getValuesWithIntKey(
                        columnForm, fileValidator.getDateFormatList(), getValueGetterForFormat());
        return formatValues;
    }

    public static List<ISelectValue<Integer>> getSelectDisplayFormatList(ColumnForm columnForm, FileValidator fileValidator) {
        final List<ISelectValue<Integer>> displayFormatValues =
                getValuesWithIntKey(
                        columnForm, fileValidator.getDateFormatList(), getValueGetterForDisplayFormat());
        return displayFormatValues;
    }

    public static List<ISelectValue<Integer>> getSelectTypeList(ColumnForm columnForm) {
        final List<ISelectValue<Integer>> selectTypeValues =
                getValuesWithIntKey(
                        columnForm, CubeTypes.TYPES, getValueGetterForType());
        return selectTypeValues;
    }

    public static List<ISelectValue<Integer>> getSelectMeasureList(ColumnForm columnForm) {
        final List<String> booleanValueList = ColumnDataSelectHelper.getFalseTrueValues();
        final List<ISelectValue<Integer>> selectMeasureValues =
                getValuesWithIntKey(
                        columnForm, booleanValueList, getValueGetterForMeasure());
        return selectMeasureValues;
    }

    public static List<ISelectValue<Integer>> getSelectAllMembersEnabledList(ColumnForm columnForm) {
        final List<String> booleanValueList = ColumnDataSelectHelper.getTrueFalseValues();
        final List<ISelectValue<Integer>> selectAllMembersEnabledValues =
                getValuesWithIntKey(
                        columnForm, booleanValueList, getValueGetterForAllMembersEnabled());
        return selectAllMembersEnabledValues;
    }

}
