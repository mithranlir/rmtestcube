package gencube.meta.model;

public class MetaDataColumn {

    private String levelName;
    private String type;
    private String format;
    private String displayFormat;
    private Boolean isMeasure = false;
    private Boolean allMembersEnabled = true;

    public String getLevelName() {
        return levelName;
    }

    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getAllMembersEnabled() {
        return allMembersEnabled;
    }

    public void setAllMembersEnabled(Boolean allMembersEnabled) {
        this.allMembersEnabled = allMembersEnabled;
    }

    public boolean getMeasure() {
        return isMeasure;
    }

    public void setMeasure(Boolean isMeasure) {
        this.isMeasure = isMeasure;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getDisplayFormat() {
        return displayFormat;
    }

    public void setDisplayFormat(String displayFormat) {
        this.displayFormat = displayFormat;
    }
}
