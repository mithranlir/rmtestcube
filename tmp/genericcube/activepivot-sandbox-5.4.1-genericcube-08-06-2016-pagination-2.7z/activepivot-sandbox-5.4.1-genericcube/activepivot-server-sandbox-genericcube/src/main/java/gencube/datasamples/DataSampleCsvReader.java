package gencube.datasamples;

import com.quartetfs.fwk.QuartetRuntimeException;
import gencube.build.PreAnalyzeResult;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class DataSampleCsvReader {

    public PreAnalyzeResult preAnalyzeResult(String filePath, List<String> commonSeparators) {
        final Path path = resolvePath(filePath);
        BufferedReader br = null;
        PreAnalyzeResult result = null;
        try {
            br = new BufferedReader(new FileReader(path.toFile().getAbsoluteFile()));
            final String line = br.readLine();
            if(line == null || line.isEmpty()) {
                return null;
            }
            for(String commonSeparator : commonSeparators) {
                if(line.contains(commonSeparator)) {
                    final String cvsSplitBy = "\\" + commonSeparator.charAt(0);
                    final String[] values = line.split(cvsSplitBy, -1);
                    if(values.length > 1) {
                        result = new PreAnalyzeResult();
                        result.setSeparatorFound(commonSeparator);
                        result.setNbColumns(values.length);
                        break;
                    }
                }
            }
            return result;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public DataSamples readSamples(String filePath, int nbSampleLines, int nbColumn, int skipFirstLines, String dataSeparator) {

        final Path path = resolvePath(filePath);
        final DataSamples dataSamples = new DataSamples();
        BufferedReader br = null;
        final String cvsSplitBy = "\\" + dataSeparator.charAt(0);

        try {
            String line;
            br = new BufferedReader(new FileReader(path.toFile().getAbsoluteFile()));
            int cpt = 0;
            while (cpt<nbSampleLines && (line = br.readLine()) != null) {
                if(cpt >= skipFirstLines) {
                    final String[] values = line.split(cvsSplitBy, -1);
                    if(values.length == 1) {
                        dataSamples.setSeparatorError(true);
                    }
                    else {
                        if (values.length >= nbColumn) {
                            for (int i = 0; i < nbColumn; i++) {
                                if (dataSamples.getSamplesMap().get(i) == null) {
                                    dataSamples.getSamplesMap().put(i, new ArrayList<String>());
                                }
                                dataSamples.getSamplesMap().get(i).add(values[i]);
                            }
                        }
                        else {
                            // TODO : do what ?
                        }
                    }
                }
                cpt++;
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return dataSamples;
    }

    protected Path resolvePath(String path) {
        final URL url = this.getClass().getClassLoader().getResource(path);
        Path p;
        if(url != null) {
            p = Paths.get(URI.create(url.toExternalForm()));
            if(p != null) {
                return p;
            }
        }
        p = Paths.get(path, new String[0]);
        if(p != null) {
            return p;
        }
        else {
            throw new QuartetRuntimeException("Cannot resolve path: " + path);
        }
    }
}
