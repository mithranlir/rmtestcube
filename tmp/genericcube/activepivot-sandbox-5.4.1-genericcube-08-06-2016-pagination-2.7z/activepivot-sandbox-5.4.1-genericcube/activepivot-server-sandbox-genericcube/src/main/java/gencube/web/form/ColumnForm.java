package gencube.web.form;

import gencube.build.PreAnalyzeResult;
import gencube.meta.model.MetaDataColumn;

import java.util.ArrayList;
import java.util.List;

public class ColumnForm {

    private List<MetaDataColumn> columns = new ArrayList<>();
    private String skipFirstLines;
    private String dataSeparator;

    public ColumnForm() {
    }

    public void configureDefaultDataSeparatorIfNeeded() {
        if(getDataSeparator()==null) {
            setDataSeparator(";");
        }
    }

    public String getSkipFirstLines() {
        return skipFirstLines;
    }

    public void setSkipFirstLines(String skipFirstLines) {
        this.skipFirstLines = skipFirstLines;
    }

    public String getDataSeparator() {
        return dataSeparator;
    }

    public void setDataSeparator(String dataSeparator) {
        this.dataSeparator = dataSeparator;
    }

    public void setColumns(List<MetaDataColumn> columns) {
        this.columns = columns;
    }

    public List<MetaDataColumn> getColumns() {
        return columns;
    }

    public static ColumnForm createColumnFormForWizard(PreAnalyzeResult result) {
        final ColumnForm columnForm = new ColumnForm();
        if(result!=null) {
            columnForm.setDataSeparator(result.getSeparatorFound());
        }
        columnForm.configureDefaultDataSeparatorIfNeeded();
        columnForm.setSkipFirstLines("0");
        return columnForm;
    }

}
