package gencube.upload;

import gencube.cfg.GenericCubeConst;
import org.springframework.core.env.Environment;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.*;

public class DirectoryBrowser {

    private String directoryPath;

    private static final String META = "meta";

    public DirectoryBrowser(Environment env) {
        this.directoryPath = env.getProperty(GenericCubeConst.CSV_DIRECTORY_PROP) + System.getProperty("file.separator");
    }

    public List<FileDesc> getFiles(final SortOption sortOption, Boolean metaFiles) throws IOException {
        final List<FileDesc> files = new ArrayList<>();
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get(directoryPath), "*.{csv,zip}")) {
            for (Path path : directoryStream) {
                fillFileDesc(metaFiles, files, path);
            }
        }
        if(sortOption!=null) {
            sortFileList(sortOption, files);
        }
        return files;
    }


    private boolean isValid(Path path, Boolean metaFiles) {
        if(metaFiles == null) {
            return true;
        }
        else {
            final String fileName = path.getFileName().toString().toLowerCase();
            if(metaFiles && fileName.contains(META)) {
                return true;
            }
            else if(!metaFiles && !fileName.contains(META)) {
                return true;
            }
        }
        return false;
    }


    private void fillFileDesc(Boolean metaFiles, List<FileDesc> files, Path path) throws IOException {
        if(isValid(path, metaFiles)) {
            final FileDesc fileDesc = createFileDesc(path);
            if (fileDesc != null) {
                files.add(fileDesc);
            }
        }
    }

    public void sortFileList(final SortOption sortOption, List<FileDesc> files) {
        Collections.sort(files, new Comparator<FileDesc>() {
            @Override
            public int compare(FileDesc o1, FileDesc o2) {
                if (SortOption.BY_NAME_ASC.equals(sortOption)) {
                    return o1.getName().compareToIgnoreCase(o2.getName());
                }
                else if (SortOption.BY_NAME_DESC.equals(sortOption)) {
                    return o2.getName().compareToIgnoreCase(o1.getName());
                }
                else if (SortOption.BY_DATE_ASC.equals(sortOption)) {
                    return o1.getModificationDate().compareTo(o2.getModificationDate());
                }
                else {
                    return o2.getModificationDate().compareTo(o1.getModificationDate());
                }
            }
        });
    }

    private final static SimpleDateFormat SDF = new SimpleDateFormat("dd-MM-YYYY HH:mm:ss");

    public FileDesc createFileDesc(Path path) throws IOException {
        final BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class);
        if(attrs.isDirectory()) {
            return null;
        }
        final FileDesc fileDesc = new FileDesc();
        fileDesc.setName(path.getFileName().toString());
        fileDesc.setModificationDate(new Date(attrs.lastModifiedTime().toMillis()));
        fileDesc.setFormattedDate(SDF.format(fileDesc.getModificationDate()));
        fileDesc.setSize(attrs.size());
        fileDesc.setFormattedSize(getFormattedSize(attrs.size()));
        return fileDesc;
    }

    private String getFormattedSize(long sizeInBytes) {
        if(sizeInBytes > 0 && sizeInBytes<=1024) {
            return "1Kb";
        }
        else if(sizeInBytes > 1024 && sizeInBytes<1024*1024) {
            return String.format("%.2f", (sizeInBytes / 1024.0)) + "kb";
        }
        else {
            return String.format("%.2f", (sizeInBytes / (1024*1024.0))) + "Mb";
        }
    }

    private long getSize(long sizeInBytes) {
        if(sizeInBytes > 0 && sizeInBytes<1024) {
            return 1;
        }
        return sizeInBytes / 1024;
    }

    public enum SortOption {
        BY_DATE_ASC,
        BY_DATE_DESC,
        BY_NAME_ASC,
        BY_NAME_DESC
    }

}
