package gencube.web.form;


public class PositionData {

    private boolean first;
    private boolean last;

    public boolean isFirst() {
        return first;
    }

    public void setFirst(boolean first) {
        this.first = first;
    }

    public boolean isLast() {
        return last;
    }

    public void setLast(boolean last) {
        this.last = last;
    }

    public boolean isAlone() {
        return isFirst() && isLast();
    }

}
