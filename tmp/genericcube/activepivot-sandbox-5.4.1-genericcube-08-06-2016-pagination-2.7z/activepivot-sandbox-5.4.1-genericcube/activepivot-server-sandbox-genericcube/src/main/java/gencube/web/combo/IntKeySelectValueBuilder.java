package gencube.web.combo;

import gencube.web.combo.select.AbstractSelectValueBuilder;
import gencube.web.combo.select.ISelectValue;

import java.util.List;

public class IntKeySelectValueBuilder extends AbstractSelectValueBuilder<Integer> {

    public IntKeySelectValueBuilder(List<String> values) {
        super(values);
    }

    @Override
    protected ISelectValue<Integer> createSelectValue(String value) {
        return new IntKeySelectValue(value);
    }

}
