package gencube.web.form;

import gencube.loadinghistory.FileLoading;

import java.util.ArrayList;
import java.util.List;

public class FileLoadingForm {

    private List<FileLoading> fileLoadingList = new ArrayList<>();

    public List<FileLoading> getFileLoadingList() {
        return fileLoadingList;
    }

    public void setFileLoadingList(List<FileLoading> fileLoadingList) {
        this.fileLoadingList = fileLoadingList;
    }


}
