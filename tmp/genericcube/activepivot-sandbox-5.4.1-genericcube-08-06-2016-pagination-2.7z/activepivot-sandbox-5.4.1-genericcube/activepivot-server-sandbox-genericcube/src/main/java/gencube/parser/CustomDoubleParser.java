package gencube.parser;

import com.quartetfs.fwk.format.impl.DoubleParser;
import javolution.text.TypeFormat;

import java.util.Locale;

public class CustomDoubleParser extends CustomNumberParser<Double>  {

    public static final String KEY = "CustomDouble";

    public CustomDoubleParser(String format) {
        super(format, new DoubleParser());
    }

    @Override
    public String description() {
        return "Custom Double Parser";
    }

    @Override
    public Object key() {
        return KEY;
    }

    @Override
    protected Double defaultValue() {
        return new Double(0);
    }

    @Override
    protected Double parseValue(String value) {
        return TypeFormat.parseDouble(value);
    }

    @Override
    protected String normalizeValue(String value) {
        return normalizeValueIfFrenchSep(value);
    }
}
