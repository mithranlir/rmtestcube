package gencube.stream;


import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.impl.FlatContextValuesHolder;
import com.quartetfs.biz.pivot.dto.*;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.security.IContextValueManager;
import com.quartetfs.pivot.live.sandbox.server.paging.impl.PagingService;
import gencube.context.ICurrentPageCV;
import gencube.context.IPageSizeCV;
import gencube.context.impl.CurrentPageCVTranslator;
import gencube.context.impl.PageSizeCVTranslator;
import gencube.context.impl.ResultSizeCV;

import java.util.ArrayList;
import java.util.List;

public class CellSetDTOReducer {

    //private int filteredAxisNum = 1; // Y axis

    private int filteredAxisIndex = 1; // Y axis

    private IContextValueManager contextValueManager;

    public void setContextValueManager(IContextValueManager contextValueManager) {
        this.contextValueManager = contextValueManager;
    }

    public CellSetDTO getLimitedCellSetDTO(CellSetDTO cellSetDTO, IMDXQuery query) {
        final int positionOfFilteredAxis = findPositionOfFilteredAxis(cellSetDTO.getAxes());
        if(positionOfFilteredAxis >= 0) {
            final int sizeOnFilteredAxis = getSizeOnFilteredAxis(cellSetDTO, positionOfFilteredAxis);
            keepResultSizeInContextValue(sizeOnFilteredAxis);
            return limitCellSetDTO(cellSetDTO, query, positionOfFilteredAxis);
        }
        return cellSetDTO;
    }

    private void keepResultSizeInContextValue(int sizeOnFilteredAxis) {
        final ResultSizeCV cv = new ResultSizeCV(Long.valueOf(sizeOnFilteredAxis));
        contextValueManager.setContextValue(PagingService.RESULT_SIZE_KEY, cv);
    }

    private int findPositionOfFilteredAxis(List<AxisDTO> axes) {
        for(int i=0; i<axes.size(); i++) {
            if(filteredAxisIndex == axes.get(i).getIndex()) {
                return i;
            }
        }
        return -1;
    }

    private int getSizeOnFilteredAxis(CellSetDTO cellSetDTO, int positionOfFilteredAxis) {
        return cellSetDTO.getAxes().get(positionOfFilteredAxis).getPositions().size();
    }

    private Integer getNbLimitedLines(IMDXQuery query) {

        final String pageSizeStr = getValueOfFlatContextValue(query, PageSizeCVTranslator.KEY);
        if(pageSizeStr!=null && !pageSizeStr.isEmpty()) {
            return Integer.parseInt(pageSizeStr);
        }

        final IPageSizeCV pageSizeCV = contextValueManager.getContextValue(PageSizeCVTranslator.KEY, IPageSizeCV.class);
        if(hasNoNbLimitedLines(pageSizeCV)) {
            return -1;
        }

        return Integer.parseInt(pageSizeCV.getPageSize());
    }

    private boolean hasNoNbLimitedLines(IPageSizeCV pageSizeCV) {
        return pageSizeCV==null || pageSizeCV.getPageSize()==null || pageSizeCV.getPageSize().isEmpty();
    }

    private String getValueOfFlatContextValue(IMDXQuery query, String contextValueName) {
        if(query.getContextValues()!=null) {
            for(IContextValue contextValue : query.getContextValues()) {
                if(contextValue instanceof FlatContextValuesHolder) {
                    final FlatContextValuesHolder holder = (FlatContextValuesHolder) contextValue;
                    if(holder.getMapping()!=null) {
                        return holder.getMapping().get(contextValueName);
                    }
                }
            }
        }
        return null;
    }

    private Integer getCurrentPage(IMDXQuery query) {

        final String currentPageStr = getValueOfFlatContextValue(query, CurrentPageCVTranslator.KEY);
        if(currentPageStr!=null && !currentPageStr.isEmpty()) {
            return Integer.parseInt(currentPageStr);
        }

        final ICurrentPageCV currentPageCV = contextValueManager.getContextValue(CurrentPageCVTranslator.KEY, ICurrentPageCV.class);
        if(!hasNoCurrentPage(currentPageCV)) {
            Integer.parseInt(currentPageCV.getCurrentPage());
        }

        return -1;
    }

    private boolean hasNoCurrentPage(ICurrentPageCV currentPageCV) {
        return currentPageCV==null || currentPageCV.getCurrentPage()==null || currentPageCV.getCurrentPage().isEmpty();
    }

    private CellSetDTO limitCellSetDTO(CellSetDTO cellSetDTO, IMDXQuery query, int positionOfFilteredAxis) {

        final int nbLimitedLines = getNbLimitedLines(query);
        final int currentPage = getCurrentPage(query);
        if(!canLimitLines(nbLimitedLines, currentPage)) {
            return cellSetDTO;
        }

        final List<CellDTO> limitedCells = createLimitedCells(
                nbLimitedLines, currentPage, cellSetDTO.getCells(), cellSetDTO.getAxes(), positionOfFilteredAxis);

        final List<AxisDTO> limitedAxes = createLimitedAxes(
                nbLimitedLines, currentPage, cellSetDTO.getAxes(), positionOfFilteredAxis);

        return createCellSetDTO(cellSetDTO, limitedCells, limitedAxes);
    }

    private boolean canLimitLines(int nbLimitedLines, int currentPage) {
        return nbLimitedLines>0 && currentPage>=0;
    }

    private int[] createPositionCounts(List<AxisDTO> axes) {
        final int[] positionCounts = new int[axes.size()];
        configurePositionCounts(axes, axes.size(), positionCounts);
        return positionCounts;
    }

    private List<CellDTO> createLimitedCells(int nbLimitedLines, int currentPage, List<CellDTO> cells, List<AxisDTO> axes, int positionOfFilteredAxis) {
        final int[] positionCounts = createPositionCounts(axes);
        final int[] axisCoordinates = new int[axes.size()];
        final List<CellDTO> limitedCells = new ArrayList<>();
        for(CellDTO cellDTO : cells) {
            // Lookup positions on axes
            configureAxisCoordinates(axisCoordinates, positionCounts, cellDTO);
            if(isInPage(axisCoordinates, currentPage,nbLimitedLines, positionOfFilteredAxis)) {
                changeOrdinal(nbLimitedLines, currentPage, cellDTO, positionCounts);
                limitedCells.add(cellDTO);
            }
        }
        return limitedCells;
    }


    private boolean isInPage(int[] axisCoordinates, int currentPage, int nbLimitedLines, int positionOfFilteredAxis) {
        final int numLine = axisCoordinates[positionOfFilteredAxis];
        return isInPage(numLine, currentPage, nbLimitedLines);
    }

    private void changeOrdinal(int nbLimitedLines, int currentPage, CellDTO cellDTO, int[] positionCounts) {

        int offset = (currentPage * nbLimitedLines);
        if(positionCounts.length>1) {
            final int positionCountOnNoneFilteredAxis = positionCounts[0];
            offset = offset * positionCountOnNoneFilteredAxis;
        }
        final int newOrdinal = cellDTO.getOrdinal()- offset;
        cellDTO.setOrdinal(newOrdinal);
    }

    private List<AxisDTO> createLimitedAxes(int nbLimitedLines, int currentPage, List<AxisDTO> axes, int positionOfFilteredAxis) {
        final List<AxisDTO> limitedAxes = new ArrayList<>();
        for(int i=0; i<axes.size(); i++) {
            if(i==positionOfFilteredAxis) {
                final AxisDTO axisDTO = axes.get(i);
                final AxisDTO limitedAxisDTO = createLimitedAxisDTO(axes, nbLimitedLines, currentPage, i, axisDTO);
                limitedAxes.add(limitedAxisDTO);
            }
            else {
                limitedAxes.add(axes.get(i));
            }
        }
        return limitedAxes;
    }

    private CellSetDTO createCellSetDTO(CellSetDTO cellSetDTO, List<CellDTO> limitedCells, List<AxisDTO> limitedAxes) {
        final List<String> cellProperties = cellSetDTO.getCellProperties();
        final List<MemberDTO> defaultMembers = cellSetDTO.getDefaultMembers();
        final AxisDTO slicerAxis = cellSetDTO.getSlicerAxis();
        return new CellSetDTO(limitedAxes, slicerAxis, defaultMembers, limitedCells, cellProperties);
    }

    private boolean isInPage(int numLine, int currentPage, int nbLimitedLines) {
        final int startRange = getStartRange(currentPage, nbLimitedLines);
        final int endRange = getEndRange(currentPage, nbLimitedLines);
        return numLine >= startRange && numLine < endRange;
    }

    private int getStartRange(int currentPage, int nbLimitedLines) {
        return currentPage * nbLimitedLines;
    }

    private int getEndRange(int currentPage, int nbLimitedLines) {
        return (currentPage+1) * nbLimitedLines;
    }

    private AxisDTO createLimitedAxisDTO(List<AxisDTO> axes, int nbLimitedLines, int currentPage, int axisPosition, AxisDTO axisDTO) {
        final AxisDTO limitedAxisDTO = new AxisDTO();
        limitedAxisDTO.setIndex(axisDTO.getIndex());
        limitedAxisDTO.setHierarchies(axisDTO.getHierarchies());
        limitedAxisDTO.setMemberProperties(axisDTO.getMemberProperties());
        configurePositions(axes, nbLimitedLines, currentPage, axisPosition, limitedAxisDTO);
        return limitedAxisDTO;
    }

    private void configurePositions(List<AxisDTO> axes, int nbLimitedLines, int currentPage, int axisPosition, AxisDTO limitedAxisDTO) {
        limitedAxisDTO.setPositions(new ArrayList<AxisPositionDTO>());
        final int startPos = currentPage * nbLimitedLines;
        final int endPos = (currentPage + 1) * nbLimitedLines;
        for(int j=startPos; j<endPos && j<axes.get(axisPosition).getPositions().size(); j++) {
            final AxisPositionDTO dto = axes.get(axisPosition).getPositions().get(j);
            limitedAxisDTO.getPositions().add(dto);
        }
    }

    private void configurePositionCounts(List<AxisDTO> axes, int axisSize, int[] positionCounts) {
        for(int a = 0; a < axisSize; a++) {
            positionCounts[a] = axes.get(a).getPositions().size();
        }
    }

    private void configureAxisCoordinates(int[] axisCoordinates, int[] positionCounts, CellDTO cellDTO) {
        int coeff = 1;
        for(int a = 0; a < axisCoordinates.length; a++) {
            final int positionCount = positionCounts[a];
            axisCoordinates[a] = (cellDTO.getOrdinal() / coeff) % positionCount;
            coeff *= positionCount;
        }
    }
}
