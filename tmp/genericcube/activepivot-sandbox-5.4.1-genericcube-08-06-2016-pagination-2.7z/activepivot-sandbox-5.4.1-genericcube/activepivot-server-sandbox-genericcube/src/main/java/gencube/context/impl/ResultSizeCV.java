package gencube.context.impl;

import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.impl.AContextValue;
import gencube.context.IPageSizeCV;
import gencube.context.IResultSizeCV;

public class ResultSizeCV extends AContextValue implements IResultSizeCV {

	private static final long serialVersionUID = 1343785495660285541L;

	protected Long resultSize;

	/** constructor */
	protected ResultSizeCV() {}

	public ResultSizeCV(Long resultSize) {
		this.resultSize = resultSize;
	}

	@Override
	public Long getResultSize() {
		return resultSize;
	}

	public void setResultSize(Long resultSize) {
		this.resultSize = resultSize;
	}

	@Override
	public String toString() {
		return "resultSize: " + resultSize;
	}

	@Override
	public Class<? extends IContextValue> getContextInterface() {
		return IResultSizeCV.class;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		final ResultSizeCV that = (ResultSizeCV) o;
		return !(resultSize != null ? !resultSize.equals(that.resultSize) : that.resultSize != null);
	}

	@Override
	public int hashCode() {
		return resultSize != null ? resultSize.hashCode() : 0;
	}
}
