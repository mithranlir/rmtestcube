package gencube.parser;

import com.quartetfs.fwk.format.impl.LongParser;
import javolution.text.TypeFormat;

import java.util.Locale;

public class CustomLongParser extends CustomNumberParser<Long>  {

    public static final String KEY = "CustomLong";

    public CustomLongParser(String format) {
        super(format, new LongParser());
    }

    @Override
    public String description() {
        return "Custom Long Parser";
    }

    @Override
    public Object key() {
        return KEY;
    }

    @Override
    protected Long defaultValue() {
        return new Long(0);
    }

    @Override
    protected Long parseValue(String value) {
        return TypeFormat.parseLong(value);
    }
}
