package gencube.meta.model;

import java.util.ArrayList;
import java.util.List;

public class MetaData {

    private int linesToSkip = 0;
    private String dataSeparator = ";";
    private List<MetaDataColumn> columns = new ArrayList<>();
    private List<HierarchyData> hierarchies = new ArrayList<>();

    public MetaData() {
    }

    public int getLinesToSkip() {
        return linesToSkip;
    }

    public void setLinesToSkip(int linesToSkip) {
        this.linesToSkip = linesToSkip;
    }

    public String getDataSeparator() {
        return dataSeparator;
    }

    public void setDataSeparator(String dataSeparator) {
        this.dataSeparator = dataSeparator;
    }

    public List<MetaDataColumn> getColumns() {
        return columns;
    }

    public void addColumn(MetaDataColumn column) {
        columns.add(column);
    }

    public List<HierarchyData> getHierarchies() {
        return hierarchies;
    }

    public void addHierarchy(HierarchyData column) {
        hierarchies.add(column);
    }

}
