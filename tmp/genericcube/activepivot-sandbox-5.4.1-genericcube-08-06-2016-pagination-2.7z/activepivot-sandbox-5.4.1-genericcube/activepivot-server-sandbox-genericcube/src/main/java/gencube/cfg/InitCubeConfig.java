package gencube.cfg;

import com.quartetfs.biz.pivot.server.impl.XMLAEnabler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

public class InitCubeConfig {

    @Autowired
    private GenericCubeConfig genericCubeConfig;

    @Bean
    public XMLAEnabler XMLAEnabler() {
        XMLAEnabler xmla = new XMLAEnabler();
        xmla.setActivePivotManager(genericCubeConfig.activePivotManager());
        xmla.setContextValueManager(genericCubeConfig.contextValueManager());
        xmla.setLogging(false);
        xmla.setMonitoring(true);
        return xmla;
    }

}
