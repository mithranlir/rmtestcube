package gencube.web.upload;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UploadedFiles {

    private List<String> files = new ArrayList<>();
    private Date lastUploadDate;

    public UploadedFiles() {
    }

    public UploadedFiles(List<String> files, Date lastUploadDate) {
        this.files = files;
        this.lastUploadDate = lastUploadDate;
    }

    public List<String> getFiles() {
        return files;
    }

    public void setFiles(List<String> files) {
        this.files = files;
    }

    public Date getLastUploadDate() {
        return lastUploadDate;
    }

    public void setLastUploadDate(Date lastUploadDate) {
        this.lastUploadDate = lastUploadDate;
    }
}
