package gencube.web;

import com.qfs.logging.MessagesSandbox;
import gencube.build.CubeReloader;
import gencube.download.DownloadHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.logging.Logger;

@Controller
@RequestMapping({ "/download" })
public class DownloadController {

    protected static Logger LOGGER = MessagesSandbox.getLogger(DownloadController.class);

    @Autowired
    private CubeReloader cubeReloader;

    @RequestMapping(value="/downloadMetaFile", method= RequestMethod.GET, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    @ResponseBody
    public FileSystemResource downloadMetaFile(String metaFile, HttpServletResponse response) {
        if(DownloadHelper.isMetaFileNameValid(metaFile)) {
            return DownloadHelper.createResourceForMetaFile(metaFile, response, cubeReloader);
        }
        return null;
    }

    @RequestMapping(value="/downloadErrorLogFile", method=RequestMethod.GET, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    @ResponseBody
    public FileSystemResource downloadErrorLogFile(String logFile, HttpServletResponse response) {
        if(DownloadHelper.isLogFileValid(logFile)) {
            return DownloadHelper.createResourceForErrorLog(logFile, response, cubeReloader);
        }
        return null;
    }
}
