package gencube.web;

import com.qfs.logging.MessagesSandbox;
import gencube.loadinghistory.FileLoadingHistoryService;
import gencube.web.form.FileLoadingForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.logging.Logger;

@Controller
@RequestMapping({ "/history" })
public class LoadingHistoryController {

    protected static Logger LOGGER = MessagesSandbox.getLogger(LoadingHistoryController.class);

    public static final String LOADING_HISTORY = "loadingHistory";

    @Autowired
    private FileLoadingHistoryService fileLoadingHistoryService;

    @RequestMapping(value = {"/loadingHistory" }, method = RequestMethod.GET)
    public String displayLoadingHistory( ModelMap model) {
        final FileLoadingForm fileLoadingForm = new FileLoadingForm();
        fileLoadingForm.setFileLoadingList(fileLoadingHistoryService.getFileLoadingHistory());
        model.addAttribute("fileLoadingForm", fileLoadingForm);
        return LOADING_HISTORY;
    }

}