package gencube.parser;

import com.quartetfs.fwk.format.impl.IntegerParser;
import com.quartetfs.fwk.format.impl.LongParser;
import javolution.text.TypeFormat;

import java.util.Locale;

public class CustomIntegerParser extends CustomNumberParser<Integer>  {

    public static final String KEY = "CustomInteger";

    public CustomIntegerParser(String format) {
        super(format, new IntegerParser());
    }

    @Override
    public String description() {
        return "Custom Integer Parser";
    }

    @Override
    public Object key() {
        return KEY;
    }

    @Override
    protected Integer defaultValue() {
        return new Integer(0);
    }

    @Override
    protected Integer parseValue(String value) {
        return TypeFormat.parseInt(value);
    }
}
