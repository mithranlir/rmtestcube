package gencube.web.combo.select;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractSelectValueBuilder<T> {

    private List<String> values = new ArrayList<>();
    private Map<String, List<T>> indexMap = new HashMap<>();

    public AbstractSelectValueBuilder(List<String> values) {
        this.values = values;
    }

    public void add(T fieldPos, String value) {
        if(value!=null) {
            if (indexMap.get(value) == null) {
                indexMap.put(value, new ArrayList<T>());
            }
            indexMap.get(value).add(fieldPos);
        }
    }

    public List<ISelectValue<T>> build() {
        final List<ISelectValue<T>> list = new ArrayList<>();
        for(String value : values) {
            final ISelectValue<T> selectValue = createSelectValue(value);
            final List<T> posList = indexMap.get(value);
            if(posList!=null) {
                for(T pos : posList) {
                    selectValue.getSelectedMap().put(pos, Boolean.TRUE);
                }
            }
            list.add(selectValue);
        }
        return list;
    }

    protected abstract ISelectValue<T> createSelectValue(String value);

}
