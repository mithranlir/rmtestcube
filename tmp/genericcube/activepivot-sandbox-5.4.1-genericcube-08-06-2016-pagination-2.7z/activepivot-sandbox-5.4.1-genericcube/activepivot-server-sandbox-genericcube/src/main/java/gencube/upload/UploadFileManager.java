package gencube.upload;

import com.qfs.logging.MessagesSandbox;
import gencube.build.CubeReloader;
import gencube.web.select.ConfigFiles;
import gencube.web.upload.FileBucket;
import gencube.web.upload.MultiFileBucket;
import org.springframework.util.FileCopyUtils;

import javax.validation.Valid;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class UploadFileManager {

    protected static Logger LOGGER = MessagesSandbox.getLogger(UploadFileManager.class);

    public static final String ZIP_EXT = ".zip";
    public static final String CSV_EXT = ".csv";

    private DirectoryBrowser directoryBrowser;
    private CubeReloader cubeReloader;

    public UploadFileManager(DirectoryBrowser directoryBrowser, CubeReloader cubeReloader) {
        this.directoryBrowser = directoryBrowser;
        this.cubeReloader = cubeReloader;
    }

    public List<FileDesc> getAvailableMetaFiles() {
        return getAvailableConfigFiles(true);
    }

    public List<FileDesc> getAvailableDataFiles() {
        return getAvailableConfigFiles(false);
    }

    private List<FileDesc> getAvailableConfigFiles(Boolean metaFiles) {
        List<FileDesc> availableConfigFiles = null;
        try {
            availableConfigFiles = directoryBrowser.getFiles(DirectoryBrowser.SortOption.BY_DATE_DESC, metaFiles);
        }
        catch (IOException e) {
            LOGGER.severe("error while browsing dir ;");
            e.printStackTrace();
        }
        return availableConfigFiles;
    }

    public boolean areConfigFilesValid(ConfigFiles configFiles) {
        return configFiles!=null && configFiles.isValid();
    }

    public void configureWithSelectedFiles(ConfigFiles configFiles, boolean forceUnzip) throws IOException {

        final String csvMetaFileName = chooseFileAsTargetFile(configFiles.getMetaFile(), forceUnzip);
        cubeReloader.setCurrentMetaFileName(csvMetaFileName);

        final String csvDataFileName = chooseFileAsTargetFile(configFiles.getDataFile(), forceUnzip);
        cubeReloader.setCurrentDataFileName(csvDataFileName);
    }

    public List<String> saveFileBuckets(@Valid MultiFileBucket multiFileBucket) throws IOException {
        final List<String> fileNames = new ArrayList<>();

        final FileBucket metaFileBucket = multiFileBucket.getFiles().get(0);
        fileNames.add(metaFileBucket.getFile().getOriginalFilename());
        final String csvMetaFileName = saveFileBucket(metaFileBucket);
        cubeReloader.setCurrentMetaFileName(csvMetaFileName);

        final FileBucket dataFileBucket = multiFileBucket.getFiles().get(1);
        fileNames.add(dataFileBucket.getFile().getOriginalFilename());
        final String csvDataFileName = saveFileBucket(dataFileBucket);
        cubeReloader.setCurrentDataFileName(csvDataFileName);

        return fileNames;
    }

    private String saveFileBucket(FileBucket fileBucket) throws IOException {
        final String uploadFileName = fileBucket.getFile().getOriginalFilename();
        String csvFileName = uploadFileName;
        if(uploadFileName.endsWith(ZIP_EXT)) {
            final Path tmpZipPath = buildFilePath(uploadFileName);
            copyFileBucketToFile(fileBucket, tmpZipPath.toString());
            csvFileName = unzipEntryFromZipFile(tmpZipPath.toString(), cubeReloader.getFileDir());
        }
        else if(uploadFileName.endsWith(CSV_EXT)) {
            final String targetFilePath = buildFilePath(uploadFileName).toString();
            copyFileBucketToFile(fileBucket, targetFilePath);
        }
        return csvFileName;
    }

    private String chooseFileAsTargetFile(String chosenFile, boolean forceUnzip) {
        if(chosenFile.endsWith(ZIP_EXT)) {
            final Path selectedFilePath = buildFilePath(chosenFile);
            return unzipEntryFromZipFileIfNeeded(selectedFilePath.toFile().getAbsolutePath(), forceUnzip);
        }
        return chosenFile;
    }

    private Path buildFilePath(String fileName) {
        return Paths.get(cubeReloader.getFileDir(), fileName);
    }

    private String unzipEntryFromZipFileIfNeeded(String selectedFilePath, boolean forceUnzip) {
        final String entryName = getEntryNameInZipFile(selectedFilePath);
        final Path targetPath = buildFilePath(entryName);
        if(forceUnzip || !Files.exists(targetPath)) {
            unzipEntryFromZipFile(selectedFilePath, targetPath.toString());
        }
        return entryName;
    }

    private String getEntryNameInZipFile(String zipFilePath){
        String entryName = null;
        try{
            final ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFilePath));
            final ZipEntry ze = zis.getNextEntry();
            if(ze!=null){
                if(!ze.getName().endsWith(CSV_EXT)) {
                    LOGGER.severe("should have a csv entry...");
                }
                else {
                    entryName = ze.getName();
                }
            }
            zis.closeEntry();
            zis.close();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        return entryName;
    }

    private String unzipEntryFromZipFile(String zipFilePath, String fileDirPath){
        final byte[] buffer = new byte[1024];
        String entryName = null;
        try{
            final ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFilePath));
            final ZipEntry ze = zis.getNextEntry();
            if(ze!=null){
                if(ze.getName().endsWith(CSV_EXT)) {
                    entryName = ze.getName();
                    Path targetFilePath = Paths.get(fileDirPath, entryName);
                    writeNewFile(buffer, zis, targetFilePath.toString());
                    LOGGER.severe("write entry " + entryName +" to target " + targetFilePath);
                }
                if(zis.getNextEntry()!=null) {
                    // ERROR
                    LOGGER.severe("should not have other entries...");
                }
            }
            zis.closeEntry();
            zis.close();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        return entryName;
    }

    public void writeNewFile(byte[] buffer, ZipInputStream zis, String targetFilePath) throws IOException {
        final File newFile = new File(targetFilePath);
        LOGGER.info("file unzip : "+ newFile.getAbsoluteFile());
        final FileOutputStream fos = new FileOutputStream(newFile);
        int len;
        while ((len = zis.read(buffer)) > 0) {
            fos.write(buffer, 0, len);
        }
        fos.close();
    }

    private void copyFileBucketToFile(FileBucket fileBucket, String targetPath) throws IOException {
        FileCopyUtils.copy(fileBucket.getFile().getBytes(), new File(targetPath));
    }


}
