package gencube.web.form;

public class FileLoadingProgress {

    private long totalSize;
    private long currentReadSize;
    private boolean stopProgress;

    public boolean isStopProgress() {
        return stopProgress;
    }

    public void setStopProgress(boolean stopProgress) {
        this.stopProgress = stopProgress;
    }

    public long getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(long totalSize) {
        this.totalSize = totalSize;
    }

    public long getCurrentReadSize() {
        return currentReadSize;
    }

    public void setCurrentReadSize(long currentReadSize) {
        this.currentReadSize = currentReadSize;
    }

}
