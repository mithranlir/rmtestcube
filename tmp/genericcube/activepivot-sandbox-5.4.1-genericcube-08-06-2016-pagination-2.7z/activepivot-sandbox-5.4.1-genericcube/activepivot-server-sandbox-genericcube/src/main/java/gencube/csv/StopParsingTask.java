package gencube.csv;

import com.qfs.logging.MessagesSandbox;

import java.util.logging.Logger;

public class StopParsingTask implements StopParsingListener {

    protected static Logger LOGGER = MessagesSandbox.getLogger(StopParsingTask.class);

    private boolean maxParsingErrorReached = false;
    private boolean parsingStopRequested = false;

    @Override
    public void onMaxParsingErrorReached(String fileName) {
        LOGGER.info("parsing stop because max parsing error reached");
        maxParsingErrorReached = true;
    }

    @Override
    public boolean isStopParsingRequested() {
        return parsingStopRequested;
    }

    public void stopParsing() {
        this.parsingStopRequested = true;
    }

    public boolean isMaxParsingErrorReached() {
        return maxParsingErrorReached;
    }
}
