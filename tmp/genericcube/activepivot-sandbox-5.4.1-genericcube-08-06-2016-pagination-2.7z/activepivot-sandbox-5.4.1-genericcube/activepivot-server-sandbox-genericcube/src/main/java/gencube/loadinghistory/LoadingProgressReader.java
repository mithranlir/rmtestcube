package gencube.loadinghistory;

import gencube.csv.CustomCSVSource;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class LoadingProgressReader {

    public static final int PERIOD_IN_SECONDS = 5;

    private FileLoading fileLoading;
    private CustomCSVSource csvSource;

    private final ScheduledExecutorService service = Executors.newScheduledThreadPool(1);

    public LoadingProgressReader(final FileLoading fileLoading, CustomCSVSource csvSource) {
        this.fileLoading = fileLoading;
        this.csvSource = csvSource;
        scheduleProgressCheck();
    }

    public void stop() {
        service.shutdownNow();
    }

    private void scheduleProgressCheck() {
        final Runnable command = createCommandToGetNewProgress();
        service.scheduleAtFixedRate(command, 0, PERIOD_IN_SECONDS, TimeUnit.SECONDS);
    }

    private Runnable createCommandToGetNewProgress() {
        return new Runnable() {
            @Override
            public void run() {
                updateNewProgress();
            }
        };
    }

    private void updateNewProgress() {
        final long currentReadSize = csvSource.getCurrentReadSize();
        fileLoading.setCurrentReadSize(currentReadSize);
    }

}
