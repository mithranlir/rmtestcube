package com.qfs.jwt.impl;

import com.qfs.activation.impl.Platform;
import com.qfs.lic.impl.QuartetFSLicense;
import com.qfs.logging.MessagesQfsWeb;
import com.quartetfs.biz.pivot.impl.Util;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.Assert;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JwtFilter extends GenericFilterBean {
    private static final Logger LOGGER = MessagesQfsWeb.getLogger(com.qfs.jwt.impl.JwtFilter.class);
    public static final String AUTHORIZATION_METHOD_PREFIX = "Jwt";
    private static volatile QuartetFSLicense LICENSE;
    protected AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = new WebAuthenticationDetailsSource();
    protected AuthenticationEntryPoint authenticationEntryPoint = new AuthenticationEntryPoint() {
        public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
            response.sendError(401, "Invalid token: " + authException.getMessage());
        }
    };
    protected final AuthenticationManager authenticationManager;

    public JwtFilter(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
        Assert.notNull(authenticationManager, "An AuthenticationManager is required");
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest)request;
        HttpServletResponse res = (HttpServletResponse)response;

        if(req.getHeader("X-ActivePivot-Live-Version") != null) {
            QuartetFSLicense e = getLicense();
            long token = (new Date()).getTime();
            String msg;
            if(token > e.getEndDate() || token < e.getStartDate()) {
                msg = "Your license has expired: system date (" + new Date(token) + ") is not between start date (" + new Date(e.getStartDate()) + ") and end date (" + new Date(e.getEndDate()) + ").";
                LOGGER.warning(msg);
                res.sendError(403, msg);
                return;
            }

            if(!e.getLiveEnabled() && !"DEV".equals(e.getEnv())) {
                msg = "The license does not enable ActivePivot Live";
                LOGGER.warning(msg);
                res.sendError(402, msg);
                return;
            }
        }

        try {
            String e1 = req.getHeader("Authorization");
            if(e1 == null || !e1.startsWith("Jwt ")) {
                chain.doFilter(request, response);
                return;
            }

            e1 = e1.substring("Jwt".length() + 1);

            AbstractAuthenticationToken token1;
            try {
                token1 = this.createAuthentication(e1);
            } catch (AuthenticationException var10) {
                if(LOGGER.isLoggable(Level.FINEST)) {
                    LOGGER.log(Level.FINEST, "Authentication failed in JWT filter", var10);
                }

                this.authenticationEntryPoint.commence(req, res, var10);
                return;
            }

            token1.setDetails(this.authenticationDetailsSource.buildDetails(req));
            Authentication auth = this.authenticate(token1);
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (AuthenticationException var11) {
            SecurityContextHolder.clearContext();
            if(LOGGER.isLoggable(Level.FINEST)) {
                LOGGER.log(Level.FINEST, "Authentication failed in JWT filter", var11);
            }

            this.authenticationEntryPoint.commence(req, res, var11);
            return;
        }

        chain.doFilter(request, response);
    }

    protected Authentication authenticate(Authentication token) throws AuthenticationException {
        return this.authenticationManager.authenticate(token);
    }

    protected AbstractAuthenticationToken createAuthentication(String token) throws AuthenticationException {
        try {
            return new JwtAuthentication(token);
        } catch (ParseException var3) {
            throw new BadCredentialsException("Invalid token", var3);
        }
    }

    public void setAuthenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
        Assert.notNull(authenticationDetailsSource, "AuthenticationDetailsSource required");
        this.authenticationDetailsSource = authenticationDetailsSource;
    }

    public void setAuthenticationEntryPoint(AuthenticationEntryPoint authenticationEntryPoint) {
        Assert.notNull(this.authenticationDetailsSource, "AuthenticationEntryPoint required");
        this.authenticationEntryPoint = authenticationEntryPoint;
    }

    private static final QuartetFSLicense getLicense() {
        if(LICENSE == null) {
            Class var0 = com.qfs.jwt.impl.JwtFilter.class;
            synchronized(com.qfs.jwt.impl.JwtFilter.class) {
                if(LICENSE == null) {
                   LICENSE = createFakeLicense();
                }
            }
        }

        return LICENSE;
    }

    private static QuartetFSLicense createFakeLicense() {

        final Properties properties = new Properties();

        final Long startDate = (new Date()).getTime() - (24 * 60 * 60 * 1000); // now - 1d;
        properties.put("sDate", startDate.toString());

        final Long endDate = (new Date()).getTime() + (365 * 24 * 60 * 60 * 1000); // now + 1 year;
        properties.put("eDate", endDate.toString());

        String host = "";
        try {
            host = Platform.getLocalHostName();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        properties.put("host", host);

        final int maxNbOfCPU = Util.retrieveNumberOfAllowedCores();
        properties.put("maxNbOfCPU", maxNbOfCPU + "");
        properties.put("live", "YES");
        properties.put("sentinel", "YES");
        properties.put("rs", "YES");

        return new QuartetFSLicense(properties);
    }
}
