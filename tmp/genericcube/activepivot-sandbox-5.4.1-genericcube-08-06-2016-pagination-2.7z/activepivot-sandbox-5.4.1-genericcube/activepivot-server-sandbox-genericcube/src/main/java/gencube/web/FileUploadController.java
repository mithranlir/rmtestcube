package gencube.web;

import com.qfs.logging.MessagesSandbox;
import gencube.build.CubeReloader;
import gencube.build.PreAnalyzeResult;
import gencube.loading.LoadingService;
import gencube.loadinghistory.FileLoading;
import gencube.loadingprogress.LoadingProgressHelper;
import gencube.meta.MetaFileNameHelper;
import gencube.meta.model.MetaData;
import gencube.meta.model.MetaDataColumn;
import gencube.upload.UploadFileManager;
import gencube.validation.FileValidator;
import gencube.validation.ValidationResult;
import gencube.web.action.HierarchyActionProcessor;
import gencube.web.form.*;
import gencube.web.helper.HierarchyActionConfigurator;
import gencube.web.select.ConfigFiles;
import gencube.web.upload.MultiFileBucket;
import gencube.web.upload.UploadedFiles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.metadata.InvalidMetadataException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import static gencube.web.form.ColumnFormSelectHelper.*;
import static gencube.web.form.HierarchyFormSelectHelper.getSelectDefaultHierarchyValues;
import static gencube.web.form.HierarchyFormSelectHelper.getSelectLevelNameValues;

@Controller
@RequestMapping({ "/upload", "/onthefly" })
public class FileUploadController {

    protected static Logger LOGGER = MessagesSandbox.getLogger(FileUploadController.class);

    public static final String ERROR_FOUND_ATTR = "errorFound";
    public static final String HIERARCHY_FORM_ATTR = "hierarchyForm";
    public static final String META_DATA_ATTR = "metaData";
    public static final String META_FILE_NAME_ATTR = "metaFileName";
    public static final String DATA_FILE_NAME_ATTR = "dataFileName";
    public static final String META_COLUMN_FORM_ATTR = "metaColumnForm";
    public static final String VALIDATION_RESULT_ATTR = "validationResult";
    public static final String FILE_NAMES_ATTR = "fileNames";
    public static final String LAST_UPLOAD_ATTR = "lastUpload";
    public static final String MULTI_FILE_BUCKET_ATTR = "multiFileBucket";
    public static final String AVAILABLE_DATA_FILES_ATTR = "availableDataFiles";
    public static final String AVAILABLE_META_FILES_ATTR = "availableMetaFiles";

    public static final String SELECT_LEVEL_NAME_LIST_ATTR = "selectLevelNameList";
    public static final String SELECT_DEFAULT_HIERARCHY_LIST_ATTR = "selectDefaultHierarchyList";
    public static final String SELECT_ALL_MEMBERS_ENABLED_LIST_ATTR = "selectAllMembersEnabledList";
    public static final String SELECT_MEASURE_LIST_ATTR = "selectMeasureList";
    public static final String SELECT_TYPE_LIST_ATTR = "selectTypeList";
    public static final String SELECT_DISPLAY_FORMAT_LIST_ATTR = "selectDisplayFormatList";
    public static final String SELECT_FORMAT_LIST_ATTR = "selectFormatList";
    public static final String SELECTED_META_FILE_ATTR = "selectedMetaFile";
    public static final String SELECTED_DATA_FILE_ATTR = "selectedDataFile";

    public static final String CHOOSE_SEPARATOR = "chooseSeparator";
    public static final String META_COLUMN = "metaColumn";
    public static final String META_HIERARCHY = "metaHierarchy";
    public static final String SUCCESS = "success";
    public static final String LOADING_SCREEN = "loadingScreen";
    public static final String FILE_UPLOADER = "fileUploader";
    public static final String VALIDATION_ERROR = "validationError";

    @Autowired
    private CubeReloader cubeReloader;

    @Autowired
    private LoadingService loadingService;

    @Autowired
    private UploadFileManager uploadFileManager;

    @Autowired
    private FileValidator fileValidator;

    @Autowired
    private HierarchyActionProcessor hierarchyActionProcessor;

    private List<String> lastUpload = null;
    private Date lastUploadDate = null;

    @ModelAttribute("configFiles")
    public ConfigFiles prepareConfigFiles() {
        return new ConfigFiles();
    }

    @RequestMapping(value = { "/", "/dataUpload", "/welcome" }, method = RequestMethod.GET)
    public String displayMainForm(ModelMap model) {
        configureModelForMainPage(model);
        return FILE_UPLOADER;
    }

    @RequestMapping(value = { "/loadingSuccess" }, method = RequestMethod.GET)
    public String displaySuccess(ModelMap model) {
        return SUCCESS;
    }

    @RequestMapping(value = "/dataUpload", method = RequestMethod.POST)
    public String multiFileUploadPost(@Valid MultiFileBucket multiFileBucket, BindingResult result, ModelMap model) throws IOException {
        final List<String> savedFileNames = uploadFileManager.saveFileBuckets(multiFileBucket);
        model.addAttribute(FILE_NAMES_ATTR, savedFileNames);
        keepLastUploadInfo(savedFileNames);
        configurePreselectedFiles(model, savedFileNames);
        return FILE_UPLOADER;
    }

    @RequestMapping(value = "/configFileSelect", method = RequestMethod.POST)
    public String configFileSelectPost(ConfigFiles configFiles, ModelMap model) throws IOException {

        if(!uploadFileManager.areConfigFilesValid(configFiles)) {
            LOGGER.severe("Error in configFiles : " + configFiles);
            configureModelForMainPage(model);
            model.addAttribute(MULTI_FILE_BUCKET_ATTR, null);
            return FILE_UPLOADER;
        }

        if(!loadingService.isCurrentFileLoadingFinished()) {
            final ValidationResult validationResult = new ValidationResult();
            validationResult.setCurrentLoadingNotFinished(true);
            model.addAttribute(VALIDATION_RESULT_ATTR, validationResult);
            return VALIDATION_ERROR;
        }

        try {
            final ValidationResult validationResult = fileValidator.validateDataFileWithMetaFile(configFiles);
            if(validationResult.hasErrors()) {
                model.addAttribute(VALIDATION_RESULT_ATTR, validationResult);
                return VALIDATION_ERROR;
            }
        }
        catch(InvalidMetadataException e) {
            final ValidationResult validationResult = new ValidationResult();
            validationResult.setInvalidMetaDataFile(true);
            model.addAttribute(VALIDATION_RESULT_ATTR, validationResult);
            return VALIDATION_ERROR;
        }

        uploadFileManager.configureWithSelectedFiles(configFiles, false);
        try {
            loadingService.startAsyncCsvLoading();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return LOADING_SCREEN;
    }

    @RequestMapping(value = {"/refreshLoadingProgress" }, method = RequestMethod.GET, produces="application/json")
    public @ResponseBody FileLoadingProgress refreshLoadingProgress(ModelMap model) {
        final FileLoading fileLoading = cubeReloader.getCurrentFileLoading();
        final FileLoadingProgress fileLoadingProgress = LoadingProgressHelper.createFileLoadingProgress(fileLoading);
        return fileLoadingProgress;
    }

    @RequestMapping(value = {"/stopCurrentLoadingAjax" }, method = RequestMethod.GET, produces="application/json")
    public @ResponseBody boolean stopCurrentLoadingAjax(ModelMap model) {
        return cubeReloader.stopCurrentLoading();
    }

    @RequestMapping(value = {"/stopCurrentLoading" }, method = RequestMethod.GET)
    public String stopCurrentLoading(ModelMap model) {
        cubeReloader.stopCurrentLoading();
        configureModelForMainPage(model);
        return FILE_UPLOADER;
    }

    @RequestMapping(value = {"/editMetaPost" }, method = RequestMethod.POST)
    public String editMetaPost(ConfigFiles configFiles, ModelMap model, HttpSession httpSession) {

        if(!uploadFileManager.areConfigFilesValid(configFiles)) {
            LOGGER.severe("Error in configFiles : " + configFiles);
            configureModelForMainPage(model);
            model.addAttribute(MULTI_FILE_BUCKET_ATTR, null);
            return FILE_UPLOADER;
        }

        final String dataFileName = configFiles.getDataFile();
        final String metaFileName = configFiles.getMetaFile();
        final String metaFilePath = cubeReloader.getMetaFilePath(metaFileName);
        final MetaData metaData = cubeReloader.getMetaData(metaFilePath);

        final ColumnForm columnForm = ColumnFormHelper.createColumFormWithMetaData(metaData);
        final HierarchyForm hierarchyForm = ColumnFormHelper.createHierarchyFormWithMetaData(metaData, metaFileName);
        configureModelWithComboLists(model, columnForm);
        model.addAttribute(META_COLUMN_FORM_ATTR, columnForm);

        httpSession.setAttribute(HIERARCHY_FORM_ATTR, hierarchyForm);
        httpSession.setAttribute(META_FILE_NAME_ATTR, metaFileName);
        httpSession.setAttribute(DATA_FILE_NAME_ATTR, dataFileName);

        return META_COLUMN;
    }


    @RequestMapping(value = {"/metaWizardPost" }, method = RequestMethod.POST)
    public String metaWizard(ConfigFiles configFiles, ModelMap model, HttpSession httpSession) {
        final String dataFileName = configFiles.getDataFile();
        if(dataFileName==null || dataFileName.isEmpty()) {
            configureModelForMainPage(model);
            return FILE_UPLOADER;
        }

        final String dataFilePath = cubeReloader.getDataFilePath(dataFileName);
        final PreAnalyzeResult result = fileValidator.preAnalyzeDataFile(dataFilePath);
        final ColumnForm columnForm = ColumnForm.createColumnFormForWizard(result);

        model.addAttribute(META_COLUMN_FORM_ATTR, columnForm);
        httpSession.setAttribute(DATA_FILE_NAME_ATTR, dataFileName);
        httpSession.removeAttribute(META_FILE_NAME_ATTR);

        return CHOOSE_SEPARATOR;
    }

    @RequestMapping(value = {"/metaSeparatorPost" }, method = RequestMethod.POST)
    public String metaSeparatorPost(ColumnForm columnForm, ModelMap model, HttpSession httpSession) {

        final String dataFile = (String) httpSession.getAttribute(DATA_FILE_NAME_ATTR);
        final String dataFilePath = cubeReloader.getDataFilePath(dataFile);
        final MetaData metaData = createMetaData(columnForm, dataFilePath);
        columnForm.configureDefaultDataSeparatorIfNeeded();
        columnForm.setColumns(metaData.getColumns());

        configureModelWithComboLists(model, columnForm);
        model.addAttribute(META_COLUMN_FORM_ATTR, columnForm);

        return META_COLUMN;
    }

    private MetaData createMetaData(ColumnForm columnForm, String dataFilePath) {
        final String dataSeparator = columnForm.getDataSeparator();
        final String skipFirstLinesStr = columnForm.getSkipFirstLines();
        final int nbSkipFirstLines = FormHelper.getInteger(skipFirstLinesStr);
        return fileValidator.createMetaData(dataFilePath, nbSkipFirstLines, dataSeparator);
    }

    @RequestMapping(value = {"/metaColumnPost" }, method = RequestMethod.POST)
    public String metaColumnPost(ColumnForm columnForm, ModelMap model, HttpSession httpSession) {

        final boolean fieldNamesValid = ColumnFormHelper.areFieldNamesValid(columnForm);
        if(!fieldNamesValid) {
            configureModelWithComboLists(model, columnForm);
            model.addAttribute(ERROR_FOUND_ATTR, "level names are mandatory");
            model.addAttribute(META_COLUMN_FORM_ATTR, columnForm);
            return META_COLUMN;
        }

        final MetaData metaData = ColumnFormHelper.convertColumnFormToMetaData(columnForm);
        final HierarchyForm hierarchyForm = createHierarchyForm(httpSession);

        final List<String> levelNameValueList = ColumnFormHelper.getLevelNamesNotMeasureList(columnForm.getColumns());
        configureModelWithComboLists(model, levelNameValueList, hierarchyForm);

        model.addAttribute(HIERARCHY_FORM_ATTR, hierarchyForm);

        httpSession.setAttribute(META_DATA_ATTR, metaData);

        return META_HIERARCHY;
    }

    private HierarchyForm createHierarchyForm(HttpSession httpSession) {

        final HierarchyForm hierarchyForm = getOrCreateHierarchyForm(httpSession);

        final String dataFile = (String) httpSession.getAttribute(DATA_FILE_NAME_ATTR);
        final String metaFile = getOrCreateMetaFileName(httpSession, dataFile);
        hierarchyForm.setMetaFileName(metaFile);

        HierarchyActionConfigurator.configureForDisplay(hierarchyForm);
        return hierarchyForm;
    }

    private boolean isEditingMeta(HttpSession httpSession) {
        return httpSession.getAttribute(META_FILE_NAME_ATTR) != null;
    }

    private HierarchyForm getOrCreateHierarchyForm(HttpSession httpSession) {
        final HierarchyForm hierarchyForm;
        if(isEditingMeta(httpSession)) {
            hierarchyForm = (HierarchyForm) httpSession.getAttribute(HIERARCHY_FORM_ATTR);
        }
        else {
            hierarchyForm = new HierarchyForm();
        }
        return hierarchyForm;
    }

    private String getOrCreateMetaFileName(HttpSession httpSession, String dataFile) {
        final String metaDataFile = (String) httpSession.getAttribute(META_FILE_NAME_ATTR);
        if(metaDataFile == null) {
            return MetaFileNameHelper.buildMetaFileName(dataFile);
        }
        return metaDataFile;
    }

    @RequestMapping(value = "/hierarchyPost", method = RequestMethod.POST)
    public String hierarchyPost(HierarchyForm hierarchyForm, ModelMap model, HttpSession httpSession) throws IOException {

        if(mustSaveMetaData(hierarchyForm)) {
            // add hierarchies
            final MetaData metaData = (MetaData) httpSession.getAttribute(META_DATA_ATTR);
            metaData.getHierarchies().addAll(hierarchyForm.getHierarchies());

            final String dataFileName = (String) httpSession.getAttribute(DATA_FILE_NAME_ATTR);
            final String metaDataFileName = HierarchyFormHelper.getMetaDataFileName(hierarchyForm, dataFileName);
            final String metaDataFilePath = cubeReloader.getMetaFilePath(metaDataFileName);
            cubeReloader.saveMetaData(metaDataFilePath, metaData);

            configureModelForMainPage(model);
            configurePreselectedDataFile(model, dataFileName);
            configurePreselectedMetaFile(model, metaDataFileName);

            return FILE_UPLOADER;
        }

        hierarchyActionProcessor.applyAction(hierarchyForm);
        hierarchyForm.initActionNameAndPosition();
        HierarchyActionConfigurator.configureForDisplay(hierarchyForm);

        final MetaData metaData = (MetaData) httpSession.getAttribute(META_DATA_ATTR);
        final List<String> levelNameValueList = ColumnFormHelper.getLevelNamesNotMeasureList(metaData.getColumns());
        configureModelWithComboLists(model, levelNameValueList, hierarchyForm);

        model.addAttribute(HIERARCHY_FORM_ATTR, hierarchyForm);

        return META_HIERARCHY;
    }

    private boolean mustSaveMetaData(HierarchyForm hierarchyForm) {
        return hierarchyForm.getActionName()==null || hierarchyForm.getActionName().isEmpty();
    }


    private void configureModelForMainPage(ModelMap model) {
        model.addAttribute(AVAILABLE_META_FILES_ATTR, uploadFileManager.getAvailableMetaFiles());
        model.addAttribute(AVAILABLE_DATA_FILES_ATTR, uploadFileManager.getAvailableDataFiles());
        model.addAttribute(MULTI_FILE_BUCKET_ATTR, new MultiFileBucket());
        model.addAttribute(LAST_UPLOAD_ATTR, new UploadedFiles(lastUpload, lastUploadDate));
        configurePreselectedMetaFile(model, "");
        configurePreselectedDataFile(model, "");
    }

    private void configurePreselectedFiles(ModelMap model, List<String> savedFileNames) {
        String metaFileUploaded = "";
        String dataFileUploaded = "";
        for(String file : savedFileNames) {
            if(MetaFileNameHelper.isMetaFile(file)) {
                metaFileUploaded = file;
            }
            else {
                dataFileUploaded = file;
            }
        }
        configurePreselectedMetaFile(model, metaFileUploaded);
        configurePreselectedDataFile(model, dataFileUploaded);
    }

    private void configurePreselectedDataFile(ModelMap model, String dataFileUploaded) {
        model.addAttribute(SELECTED_DATA_FILE_ATTR, dataFileUploaded);
    }

    private void configurePreselectedMetaFile(ModelMap model, String metaFileUploaded) {
        model.addAttribute(SELECTED_META_FILE_ATTR, metaFileUploaded);
    }

    private void configureModelWithComboLists(ModelMap model, ColumnForm columnForm) {
        model.addAttribute(SELECT_FORMAT_LIST_ATTR, getSelectFormatList(columnForm, fileValidator));
        model.addAttribute(SELECT_DISPLAY_FORMAT_LIST_ATTR, getSelectDisplayFormatList(columnForm, fileValidator));
        model.addAttribute(SELECT_TYPE_LIST_ATTR, getSelectTypeList(columnForm));
        model.addAttribute(SELECT_MEASURE_LIST_ATTR, getSelectMeasureList(columnForm));
        model.addAttribute(SELECT_ALL_MEMBERS_ENABLED_LIST_ATTR, getSelectAllMembersEnabledList(columnForm));
    }

    private void configureModelWithComboLists(ModelMap model, List<String> fakeLevelNameValueList, HierarchyForm hierarchyForm) {
        model.addAttribute(SELECT_DEFAULT_HIERARCHY_LIST_ATTR, getSelectDefaultHierarchyValues(hierarchyForm));
        model.addAttribute(SELECT_LEVEL_NAME_LIST_ATTR, getSelectLevelNameValues(hierarchyForm, fakeLevelNameValueList));
    }

    private void keepLastUploadInfo(List<String> savedFileNames) {
        lastUpload = savedFileNames;
        lastUploadDate = new Date();
    }

}