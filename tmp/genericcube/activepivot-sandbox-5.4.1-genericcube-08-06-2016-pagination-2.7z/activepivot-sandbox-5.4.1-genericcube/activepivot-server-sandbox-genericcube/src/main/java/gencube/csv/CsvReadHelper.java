package gencube.csv;

import com.qfs.logging.MessagesSandbox;
import com.qfs.msg.csv.IFileInfo;
import com.qfs.msg.csv.ILineReader;
import com.qfs.msg.csv.impl.CSVSource;
import com.qfs.source.impl.CSVMessageChannelFactory;
import com.qfs.source.impl.Fetch;
import com.qfs.store.IDatastore;
import com.qfs.store.log.impl.LogWriteException;
import com.quartetfs.fwk.QuartetRuntimeException;
import gencube.memory.MemMonitorHelper;

import java.util.List;
import java.util.logging.Logger;

public class CsvReadHelper {

    protected static Logger LOGGER = MessagesSandbox.getLogger(CsvReadHelper.class);

    // one commit
    public static void loadCsv2(IDatastore datastore, CSVSource csvSource, CSVMessageChannelFactory channelFactory) throws LogWriteException {

        final List<String> stores = datastore.getSchemaMetadata().getStoreNames();
        final Fetch<IFileInfo, ILineReader> fetch = new Fetch<>(channelFactory, stores);
        final long before = System.nanoTime();
        final Thread memMonitorThread = MemMonitorHelper.createAndStartMemMonitorThread();
        fetch.fetch(csvSource);
        MemMonitorHelper.stopMemMonitor(memMonitorThread);
        final long elapsed = System.nanoTime() - before;
        LOGGER.info("CSV data load completed in " + elapsed / 1_000_000L + "ms.");
    }

    // several commits
    public static void loadCsv(IDatastore datastore, CSVSource csvSource, CSVMessageChannelFactory channelFactory) throws LogWriteException {

        final List<String> stores = datastore.getSchemaMetadata().getStoreNames();

        final List channels = CsvConfigHelper.createAutocommitChannels(channelFactory, stores, false);

        final Thread memMonitorThread = MemMonitorHelper.createAndStartMemMonitorThread();

        final long before = System.nanoTime();
        try {
            csvSource.fetch(channels);
        }
        catch (Exception exception) {
            String msg = "An error occured when fetching data into " + channels;
            if(exception instanceof RuntimeException) {
                throw (RuntimeException)exception;
            }
            throw new QuartetRuntimeException(msg, exception);
        }

        MemMonitorHelper.stopMemMonitor(memMonitorThread);

        final long elapsed = System.nanoTime() - before;
        LOGGER.info("CSV data load completed in " + elapsed / 1_000_000L + "ms.");
    }


}
