package gencube.csv;

import com.qfs.logging.MessagesSandbox;
import com.qfs.source.IStoreMessage;
import com.qfs.source.impl.AutoCommitTuplePublisher;
import com.qfs.source.impl.TuplePublisher;
import com.qfs.store.transaction.DatastoreTransactionException;
import com.quartetfs.fwk.QuartetRuntimeException;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class BulkAutoCommitTuplePublisher<I>  extends AutoCommitTuplePublisher<I> {

    protected static Logger LOGGER = MessagesSandbox.getLogger(BulkAutoCommitTuplePublisher.class);

    private int blockNumber;

    public BulkAutoCommitTuplePublisher(TuplePublisher tuplePublisher, int blockNumber) {
        super(tuplePublisher);
        this.blockNumber = blockNumber;
    }

    @Override
    public void publish(IStoreMessage<I, ?> message, List<Object[]> tuples) {
        this.startTransaction(null);

        if(blockNumber == -1) {
            publishBlock(message, tuples);
        }
        else {
            final List<List<Object[]>> backedSplit = backedListSplit(tuples, blockNumber);
            for (List<Object[]> subList : backedSplit) {
                publishBlock(message, subList);
            }
        }

        this.commitTransaction();
    }

    private void publishBlock(IStoreMessage<I, ?> message, List<Object[]> subList) {
        LOGGER.info("publish block with size " + subList.size());
        try {
            this.tuplePublisher.publish(message, subList);
        } catch (Exception var6) {
            try {
                this.transactionManager.rollbackTransaction();
            } catch (DatastoreTransactionException var5) {
                throw new QuartetRuntimeException("Following a publication error, the automatic transaction rollback has failed.", var5);
            }

            throw new QuartetRuntimeException("There was an error publishing message " + this + " on " + this.store, var6);
        }
    }

    private List<List<Object[]>> backedListSplit(List<Object[]> tuples, int nbElm) {
        final List<List<Object[]>> split = new ArrayList<>();

        int blockSize = tuples.size() / nbElm;

        if(blockSize==0) {
            split.add(tuples);
        }
        else {
            final int modulo = tuples.size() % nbElm;
            if (modulo > 0) {
                blockSize += 1;
            }

            for (int i = 0; i < nbElm; i++) {
                final int fromIndex = i * blockSize;
                final int nextIndex = (i + 1) * blockSize;
                final int toIndex = (nextIndex > tuples.size()) ? tuples.size() : nextIndex;
                final List<Object[]> subList = tuples.subList(fromIndex, toIndex);
                split.add(subList);
            }
        }
        return split;
    }

}
