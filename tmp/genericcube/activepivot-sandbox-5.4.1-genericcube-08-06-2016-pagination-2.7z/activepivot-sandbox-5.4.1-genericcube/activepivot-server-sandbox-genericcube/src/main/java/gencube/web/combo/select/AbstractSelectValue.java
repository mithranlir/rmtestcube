package gencube.web.combo.select;

import java.util.HashMap;
import java.util.Map;

public class AbstractSelectValue<T> implements ISelectValue<T> {

    private String value;
    private Map<T, Boolean> selectedMap;

    public AbstractSelectValue(String value) {
        this.value = value;
        this.selectedMap = new HashMap<>();
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Map<T, Boolean> getSelectedMap() {
        return selectedMap;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setSelectedMap(Map<T, Boolean> selectedMap) {
        this.selectedMap = selectedMap;
    }

}
