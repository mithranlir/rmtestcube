package gencube.web.combo;

import gencube.web.combo.select.AbstractSelectValue;

public class IntKeySelectValue extends AbstractSelectValue<Integer> {
    public IntKeySelectValue(String value) {
        super(value);
    }
}
