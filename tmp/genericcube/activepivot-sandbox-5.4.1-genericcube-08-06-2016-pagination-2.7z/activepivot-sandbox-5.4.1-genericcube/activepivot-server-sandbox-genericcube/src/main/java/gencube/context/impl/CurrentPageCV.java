package gencube.context.impl;

import com.quartetfs.biz.pivot.context.IContextValue;
import com.quartetfs.biz.pivot.context.impl.AContextValue;
import gencube.context.ICurrentPageCV;
import gencube.context.IPageSizeCV;

public class CurrentPageCV extends AContextValue implements ICurrentPageCV {


	private static final long serialVersionUID = -4450359879787755926L;

	protected String currentPage;

	/** constructor */
	protected CurrentPageCV() {}

	public CurrentPageCV(String currentPage) {
		this.currentPage = currentPage;
	}

	@Override
	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	@Override
	public String toString() {
		return "currentPage: " + currentPage;
	}

	@Override
	public Class<? extends IContextValue> getContextInterface() {
		return IPageSizeCV.class;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		final CurrentPageCV that = (CurrentPageCV) o;
		return !(currentPage != null ? !currentPage.equals(that.currentPage) : that.currentPage != null);
	}

	@Override
	public int hashCode() {
		return currentPage != null ? currentPage.hashCode() : 0;
	}
}
