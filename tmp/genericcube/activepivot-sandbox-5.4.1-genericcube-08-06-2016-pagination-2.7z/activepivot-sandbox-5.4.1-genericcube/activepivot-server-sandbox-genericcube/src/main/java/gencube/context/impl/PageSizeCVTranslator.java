package gencube.context.impl;

import com.quartetfs.biz.pivot.context.IContextValueTranslator;
import com.quartetfs.biz.pivot.context.impl.StringContextValueTranslator;
import com.quartetfs.fwk.QuartetPluginValue;
import gencube.context.IPageSizeCV;

@QuartetPluginValue(intf=IContextValueTranslator.class)
public class PageSizeCVTranslator extends StringContextValueTranslator<IPageSizeCV> {

	/** serialVersionUID */
	private static final long serialVersionUID = -1129088664293462391L;

	/** Translator key */
	public static final String KEY = "pageSize";
	
	@Override
	public Class<IPageSizeCV> getContextInterface() { return IPageSizeCV.class; }

	@Override
	public String key() { return KEY; }

	@Override
	protected IPageSizeCV createInstance(String content) { return new PageSizeCV(content); }

	@Override
	protected String getContent(IPageSizeCV instance) { return instance.getPageSize(); }

}
