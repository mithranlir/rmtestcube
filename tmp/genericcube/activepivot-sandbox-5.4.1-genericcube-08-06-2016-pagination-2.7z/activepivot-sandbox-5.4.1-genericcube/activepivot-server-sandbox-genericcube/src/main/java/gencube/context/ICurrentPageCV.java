/*
 * (C) Quartet FS 2010
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package gencube.context;

import com.quartetfs.biz.pivot.context.IContextValue;

public interface ICurrentPageCV extends IContextValue {
	String getCurrentPage();
}
