package gencube.web.select;

public class ConfigFiles {

    private String dataFile;
    private String metaFile;

    public String getDataFile() {
        return dataFile;
    }

    public void setDataFile(String dataFile) {
        this.dataFile = dataFile;
    }

    public String getMetaFile() {
        return metaFile;
    }

    public void setMetaFile(String metaFile) {
        this.metaFile = metaFile;
    }

    public boolean isValid() {
        return dataFile!=null && !dataFile.isEmpty() && metaFile!=null && !metaFile.isEmpty();
    }

    @Override
    public String toString() {
        return "ConfigFiles{" +
                "dataFile='" + dataFile + '\'' +
                ", metaFile='" + metaFile + '\'' +
                '}';
    }
}
