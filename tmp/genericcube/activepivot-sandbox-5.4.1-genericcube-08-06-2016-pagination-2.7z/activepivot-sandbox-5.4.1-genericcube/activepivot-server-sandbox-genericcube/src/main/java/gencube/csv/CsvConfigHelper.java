package gencube.csv;

import com.qfs.msg.IColumnCalculator;
import com.qfs.msg.csv.*;
import com.qfs.msg.csv.impl.CSVColumnParser;
import com.qfs.msg.csv.impl.CSVSource;
import com.qfs.msg.csv.translator.impl.AColumnCalculator;
import com.qfs.source.IStoreMessageChannel;
import com.qfs.source.ITuplePublisher;
import com.qfs.source.impl.AutoCommitTuplePublisher;
import com.qfs.source.impl.CSVMessageChannelFactory;
import com.qfs.source.impl.TuplePublisher;
import com.qfs.store.IDatastore;
import com.quartetfs.fwk.format.IParser;
import gencube.build.GenericCubeBuilder;
import gencube.loadinghistory.FileLoadingHistoryService;
import gencube.memory.MemMonitorHelper;
import gencube.meta.model.MetaData;
import gencube.meta.model.MetaDataColumn;
import gencube.parser.*;
import org.springframework.core.env.Environment;
import rmlib.typevalidator.model.CubeTypes;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

import static org.springframework.util.StringUtils.isEmpty;

public class CsvConfigHelper {

    public static final char CSV_SEPARATOR = '|';

    public static List createAutocommitChannels(
            CSVMessageChannelFactory channelFactory, List<String> stores, boolean bulk) {
        final ArrayList channels = new ArrayList();
        final Map<String, String> mapping = getMapping(channelFactory, stores);
        for(Map.Entry<String, String> link : mapping.entrySet()) {
            final String topic = link.getKey();
            final String store = link.getValue();
            final IStoreMessageChannel channel =
                    createAutocommitChannel(channelFactory, channelFactory.getDatastore(), topic, store, bulk);
            channels.add(channel);
        }
        return channels;
    }

    public static IStoreMessageChannel createAutocommitChannel(
            CSVMessageChannelFactory channelFactory,
            IDatastore datastore,
            String topicName,
            String storeName,
            boolean bulk) {

        final ITuplePublisher<IFileInfo> publisher =
                createAutoCommitTuplePublisher(datastore, storeName, bulk);

        return channelFactory.createChannel(topicName, storeName, publisher);
    }

    public static ITuplePublisher<IFileInfo> createAutoCommitTuplePublisher(IDatastore datastore, String storeName, boolean bulk) {
        ITuplePublisher<IFileInfo> publisher;
        if(bulk) {
            final int blockNumber = bulk ? 2 : -1;
            publisher =
                    new BulkAutoCommitTuplePublisher<IFileInfo>(
                            new TuplePublisher<IFileInfo>(datastore, storeName),
                            blockNumber) {
                        @Override
                        protected void startTransaction(IFileInfo identifier) {
                            super.startTransaction(identifier);
                            MemMonitorHelper.logAvailableMemory();
                        }
                    };
        }
        else {
            publisher =
                    new AutoCommitTuplePublisher<IFileInfo>(
                            new TuplePublisher<IFileInfo>(datastore, storeName)) {
                        @Override
                        protected void startTransaction(IFileInfo identifier) {
                            super.startTransaction(identifier);
                            MemMonitorHelper.logAvailableMemory();
                        }
                    };
        }
        return publisher;
    }

    public static Map getMapping(CSVMessageChannelFactory channelFactory, List<String> stores) {
        return defaultMapping((Collection)(stores != null?stores:channelFactory.getSchemaMetadata().getStoreNames()));
    }

    public static Map<String, String> defaultMapping(Collection<String> stores) {
        final LinkedHashMap mapping = new LinkedHashMap(stores.size());
        final Iterator i$ = stores.iterator();
        while(i$.hasNext()) {
            final String store = (String)i$.next();
            mapping.put(store, store);
        }
        return mapping;
    }

    public static CustomCSVSource createCsvSource(Environment env,
                                                  StopParsingListener stopParsingListener) {
        final CustomCSVSource csvSource = new CustomCSVSource(stopParsingListener);
        configureCsvSource(env, csvSource);
        return csvSource;
    }

    public static void configureCsvSource(Environment env, CSVSource csvSource) {
        final String parserThreads = env.getProperty("csvSource.parserThreads", "4");
        final String bufferSize = env.getProperty("csvSource.bufferSize", "512");
        final Properties sourceProps = new Properties();
        sourceProps.setProperty(ICSVSourceConfiguration.PARSER_THREAD_PROPERTY, parserThreads);
        sourceProps.setProperty(ICSVSourceConfiguration.BUFFER_SIZE_PROPERTY, bufferSize);
        csvSource.configure(sourceProps);
    }

    public static CSVMessageChannelFactory createCsvMessageChannelFactory(
            IDatastore datastore,
            CSVSource csvSource,
            List<IColumnCalculator<ILineReader>> columnCalculators) {

        final CSVMessageChannelFactory channelFactory =
                new CSVMessageChannelFactory(csvSource, datastore);

        channelFactory.setCalculatedColumns(
                GenericCubeBuilder.DEFAULT_TOPIC,
                GenericCubeBuilder.DEFAULT_STORE,
                columnCalculators
        );
        return channelFactory;
    }


    public static List<IColumnCalculator<ILineReader>> createColumnCalculators(
            List<MetaDataColumn> metaDataColumns,
            FileLoadingHistoryService fileLoadingHistoryService) {

        final List<IColumnCalculator<ILineReader>> columnCalculators = new ArrayList<>();
        columnCalculators.add(createFactIdColumnCalculator());
        columnCalculators.addAll(createColumnCalculatorsBasedOnMetaData(metaDataColumns, fileLoadingHistoryService));
        return columnCalculators;
    }

    public static List<IColumnCalculator<ILineReader>> createColumnCalculatorsBasedOnMetaData(
            List<MetaDataColumn> metaDataColumns,
            FileLoadingHistoryService fileLoadingHistoryService) {

        final List<IColumnCalculator<ILineReader>> csvColumnParsers = new ArrayList<>();
        for(int i=0; i<metaDataColumns.size(); i++) {
            final MetaDataColumn metaDataColumn = metaDataColumns.get(i);
            final CSVColumnParser csvColumnParser = createCustomNumberCSVColumnParser(metaDataColumn, i, fileLoadingHistoryService);
            if(csvColumnParser!=null) {
                csvColumnParsers.add(csvColumnParser);
            }
        }
        return csvColumnParsers;
    }

    private static CSVColumnParser createCustomNumberCSVColumnParser(
            MetaDataColumn metaDataColumn,
            int sourcePosition,
            FileLoadingHistoryService fileLoadingHistoryService) {

        if(!isEmpty(metaDataColumn.getFormat())) {
            IParser<?> parser = null;
            if(CubeTypes.DOUBLE.equals(metaDataColumn.getType())) {
                parser = new CustomDoubleParser(metaDataColumn.getFormat());
            }
            else if(CubeTypes.FLOAT.equals(metaDataColumn.getType())) {
                parser = new CustomFloatParser(metaDataColumn.getFormat());
            }
            else if(CubeTypes.LONG.equals(metaDataColumn.getType())) {
                parser = new CustomLongParser(metaDataColumn.getFormat());
            }
            else if(CubeTypes.INT.equals(metaDataColumn.getType())) {
                parser = new CustomIntegerParser(metaDataColumn.getFormat());
            }
            if(parser!=null) {
                return new CustomCSVColumnParser(
                        metaDataColumn.getLevelName(), parser, sourcePosition, fileLoadingHistoryService);
            }
        }
        return null;
    }


    private static IColumnCalculator<ILineReader> createFactIdColumnCalculator() {
        return new AColumnCalculator<ILineReader>(GenericCubeBuilder.FACT_ID) {
            final AtomicLong keyGenerator = new AtomicLong();
            @Override
            public Object compute(IColumnCalculationContext iColumnCalculationContext) {
                return keyGenerator.incrementAndGet();
            }
        };
    }

    public static ICSVTopic createCsvTopic(MetaData metaData, String dataFilePath, CSVSource csvSource) {

        final List<String> columns = new ArrayList<>();
        for(MetaDataColumn column : metaData.getColumns()) {
            columns.add(column.getLevelName());
        }

        final ICSVParserConfiguration csvParserConfiguration =
                csvSource.createParserConfiguration(columns, metaData.getLinesToSkip());

        final ICSVTopic topic =
                csvSource.createTopic(
                        GenericCubeBuilder.DEFAULT_TOPIC,
                        dataFilePath,
                        csvParserConfiguration);

        topic.getParserConfiguration().setSeparator(CSV_SEPARATOR);

        return topic;
    }

}
