package gencube.context.impl;

import com.quartetfs.biz.pivot.context.IContextValueTranslator;
import com.quartetfs.biz.pivot.context.impl.StringContextValueTranslator;
import com.quartetfs.fwk.QuartetPluginValue;
import gencube.context.ICurrentPageCV;
import gencube.context.IPageSizeCV;

@QuartetPluginValue(intf=IContextValueTranslator.class)
public class CurrentPageCVTranslator extends StringContextValueTranslator<ICurrentPageCV> {


	public static final String KEY = "currentPage";
	private static final long serialVersionUID = 6419912070006025510L;

	@Override
	public Class<ICurrentPageCV> getContextInterface() { return ICurrentPageCV.class; }

	@Override
	public String key() { return KEY; }

	@Override
	protected ICurrentPageCV createInstance(String content) { return new CurrentPageCV(content); }

	@Override
	protected String getContent(ICurrentPageCV instance) { return instance.getCurrentPage(); }

}
