package gencube.webapp;

import com.qfs.sandbox.security.impl.CookieUtil;
import gencube.cfg.GenericCubeConfig;
import gencube.cfg.SecurityConfig;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.DelegatingFilterProxy;
import org.springframework.web.servlet.DispatcherServlet;

import javax.servlet.DispatcherType;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;
import java.util.EnumSet;

import static org.springframework.security.config.BeanIds.SPRING_SECURITY_FILTER_CHAIN;

public class WebAppInitializer implements WebApplicationInitializer {

	public final static Class MAIN_CONFIG_CLASS = GenericCubeConfig.class;

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		configureDispatchServlet(servletContext);
		configureSpringSecurity(servletContext);
	}

	private void configureDispatchServlet(ServletContext servletContext) {

		// Spring Context Bootstrapping + web
		final AnnotationConfigWebApplicationContext rootAppContext = new AnnotationConfigWebApplicationContext();
		rootAppContext.register(MAIN_CONFIG_CLASS);
		servletContext.addListener(new ContextLoaderListener(rootAppContext));
		CookieUtil.configure(servletContext.getSessionCookieConfig(), SecurityConfig.COOKIE_NAME);

		// The main servlet/the central dispatcher
		final DispatcherServlet servlet = new DispatcherServlet(rootAppContext);
		servlet.setDispatchOptionsRequest(true);
		Dynamic dispatcher = servletContext.addServlet("springDispatcherServlet", servlet);
		dispatcher.addMapping("/*");
		dispatcher.setLoadOnStartup(1);
	}


	private void configureSpringSecurity(ServletContext servletContext) {
		// Spring Security Filter
		final FilterRegistration.Dynamic springSecurity =
				servletContext.addFilter(SPRING_SECURITY_FILTER_CHAIN, new DelegatingFilterProxy());
		springSecurity.addMappingForUrlPatterns(
				EnumSet.of(DispatcherType.REQUEST), true, "/*");
		// to make WS authentication work through handshake process.
	}

}
