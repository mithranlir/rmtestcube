package gencube.web.form;

import gencube.meta.model.MetaData;
import gencube.meta.model.MetaDataColumn;

import java.util.ArrayList;
import java.util.List;

public class ColumnFormHelper {

    public static ColumnForm createColumFormWithMetaData(MetaData metaData) {
        final ColumnForm columnForm = new ColumnForm();
        columnForm.setSkipFirstLines(metaData.getLinesToSkip()+"");
        columnForm.setDataSeparator(metaData.getDataSeparator());
        columnForm.setColumns(metaData.getColumns());
        return columnForm;
    }

    public static HierarchyForm createHierarchyFormWithMetaData(MetaData metaData, String metaFileName) {
        final HierarchyForm hierarchyForm = new HierarchyForm();
        hierarchyForm.setHierarchies(metaData.getHierarchies());
        hierarchyForm.setMetaFileName(metaFileName);
        return hierarchyForm;
    }

    public static MetaData convertColumnFormToMetaData(ColumnForm columnForm) {
        final MetaData metaData = new MetaData();
        metaData.setLinesToSkip(FormHelper.getInteger(columnForm.getSkipFirstLines()));
        metaData.setDataSeparator(columnForm.getDataSeparator());
        metaData.getColumns().addAll(columnForm.getColumns());
        return metaData;
    }

    public static boolean areFieldNamesValid(ColumnForm columnForm) {
        boolean fieldNamesValid = true;
        for(MetaDataColumn column : columnForm.getColumns()) {
            if(column.getLevelName() == null && column.getLevelName().isEmpty()) {
                fieldNamesValid = false;
                break;
            }
        }
        return fieldNamesValid;
    }

    public static List<String> getLevelNamesNotMeasureList(List<MetaDataColumn> columns) {
        final List<String> levelNameValueList = new ArrayList<>();
        for(MetaDataColumn column : columns) {
            if(!column.getMeasure()) {
                levelNameValueList.add(column.getLevelName());
            }
        }
        return levelNameValueList;
    }

}
