package gencube.meta;

public class MetaFileNameHelper {

    public static boolean isMetaFile(String file) {
        return file.contains(".metadata.");
    }

    public static  String buildMetaFileName(String metaFileName) {
        return metaFileName.replaceAll("\\.csv", ".metadata.csv");
    }

}
