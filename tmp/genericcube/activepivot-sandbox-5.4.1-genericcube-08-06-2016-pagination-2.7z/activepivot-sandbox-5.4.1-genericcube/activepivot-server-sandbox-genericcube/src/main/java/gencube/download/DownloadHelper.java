package gencube.download;

import gencube.build.CubeReloader;
import org.springframework.core.io.FileSystemResource;

import javax.servlet.http.HttpServletResponse;
import java.io.File;

public class DownloadHelper {

    public static boolean isLogFileValid(String logFile) {
        return logFile!=null && !logFile.isEmpty();
    }

    public static FileSystemResource createResourceForErrorLog(String logFile, HttpServletResponse response, CubeReloader cubeReloader) {
        response.setHeader("Content-Disposition", "attachment; filename=" + logFile);
        final String metaFilePath = cubeReloader.getLogFilePath(logFile);
        return new FileSystemResource(new File(metaFilePath));
    }

    public static boolean isMetaFileNameValid(String metaFile) {
        return metaFile!=null && metaFile.toLowerCase().contains("metadata");
    }

    public static FileSystemResource createResourceForMetaFile(String metaFile, HttpServletResponse response, CubeReloader cubeReloader) {
        response.setHeader("Content-Disposition", "attachment; filename=" + metaFile);
        final String metaFilePath = cubeReloader.getMetaFilePath(metaFile);
        return new FileSystemResource(new File(metaFilePath));
    }

}
