package gencube.csv;

public class StopParsingException extends RuntimeException {

    public StopParsingException(String message) {
        super(message);
    }
}
