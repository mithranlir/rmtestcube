package gencube.web.form;

public class ActionData {

    private boolean showDimField;

    private int dimOrder;
    private boolean dimAdd;
    private boolean dimDel;
    private boolean dimMoveUp;
    private boolean dimMoveDown;

    private int hierOrder;
    private boolean hierAdd;
    private boolean hierDel;
    private boolean hierMoveUp;
    private boolean hierMoveDown;

    private boolean levelAdd;

    public boolean getLevelDel() {
        return levelDel;
    }

    public void setLevelDel(boolean levelDel) {
        this.levelDel = levelDel;
    }

    public boolean getLevelAdd() {
        return levelAdd;
    }

    public void setLevelAdd(boolean levelAdd) {
        this.levelAdd = levelAdd;
    }

    private boolean levelDel;

    public boolean getShowDimField() {
        return showDimField;
    }

    public void setShowDimField(boolean show) {
        this.showDimField = show;
    }

    public int getDimOrder() {
        return dimOrder;
    }

    public void setDimOrder(int dimOrder) {
        this.dimOrder = dimOrder;
    }

    public boolean getDimAdd() {
        return dimAdd;
    }

    public void setDimAdd(boolean dimAdd) {
        this.dimAdd = dimAdd;
    }

    public boolean getDimDel() {
        return dimDel;
    }

    public void setDimDel(boolean dimDel) {
        this.dimDel = dimDel;
    }

    public boolean getDimMoveUp() {
        return dimMoveUp;
    }

    public void setDimMoveUp(boolean dimMoveUp) {
        this.dimMoveUp = dimMoveUp;
    }

    public boolean getDimMoveDown() {
        return dimMoveDown;
    }

    public void setDimMoveDown(boolean dimMoveDown) {
        this.dimMoveDown = dimMoveDown;
    }

    public int getHierOrder() {
        return hierOrder;
    }

    public void setHierOrder(int hierOrder) {
        this.hierOrder = hierOrder;
    }

    public boolean getHierAdd() {
        return hierAdd;
    }

    public void setHierAdd(boolean hierAdd) {
        this.hierAdd = hierAdd;
    }

    public boolean getHierDel() {
        return hierDel;
    }

    public void setHierDel(boolean hierDel) {
        this.hierDel = hierDel;
    }

    public boolean getHierMoveUp() {
        return hierMoveUp;
    }

    public void setHierMoveUp(boolean hierMoveUp) {
        this.hierMoveUp = hierMoveUp;
    }

    public boolean getHierMoveDown() {
        return hierMoveDown;
    }

    public void setHierMoveDown(boolean hierMoveDown) {
        this.hierMoveDown = hierMoveDown;
    }
}
