package gencube.security;

import gencube.cfg.SecurityConfig;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.security.core.authority.mapping.NullAuthoritiesMapper;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class CustomTokenAuthenticationProvider implements AuthenticationProvider {

	private GrantedAuthoritiesMapper authoritiesMapper = new NullAuthoritiesMapper();
	private UserDetailsService userDetailsService;

    @Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String username = authentication.getPrincipal() == null?"NONE_PROVIDED":authentication.getName();
		UserDetails user = null;
		try {
			user = this.retrieveUser(username, (UsernamePasswordAuthenticationToken)authentication);
		}
		catch (UsernameNotFoundException var6) {
			throw new BadCredentialsException("Bad credentials", null);
		}

		if (isTokenValid(authentication.getCredentials())) {
			return createSuccessAuthentication(user, authentication, user);
		}
		throw new BadCredentialsException("Bad credentials", null);
	}

	protected final UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
		UserDetails loadedUser = null;
		try {
			loadedUser = userDetailsService.loadUserByUsername(username);
		}
		catch (UsernameNotFoundException var6) {
			throw var6;
		}
		catch (Exception var7) {
			throw new InternalAuthenticationServiceException(var7.getMessage(), var7);
		}
		if(loadedUser == null) {
			throw new InternalAuthenticationServiceException("UserDetailsService returned null, which is an interface contract violation");
		} else {
			return loadedUser;
		}
	}

	protected Authentication createSuccessAuthentication(Object principal, Authentication authentication, UserDetails user) {
		UsernamePasswordAuthenticationToken result =
				new UsernamePasswordAuthenticationToken(
						principal, authentication.getCredentials(),
						this.authoritiesMapper.mapAuthorities(user.getAuthorities()));
		result.setDetails(authentication.getDetails());
		return result;
	}

	public boolean supports(Class<?> authentication) {
		return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
	}

	public void setUserDetailsService(UserDetailsService userDetailsService) {
		this.userDetailsService = userDetailsService;
	}

    private boolean isTokenValid(Object credentials) {
		return "12341234".equals(credentials);
	}
}
