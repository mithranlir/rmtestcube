package gencube.web.form;

import gencube.meta.MetaFileNameHelper;

public class HierarchyFormHelper {

    public static String getMetaDataFileName(HierarchyForm hierarchyForm, String dataFile) {
        String metaDataFile = hierarchyForm.getMetaFileName();
        if(metaDataFile==null || metaDataFile.isEmpty()) {
            metaDataFile = MetaFileNameHelper.buildMetaFileName(dataFile);
        }
        return metaDataFile;
    }
}
