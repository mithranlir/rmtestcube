package gencube.loadinghistory;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class LoadingErrorLogWriter {

    public static final int PERIOD_IN_SECONDS = 10;
    public static final String SEP = ";";

    private boolean isRunning = false;
    private FileLoading fileLoading;
    private PrintWriter printWriter;
    private String dirPath;

    private ConcurrentLinkedQueue<FileLoadingError> queue = new ConcurrentLinkedQueue<>();

    private final ScheduledExecutorService service = Executors.newScheduledThreadPool(1);

    public LoadingErrorLogWriter(final FileLoading fileLoading, String dirPath) {
        this.fileLoading = fileLoading;
        this.dirPath = dirPath;
    }

    public void start() {
        this.isRunning = true;
        openErrorFile();
        scheduleDequeuer();
    }

    public void addError(FileLoadingError fileLoadingError) {
        queue.add(fileLoadingError);
        if(!fileLoading.getHasError()) {
            fileLoading.setHasError(true);
        }
    }

    public void stop() {
        service.shutdownNow();
        dequeue();
        closeErrorFile();
        isRunning = false;
    }

    public boolean isRunning() {
        return isRunning;
    }

    private void closeErrorFile() {
        closeErrorFile(printWriter);
    }

    private void openErrorFile() {
        this.printWriter = createPrintWriter(fileLoading);
        writeHeaderInFile();
    }

    private void writeHeaderInFile() {
        this.printWriter.println(getHeaderLine());
    }

    private PrintWriter createPrintWriter(FileLoading fileLoading) {
        final Path path = getErrorLogFilePath(fileLoading);
        PrintWriter out = null;
        try {
            out = new PrintWriter(
                    new BufferedWriter(
                            new FileWriter(path.toFile())));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return out;
    }

    private Path getErrorLogFilePath(FileLoading fileLoading) {
        return Paths.get(dirPath, fileLoading.getErrorLogFileName());
    }

    private void dequeue() {
        for (FileLoadingError fileLoadingError : removeErrorsFromQueue()) {
            final String line = convertToLine(fileLoadingError);
            this.printWriter.println(line);
        }
    }

    private String getHeaderLine() {
        return "rowNumber" + SEP
                + "columnName" + SEP
                + "errorMsg";
    }

    private String convertToLine(FileLoadingError fileLoadingError) {
        return fileLoadingError.getLineNumber() + SEP
                + fileLoadingError.getColumnName() + SEP
                + fileLoadingError.getErrorMessage();
    }

    private void scheduleDequeuer() {
        final Runnable dequeueCommand = createRunnableToDequeue();
        service.scheduleAtFixedRate(dequeueCommand, 0, PERIOD_IN_SECONDS, TimeUnit.SECONDS);
    }

    private Runnable createRunnableToDequeue() {
        return new Runnable() {
            @Override
            public void run() {
                dequeue();
            }
        };
    }

    private List<FileLoadingError> removeErrorsFromQueue() {
        final List<FileLoadingError> errors = new ArrayList<>();
        final int size = queue.size();
        if(size>0) {
            FileLoadingError error;
            int cpt = 0;
            while (cpt<size && (error = queue.poll()) != null) {
                errors.add(error);
                cpt++;
            }
        }
        return errors;
    }

    private void closeErrorFile(PrintWriter printWriter) {
        if(printWriter!=null) {
            printWriter.flush();
            try {
                printWriter.close();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
