package gencube.loadinghistory;

import java.util.Date;

public class FileLoading {

    private String dataFileName;
    private String metaFileName;
    private Date startDate;
    private Date endDate;
    private String errorLogFileName;
    private boolean hasError;
    private boolean maxErrorReached;
    private boolean stopParsingRequested;
    private long totalSize;
    private long currentReadSize;

    public Date getEndDate() {
        return endDate;
    }

    public boolean isFinished() {
        return getEndDate()!=null;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getDataFileName() {
        return dataFileName;
    }

    public void setDataFileName(String dataFileName) {
        this.dataFileName = dataFileName;
    }

    public String getMetaFileName() {
        return metaFileName;
    }

    public void setMetaFileName(String metaFileName) {
        this.metaFileName = metaFileName;
    }

    public String getErrorLogFileName() {
        return errorLogFileName;
    }

    public void setErrorLogFileName(String errorLogFileName) {
        this.errorLogFileName = errorLogFileName;
    }

    public boolean getHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public long getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(long totalSize) {
        this.totalSize = totalSize;
    }

    public long getCurrentReadSize() {
        return currentReadSize;
    }

    public void setCurrentReadSize(long currentReadSize) {
        this.currentReadSize = currentReadSize;
    }

    public boolean isMaxErrorReached() {
        return maxErrorReached;
    }

    public void setMaxErrorReached(boolean maxErrorReached) {
        this.maxErrorReached = maxErrorReached;
    }

    public boolean isStopParsingRequested() {
        return stopParsingRequested;
    }

    public void setStopParsingRequested(boolean parsingStopRequested) {
        this.stopParsingRequested = parsingStopRequested;
    }

    public String getStatus() {
        if(isStopParsingRequested()) {
            return "ABORTED";
        }
        else if(isMaxErrorReached()) {
            return "PARSING ERROR";
        }
        else if(getHasError()) {
            return "PARSING ERROR";
        }
        return "OK";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FileLoading that = (FileLoading) o;

        if (dataFileName != null ? !dataFileName.equals(that.dataFileName) : that.dataFileName != null) return false;
        if (metaFileName != null ? !metaFileName.equals(that.metaFileName) : that.metaFileName != null) return false;
        return !(startDate != null ? !startDate.equals(that.startDate) : that.startDate != null);

    }

    @Override
    public int hashCode() {
        int result = dataFileName != null ? dataFileName.hashCode() : 0;
        result = 31 * result + (metaFileName != null ? metaFileName.hashCode() : 0);
        result = 31 * result + (startDate != null ? startDate.hashCode() : 0);
        return result;
    }

}
