package gencube.meta;

import com.google.common.base.Joiner;
import gencube.meta.model.HierarchyData;
import gencube.meta.model.MetaData;
import gencube.meta.model.MetaDataColumn;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class MetaCsvWriter {

    public static final String SKIPLINES_DEF_HEADER = "#SKIPLINES_DEF|nbSkipLines";
    public static final String DATA_SEP_DEF_HEADER = "#DATA_SEP_DEF|char";
    public static final String FIELD_DEF_HEADER = "#FIELD_DEF|levelName|type|format|displayFormat|isMeasure|allMembersEnabled(if not measure)";
    public static final String HIERARCHY_FIELD_HEADER = "#HIERARCHY_DEF|dimensionName|hierarchyName|defaultHierarchy|hierarchyFolder|field list separated by comma...";
    public final static String SEP = "|";
    public static final String RC = "\n";
    public static final String LIST_SEP = ",";

    public void writeMetaData(String filePath, MetaData metaData) {

        FileWriter fw = null;
        try {
            fw = new FileWriter(filePath);

            // HEADERS COMMENT
            writeHeaderComments(fw);

            // SKIP LINES NUMBER
            fw.write(createSkipLinesDefLine(metaData.getLinesToSkip())+ RC);

            // DATA SEPARATOR
            fw.write(createDataSeparatorDefLine(metaData.getDataSeparator())+ RC);

            // FIELD LINES
            for (MetaDataColumn metaDataColumn : metaData.getColumns()) {
                fw.write(createFieldDefLine(metaDataColumn)+ RC);
            }

            // HIERARCHY LINES
            for (HierarchyData hierarchyData : metaData.getHierarchies()) {
                fw.write(createHierarchyDefLine(hierarchyData)+ RC);
            }

            fw.flush();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if(fw!=null) {
                try {
                    fw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void writeHeaderComments(FileWriter fw) throws IOException {
        fw.write(DATA_SEP_DEF_HEADER + RC);
        fw.write(SKIPLINES_DEF_HEADER + RC);
        fw.write(FIELD_DEF_HEADER + RC);
        fw.write(HIERARCHY_FIELD_HEADER + RC);
    }

    private String createHierarchyDefLine(HierarchyData hierarchyData) {
        return MetaCsvReader.HIERARCHY_DEF + SEP
                + hierarchyData.getDimensionName() + SEP
                + hierarchyData.getHierarchyName() + SEP
                + hierarchyData.getDefaultHierarchy() + SEP
                + hierarchyData.getHierarchyFolder() + SEP
                + flatStringList(hierarchyData.getLevelNames());
    }

    private String createFieldDefLine(MetaDataColumn metaDataColumn) {
        return MetaCsvReader.FIELD_DEF + SEP
                + metaDataColumn.getLevelName() + SEP
                + metaDataColumn.getType() + SEP
                + metaDataColumn.getFormat() + SEP
                + metaDataColumn.getDisplayFormat() + SEP
                + metaDataColumn.getMeasure() + SEP
                + metaDataColumn.getAllMembersEnabled();
    }

    private String createDataSeparatorDefLine(String separator) {
        return MetaCsvReader.DATA_SEP_DEF + SEP
                + separator;
    }

    private String createSkipLinesDefLine(int skipLines) {
        return MetaCsvReader.SKIPLINES_DEF + SEP
                + skipLines;
    }

    private String flatStringList(List<String> values) {
        if(values==null || values.isEmpty()) {
            return "";
        }
        return Joiner.on(LIST_SEP).join(values);
    }

}
