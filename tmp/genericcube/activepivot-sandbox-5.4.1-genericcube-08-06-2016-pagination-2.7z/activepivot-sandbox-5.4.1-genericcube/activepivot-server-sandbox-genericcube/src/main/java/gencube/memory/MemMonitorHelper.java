package gencube.memory;

import com.qfs.logging.MessagesSandbox;

import java.util.logging.Logger;

public class MemMonitorHelper {

    protected static Logger LOGGER = MessagesSandbox.getLogger(MemMonitorHelper.class);

    public static Thread createAndStartMemMonitorThread() {
        final Thread thread = new Thread() {
            @Override
            public void run() {
                while (!this.isInterrupted()) {
                    logAvailableMemory();
                    try {
                        Thread.sleep(10000);
                    }
                    catch (InterruptedException e) {
                        break;
                    }
                }
            }
        };
        thread.start();
        return thread;
    }

    public static void logAvailableMemory() {
        long allocatedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        long presumableFreeMemory = Runtime.getRuntime().maxMemory() - allocatedMemory;
        LOGGER.info("freeMem=" + (Runtime.getRuntime().freeMemory() / (1024 * 1024)) + " MB "
                + "presumableFreeMemory=" + (presumableFreeMemory / (1024 * 1024)) + " MB");
    }


    public static void stopMemMonitor(Thread t) {
        t.interrupt();
        try {
            t.join();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
