package gencube.validation;

import gencube.build.CubeReloader;
import gencube.build.PreAnalyzeResult;
import gencube.datasamples.DataSamples;
import gencube.meta.model.MetaData;
import gencube.meta.model.MetaDataColumn;
import gencube.web.select.ConfigFiles;
import rmlib.typevalidator.TypeValidator;
import rmlib.typevalidator.model.CubeTypes;
import rmlib.typevalidator.model.TypeValidatorResult;
import rmlib.typevalidator.model.TypeValidatorValidResult;

import java.util.List;

public class FileValidator {

    private TypeValidator typeValidator;
    private CubeReloader cubeReloader;

    public FileValidator(TypeValidator typeValidator, CubeReloader cubeReloader) {
        this.typeValidator = typeValidator;
        this.cubeReloader = cubeReloader;
    }

    public ValidationResult validateDataFileWithMetaFile(ConfigFiles configFiles) {

        final ValidationResult validationResult = new ValidationResult();
        final String metaFilePath = cubeReloader.getMetaFilePath(configFiles.getMetaFile());
        final MetaData metaData = cubeReloader.getMetaData(metaFilePath);
        final String dataFilePath = cubeReloader.getMetaFilePath(configFiles.getDataFile());
        final DataSamples dataSamples = cubeReloader.getDataSamples(dataFilePath, metaData);

        if(dataSamples.isSeparatorError()) {
            validationResult.setSeparatorError(true);
        }
        else {
            if(dataSamples.getSamplesMap().size()!=metaData.getColumns().size()) {
                // TODO
                validationResult.setSeparatorError(true);
            }
            else {
                for (int i = 0; i < metaData.getColumns().size(); i++) {
                    final MetaDataColumn column = metaData.getColumns().get(i);
                    final List<String> samples = dataSamples.getSamplesMap().get(i);
                    final TypeValidatorValidResult result = typeValidator.valid(samples, column.getType(), column.getFormat());
                    final ColumnValidationResult columnValidationResult = new ColumnValidationResult(result, column);
                    validationResult.getColumnValidationResultList().add(columnValidationResult);
                }
            }
        }
        return validationResult;
    }

    public MetaData createMetaData(String dataFilePath, int nbLinesToSkip, String dataSeparator) {

        final PreAnalyzeResult result = cubeReloader.preAnalyzeResult(dataFilePath, dataSeparator);
        if(result == null) {
            return null;
        }

        final DataSamples dataSamples =
                cubeReloader.getDataSamples(dataFilePath, result.getNbColumns(), nbLinesToSkip, result.getSeparatorFound());

        final MetaData metaData = new MetaData();
        metaData.setDataSeparator(dataSeparator);
        metaData.setLinesToSkip(nbLinesToSkip);

        for (int i = 0; i < result.getNbColumns(); i++) {
            final List<String> samples = dataSamples.getSamplesMap().get(i);
            final TypeValidatorResult typeValidatorResult = typeValidator.findType(samples);
            final MetaDataColumn column = new MetaDataColumn();
            if(typeValidatorResult == null || typeValidatorResult.getTypeFound() == null) {
                column.setType(CubeTypes.STRING);
                column.setAllMembersEnabled(true);
            }
            else {
                column.setType(typeValidatorResult.getTypeFound());
                column.setFormat(typeValidatorResult.getFormat());
                column.setAllMembersEnabled(true);
                column.setDisplayFormat(column.getFormat());
                if(CubeTypes.DECIMAL_TYPES.contains(column.getType())) {
                    column.setMeasure(true);
                }
            }
            column.setLevelName(getDefaultName(column.getType(), i+1));
            metaData.addColumn(column);
        }

        return metaData;
    }

    private String getDefaultName(String type, int index) {
        return type + "_" + index;
    }

    public List<String> getDateFormatList() {
        return typeValidator.getDateFormatList();
    }

    public PreAnalyzeResult preAnalyzeDataFile(String dataFilePath) {
        return cubeReloader.preAnalyzeResult(dataFilePath);
    }

}
