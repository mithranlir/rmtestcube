package gencube.cfg;

public class GenericCubeConst {
    public final static String REFERENCE_CSV_DIRECTORY_PROP = "reference.csv.directory";
    public final static String DEFAULT_CSV_METAFILE_PROP = "default.csv.metafile";
    public final static String DEFAULT_CSV_DATAFILE_PROP = "default.csv.datafile";
    public final static String CSV_DIRECTORY_PROP = "csv.directory";
}
