package gencube.web.form;

import gencube.meta.model.HierarchyData;

import java.util.ArrayList;
import java.util.List;

public class HierarchyForm {

    private List<HierarchyData> hierarchies = new ArrayList<>();
    private List<ActionData> actionDatas = new ArrayList<>();
    private String actionName;
    private String position;
    private String metaFileName;

    public HierarchyForm() {
    }

    public void initActionNameAndPosition() {
        setActionName(null);
        setPosition(null);
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public void setHierarchies(List<HierarchyData> hierarchies) {
        this.hierarchies = hierarchies;
    }

    public List<HierarchyData> getHierarchies() {
        return hierarchies;
    }

    public List<ActionData> getActionDatas() {
        return actionDatas;
    }

    public void setActionDatas(List<ActionData> actionDatas) {
        this.actionDatas = actionDatas;
    }

    public String getMetaFileName() {
        return metaFileName;
    }

    public void setMetaFileName(String metaFileName) {
        this.metaFileName = metaFileName;
    }
}
