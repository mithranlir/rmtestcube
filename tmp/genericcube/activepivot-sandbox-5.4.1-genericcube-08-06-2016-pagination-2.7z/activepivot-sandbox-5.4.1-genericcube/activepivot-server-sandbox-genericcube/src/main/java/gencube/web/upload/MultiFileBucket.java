package gencube.web.upload;

import java.util.ArrayList;
import java.util.List;

public class MultiFileBucket {

    private String actionType;

    private List<FileBucket> files = new ArrayList<>();

    public MultiFileBucket(){
        files.add(new FileBucket());
        files.add(new FileBucket());
    }

    public List<FileBucket> getFiles() {
        return files;
    }

    public void setFiles(List<FileBucket> files) {
        this.files = files;
    }


}
