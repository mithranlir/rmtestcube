package gencube.web.helper;

import gencube.meta.model.HierarchyData;
import gencube.web.form.ActionData;
import gencube.web.form.HierarchyForm;
import gencube.web.form.OrderCtx;
import gencube.web.form.PositionData;

import java.util.ArrayList;
import java.util.List;

public class HierarchyActionConfigurator {

    public static void configureForDisplay(HierarchyForm hierarchyForm) {
        final List<ActionData> actionDataList = new ArrayList<>();
        final OrderCtx orderCtx = new OrderCtx();
        for(int i=0; i<hierarchyForm.getHierarchies().size(); i++) {
            final HierarchyData hierarchyData = hierarchyForm.getHierarchies().get(i);
            final ActionData actionData = new ActionData();
            configureOrders(orderCtx, hierarchyData, actionData);
            configureShowDimField(actionData);
            configureActions(hierarchyForm, i, actionData);
            actionDataList.add(actionData);
        }
        hierarchyForm.setActionDatas(actionDataList);
    }

    private static void configureOrders(OrderCtx orderCtx, HierarchyData hierarchyData, ActionData actionData) {
        if(isNotSame(orderCtx.getLastDimName(), hierarchyData.getDimensionName())) {
            orderCtx.incDimOrder();
            orderCtx.setCurrentHierOrder(1);
        }
        else {
            orderCtx.incHierOrder();
        }
        orderCtx.setLastDimName(hierarchyData.getDimensionName());
        actionData.setDimOrder(orderCtx.getCurrentDimOrder());
        actionData.setHierOrder(orderCtx.getCurrentHierOrder());
    }

    private static void configureShowDimField(ActionData actionData) {
        if(actionData.getHierOrder()==1) {
            actionData.setShowDimField(true);
        }
    }

    private static void configureActions(HierarchyForm hierarchyForm, int i, ActionData actionData) {
        configureDimensionActions(hierarchyForm, i, actionData);
        configureHierarchyActions(hierarchyForm, i, actionData);
        configureLevelActions(hierarchyForm, i, actionData);
    }

    private static void configureLevelActions(HierarchyForm hierarchyForm, int i, ActionData actionData) {
        if(hierarchyForm.getHierarchies().get(i).getLevelNames().size()>1) {
            actionData.setLevelDel(true);
        }
        actionData.setLevelAdd(true);
    }

    private static void configureHierarchyActions(HierarchyForm hierarchyForm, int i, ActionData actionData) {
        final PositionData hierarchyPos =
                computeHierarchyPosition(i, hierarchyForm.getHierarchies(), actionData);
        if(!hierarchyPos.isFirst()) {
            actionData.setHierMoveUp(true);
        }
        if(!hierarchyPos.isLast()) {
            actionData.setHierMoveDown(true);
        }
        if(hierarchyPos.isLast()) {
            actionData.setHierAdd(true);
            if(!hierarchyPos.isFirst()) {
                actionData.setHierDel(true);
            }
        }
    }

    private static void configureDimensionActions(HierarchyForm hierarchyForm, int i, ActionData actionData) {
        if(actionData.getShowDimField()) {
            final PositionData dimensionPos =
                    computeDimPosition(i, hierarchyForm.getHierarchies());
            if(!dimensionPos.isFirst()) {
                actionData.setDimMoveUp(true);
            }
            if(!dimensionPos.isLast()) {
                actionData.setDimMoveDown(true);
            }
            if(dimensionPos.isLast()) {
                actionData.setDimAdd(true);
            }
            actionData.setDimDel(true);
        }
    }

    private static PositionData computeDimPosition(int index, List<HierarchyData> hierarchies) {
        final PositionData position = new PositionData();
        position.setFirst(isFirstDimension(index, hierarchies));
        position.setLast(isLastDimension(index, hierarchies));
        return position;
    }

    private static PositionData computeHierarchyPosition(int index, List<HierarchyData> hierarchies, ActionData actionData) {
        final PositionData position = new PositionData();
        position.setFirst(isFirstHierarchyInDim(index, actionData));
        position.setLast(isLastHierarchyInDim(index, hierarchies));
        return position;
    }

    private static boolean isNotSame(String lastDimName, String dimensionName) {
        return lastDimName == null || !lastDimName.equals(dimensionName);
    }

    private static boolean isLastDimension(int index, List<HierarchyData> hierarchies) {
        final String dimName = hierarchies.get(index).getDimensionName();
        int nextDimIdx = -1;
        for(int i=index+1; i<hierarchies.size(); i++) {
            final HierarchyData data = hierarchies.get(i);
            if(!dimName.equals(data.getDimensionName())) {
                nextDimIdx = i;
                break;
            }
        }
        return nextDimIdx == -1;
    }

    private static boolean isFirstDimension(int index, List<HierarchyData> hierarchies) {
        final String dimName = hierarchies.get(index).getDimensionName();
        for(int i=0; i<hierarchies.size() && i<index; i++) {
            final HierarchyData data = hierarchies.get(i);
            if(!dimName.equals(data.getDimensionName())) {
                return false;
            }
        }
        return true;
    }

    private static boolean isLastHierarchyInDim(int index, List<HierarchyData> hierarchies) {
        final String dimName = hierarchies.get(index).getDimensionName();
        final int nextIndex = index + 1;
        if(nextIndex < hierarchies.size()) {
            final String dimNameOfNextHierarchy = hierarchies.get(nextIndex).getDimensionName();
            return !dimName.equals(dimNameOfNextHierarchy);
        }
        return true;
    }

    private static boolean isFirstHierarchyInDim(int index, ActionData actionData) {
        return actionData.getHierOrder() == 1;
    }

}
