package gencube.parser;

import com.qfs.msg.csv.IFileInfo;
import com.qfs.msg.csv.ILineReader;
import com.qfs.msg.csv.impl.CSVColumnParser;
import com.quartetfs.fwk.QuartetRuntimeException;
import com.quartetfs.fwk.format.IParser;
import gencube.loadinghistory.FileLoadingError;
import gencube.loadinghistory.FileLoadingHistoryService;

public class CustomCSVColumnParser extends CSVColumnParser {

    private FileLoadingHistoryService service;

    public CustomCSVColumnParser(String columnName, String columnType, FileLoadingHistoryService service) {
        super(columnName, columnType);
        this.service = service;
    }

    public CustomCSVColumnParser(String columnName, String columnType, int sourcePosition, FileLoadingHistoryService service) {
        super(columnName, columnType, sourcePosition);
        this.service = service;
    }

    public CustomCSVColumnParser(String columnName, IParser<?> parser, int sourcePosition, FileLoadingHistoryService service) {
        super(columnName, parser, sourcePosition);
        this.service = service;
    }

    public CustomCSVColumnParser(String columnName, String columnType, int sourcePosition, Object defaultValue, FileLoadingHistoryService service) {
        super(columnName, columnType, sourcePosition, defaultValue);
        this.service = service;
    }

    @Override
    public Object compute(IColumnCalculationContext<ILineReader> context) {
        final CharSequence text = context.getContext().readSequence(this.sourcePosition);
        try {
            final Object e = this.fieldParser.parse(text);
            return null == e && this.hasDefaultValue?this.defaultValue:e;
        }
        catch (Exception exception) {
            final IFileInfo fileInfo = context.getContext().getCurrentFile();
            processFileLoadingError(context, text, fileInfo.getName());
            throw new QuartetRuntimeException(exception, "messaging-csv", "EXC_TRANSLATING_COL", new Object[]{this.columnName, this.fieldParser, fileInfo, text});
        }
    }

    private void processFileLoadingError(IColumnCalculationContext<ILineReader> context, CharSequence text, String dataFileName) {
        final String errorMsg = "Cannot parse \"" + text + "\" with parser " + this.fieldParser.key();
        final FileLoadingError fileLoadingError = createFileLoadingError(context, errorMsg, dataFileName);
        service.addError(fileLoadingError);
    }

    private FileLoadingError createFileLoadingError(IColumnCalculationContext<ILineReader> context, String errorMsg, String dataFileName) {
        final FileLoadingError fileLoadingError = new FileLoadingError();
        fileLoadingError.setFileName(dataFileName);
        fileLoadingError.setIndex(sourcePosition);
        fileLoadingError.setColumnName(columnName);
        fileLoadingError.setErrorMessage(errorMsg);
        fileLoadingError.setLineNumber(context.getContext().getLineIndex());
        return fileLoadingError;
    }
}
