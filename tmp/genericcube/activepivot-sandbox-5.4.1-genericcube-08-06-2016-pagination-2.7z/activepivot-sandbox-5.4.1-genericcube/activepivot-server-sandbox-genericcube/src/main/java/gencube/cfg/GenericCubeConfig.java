package gencube.cfg;

import com.qfs.QfsWebUtils;
import com.qfs.content.service.IContentService;
import com.qfs.monitoring.HealthCheckAgent;
import com.qfs.pivot.content.IActivePivotContentService;
import com.qfs.pivot.servlet.impl.ContextValueFilter;
import com.qfs.sandbox.cfg.impl.SandboxCorsFilterConfig;
import com.qfs.server.cfg.IActivePivotConfig;
import com.qfs.server.cfg.IActivePivotContentServiceConfig;
import com.qfs.server.cfg.impl.*;
import com.qfs.store.impl.SchemaPrinter;
import com.qfs.store.log.impl.LogWriteException;
import com.quartetfs.biz.pivot.IActivePivotManager;
import com.quartetfs.biz.pivot.impl.PeriodicActivePivotSchemaRebuilder;
import com.quartetfs.biz.pivot.security.IAuthorityComparator;
import com.quartetfs.biz.pivot.security.IContextValueManager;
import com.quartetfs.biz.pivot.security.IUserDetailsService;
import com.quartetfs.biz.pivot.security.impl.ContextValueManager;
import com.quartetfs.biz.pivot.security.impl.ContextValuePropagator;
import com.quartetfs.biz.pivot.streaming.IMdxStreamRegister;
import com.quartetfs.biz.pivot.webservices.impl.ConfigurationService;
import com.quartetfs.biz.pivot.webservices.impl.JAXBDataBindingFactory;
import com.quartetfs.fwk.Registry;
import com.quartetfs.fwk.contributions.impl.ClasspathContributionProvider;
import com.quartetfs.fwk.query.QueryException;
import com.quartetfs.fwk.types.impl.ExtendedPluginInjector;
import com.quartetfs.fwk.types.impl.FactoryValue;
import com.quartetfs.pivot.live.sandbox.server.paging.IPagingService;
import com.quartetfs.pivot.live.sandbox.server.paging.impl.PagingService;
import com.quartetfs.tech.streaming.IStream;
import gencube.build.ContentServiceBuildHelper;
import gencube.build.CubeReloader;
import gencube.build.DistributedMessageAndSecurityHelper;
import gencube.build.GenericCubeBuilder;
import gencube.loading.LoadingService;
import gencube.loadinghistory.FileLoadingHistoryService;
import gencube.stream.CustomMdxStream;
import gencube.upload.DirectoryBrowser;
import gencube.upload.UploadFileManager;
import gencube.validation.FileValidator;
import gencube.web.action.HierarchyActionProcessor;
import org.apache.cxf.jaxws.spring.EndpointDefinitionParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;
import rmlib.ProgrammaticCubeWrapper;
import rmlib.cubebuilder.CubeBuilder;
import rmlib.debug.HierarchiesPrintHelper;
import rmlib.query.SimpleQueryUtils;
import rmlib.typevalidator.TypeValidator;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@PropertySource(value = { "classpath:sandbox.properties", "classpath:jwt.properties" } )
@Configuration
@Import(value = {

		InitCubeConfig.class,

		ActivePivotServicesConfig.class,
		ActivePivotCxfServicesConfig.class,
		ActivePivotRemotingServicesConfig.class,

		JwtConfig.class,
		SandboxCorsFilterConfig.class,

		LiveResourceServerConfig.class,

		// CUSTOM SECU
		SecurityConfig.class,

		ActivePivotXmlaConfig.class,

		QfsRestServicesConfig.class,

		// Streaming Services monitor
		StreamingMonitorConfig.class,
		// web mvc (none QFS)
		WebMvcConfig.class
})
public class GenericCubeConfig implements IActivePivotConfig, IActivePivotContentServiceConfig {

	/** Before anything else we statically initialize the Quartet FS Registry. */
	static {
		Registry.setContributionProvider(new ClasspathContributionProvider("com.qfs", "com.quartetfs", "gencube.context"));
	}


	@Autowired(
			required = false
	)
	protected IAuthorityComparator authorityComparator;

	@Autowired
	protected Environment env;

	@Bean
	public DirectoryBrowser directoryBrowser() {
		return new DirectoryBrowser(env);
	}

	@Bean
	public FileLoadingHistoryService fileLoadingHistoryService() {
		return new FileLoadingHistoryService();
	}

	@Bean
	public CubeReloader cubeReloader(FileLoadingHistoryService fileLoadingHistoryService) {
		return new CubeReloader(env, fileLoadingHistoryService);
	}

	@Bean
	public LoadingService loadingService(CubeReloader cureReloader, FileLoadingHistoryService fileLoadingHistoryService) {
		return new LoadingService(cureReloader, fileLoadingHistoryService);
	}

	@Autowired
	private ResourceLoader resourceLoader;

	@Bean
	public TypeValidator typeValidator() throws IOException, URISyntaxException {
		return new TypeValidator();
	}

	@Bean
	public HierarchyActionProcessor hyrarchyActionProcessor() {
		return new HierarchyActionProcessor();
	}

	@Bean
	public FileValidator fileValidator(TypeValidator typeValidator, CubeReloader cubeReloader) throws IOException, URISyntaxException {
		return new FileValidator(typeValidator, cubeReloader);
	}

	@Bean
	public UploadFileManager uploadFileManager(DirectoryBrowser directoryBrowser, CubeReloader cubeReloader) {
		return new UploadFileManager(directoryBrowser, cubeReloader);
	}

	@Bean
	public ProgrammaticCubeWrapper programmaticCubeWrapper(CubeReloader cubeReloader) throws Exception {
		return cubeReloader.buildProgrammaticCubeWrapper();
	}

	@Bean
	@DependsOn({"programmaticCubeWrapper"})
	public Void configureCubeReloader(CubeReloader cubeReloader, ProgrammaticCubeWrapper programmaticCube) {
		cubeReloader.configure(programmaticCube);
		return null;
	}

	@Autowired
	private ProgrammaticCubeWrapper programmaticCubeWrapper;

	@Bean(destroyMethod = "stop")
	@Override
	public IActivePivotManager activePivotManager() {
		return programmaticCubeWrapper.getManager();
	}

	@Autowired
	private IActivePivotManager activePivotManager;

	@Bean
	@Override
	public IActivePivotContentService activePivotContentService() {
		return ContentServiceBuildHelper.createActivePivotContentService(
				programmaticCubeWrapper.getActivePivotManagerDescription());
	}

	@Bean
	@Override
	public IContentService contentService() {
		// Return the real content service used by the activePivotContentService instead of the wrapped one
		return activePivotContentService().getContentService().getUnderlying();
	}

	@Bean
	public Void configurationCubeReloaderWithConfigurationService(CubeReloader cubeReloader,
																  ConfigurationService configurationService) {
		cubeReloader.setConfigurationService(configurationService);
		return null;
	}

	@Bean
	public Void startManager(
			IActivePivotManager activePivotManager,
			IContextValueManager contextValueManager,
			IUserDetailsService userDetailsService,
			IMdxStreamRegister mdxStreamRegister) throws Exception {

		DistributedMessageAndSecurityHelper.configure(contextValueManager, userDetailsService);

		Registry.getExtendedPlugin(IStream.class).add(new FactoryValue<IStream>(CustomMdxStream.PLUGIN_KEY, CustomMdxStream.PLUGIN_KEY, CustomMdxStream.class));
		ExtendedPluginInjector.inject(IStream.class, CustomMdxStream.PLUGIN_KEY, "ActivePivotManager", activePivotManager);
		ExtendedPluginInjector.inject(IStream.class, CustomMdxStream.PLUGIN_KEY, "mdxStreamRegister", mdxStreamRegister);
		ExtendedPluginInjector.inject(IStream.class, CustomMdxStream.PLUGIN_KEY, "contextValueManager", contextValueManager);

		/* Initialize the ActivePivot Manager and start it */
		activePivotManager.init(null);
		activePivotManager.start();

		return null;
	}

	@Bean
	@DependsOn({"startManager"})
	public Void csvLoad(CubeReloader cubeReloader, ProgrammaticCubeWrapper testCube) throws LogWriteException, IOException {
		cubeReloader.csvLoad(testCube);
		return null;
	}

	@Bean
	@DependsOn(value = { "csvLoad"})
	public Void checkResults(ProgrammaticCubeWrapper testCube) throws QueryException, ParseException {

		HierarchiesPrintHelper.printHierarchies(testCube.getPivot().getId(), testCube.getManager());

		SchemaPrinter.printStoresSizes(testCube.getDatastore().getHead().getSchema());

		// QUERY CUBE (SIMPLE)
		SimpleQueryUtils.queryCubeSimple(GenericCubeBuilder.CUBE_NAME, testCube.getManager());

		return null;
	}

	@Bean(
			destroyMethod = "shutdown"
	)
	public IContextValueManager contextValueManager() {
		final ContextValueManager contextValueManager = new ContextValueManager();
		if(null != this.authorityComparator) {
			contextValueManager.setAuthorityComparator(this.authorityComparator);
		}
		return contextValueManager;
	}

	@Autowired
	private IContextValueManager contextValueManager;

	@Bean
	public IPagingService pagingService() {
		return new PagingService(contextValueManager);
	}

	@Bean
	@Override
	public ContextValueFilter contextValueFilter() {
		return new ContextValueFilter(this.contextValuePropagator());
	}

	@Bean
	public ContextValuePropagator contextValuePropagator() {
		final ContextValuePropagator propagator = new ContextValuePropagator(activePivotManager, contextValueManager);
		return propagator;
	}

	@Bean(initMethod = "start", destroyMethod = "stop")
	public PeriodicActivePivotSchemaRebuilder rebuild(IActivePivotManager manager) {
		return new PeriodicActivePivotSchemaRebuilder()
				.setManager(manager)
				.setSchemaName(CubeBuilder.TEST_SCHEMA)
				.setPeriod(30, TimeUnit.MINUTES);
	}

	@Bean(initMethod = "start", destroyMethod = "interrupt")
	public HealthCheckAgent healthCheckAgent() {
		final HealthCheckAgent agent = new HealthCheckAgent(60);  // One trace per minute
		return agent;
	}

	@Bean
	public IPagingService pagingService(IContextValueManager contextValueManager) {
		final PagingService service = new PagingService(contextValueManager);
		return service;
	}

	@Bean(
			initMethod = "publish",
			destroyMethod = "stop"
	)
	public javax.xml.ws.Endpoint cxfPagingService(JAXBDataBindingFactory jaxbDataBindingFactory, IPagingService pagingService) throws Exception {
		return this.createEndPoint(pagingService, jaxbDataBindingFactory, "Paging");
	}

	protected javax.xml.ws.Endpoint createEndPoint(Object service, JAXBDataBindingFactory factory, String adress) throws Exception {
		EndpointDefinitionParser.SpringEndpointImpl cxf = new EndpointDefinitionParser.SpringEndpointImpl(service);
		cxf.setDataBinding(factory.create());
		cxf.setAddress(QfsWebUtils.url(new String[]{"/webservices", adress}));
		cxf.setProperties(this.webServiceProperties());
		return cxf;
	}

	public Map<String, Object> webServiceProperties() {
		HashMap properties = new HashMap();
		properties.put("faultStackTraceEnabled", Boolean.valueOf(true));
		properties.put("exceptionMessageCauseEnabled", Boolean.valueOf(true));
		return properties;
	}

}
