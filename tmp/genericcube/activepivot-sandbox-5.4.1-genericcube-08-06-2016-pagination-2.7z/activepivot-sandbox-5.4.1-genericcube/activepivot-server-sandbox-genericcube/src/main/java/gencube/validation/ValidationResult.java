package gencube.validation;

import java.util.ArrayList;
import java.util.List;

public class ValidationResult {

    private List<ColumnValidationResult> columnValidationResultList = new ArrayList<ColumnValidationResult>();
    private boolean separatorError;
    private boolean currentLoadingNotFinished;
    private boolean invalidMetaDataFile;

    public boolean isCurrentLoadingNotFinished() {
        return currentLoadingNotFinished;
    }

    public void setCurrentLoadingNotFinished(boolean currentLoadingNotFinished) {
        this.currentLoadingNotFinished = currentLoadingNotFinished;
    }

    public boolean isSeparatorError() {
        return separatorError;
    }

    public void setSeparatorError(boolean separatorError) {
        this.separatorError = separatorError;
    }

    public List<ColumnValidationResult> getColumnValidationResultList() {
        return columnValidationResultList;
    }

    public void setColumnValidationResultList(List<ColumnValidationResult> columnValidationResultList) {
        this.columnValidationResultList = columnValidationResultList;
    }

    public boolean hasValidationErrors() {
        for(ColumnValidationResult columnValidationResult : columnValidationResultList) {
            if(!columnValidationResult.isValid()) {
                return true;
            }
        }
        return false;
    }

    public boolean hasErrors() {
        return currentLoadingNotFinished || isSeparatorError() || hasValidationErrors() || isInvalidMetaDataFile();
    }

    public boolean isInvalidMetaDataFile() {
        return invalidMetaDataFile;
    }

    public void setInvalidMetaDataFile(boolean invalidMetaDataFile) {
        this.invalidMetaDataFile = invalidMetaDataFile;
    }
}
