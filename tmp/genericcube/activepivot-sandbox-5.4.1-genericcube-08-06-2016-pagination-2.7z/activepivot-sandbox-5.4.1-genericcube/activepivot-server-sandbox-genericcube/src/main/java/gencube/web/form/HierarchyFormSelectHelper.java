package gencube.web.form;

import gencube.web.combo.select.ISelectValue;
import gencube.web.helper.ColumnDataSelectHelper;

import java.util.List;

import static gencube.web.helper.ColumnDataSelectHelper.*;

public class HierarchyFormSelectHelper {

    public static List<ISelectValue<Integer>> getSelectDefaultHierarchyValues(HierarchyForm hierarchyForm) {
        final List<String> booleanValueList = ColumnDataSelectHelper.getFalseTrueValues();
        final List<ISelectValue<Integer>> selectDefaultHierarchyValues =
                getValuesWithIntKey(
                        hierarchyForm, booleanValueList, getValueGetterForDefaultHierarchy());
        return selectDefaultHierarchyValues;
    }

    public static List<ISelectValue<String>> getSelectLevelNameValues(HierarchyForm hierarchyForm, List<String> levelNames) {
        final List<ISelectValue<String>> selectLevelNameValues =
                getValuesWithStringKey(
                        hierarchyForm, levelNames, getValueGetterForLevel());
        return selectLevelNameValues;
    }
}
