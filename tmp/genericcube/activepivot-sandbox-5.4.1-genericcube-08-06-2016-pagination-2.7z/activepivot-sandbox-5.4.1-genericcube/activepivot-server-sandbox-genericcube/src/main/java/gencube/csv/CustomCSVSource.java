package gencube.csv;

import com.qfs.msg.IMessageChannel;
import com.qfs.msg.csv.ICSVParserConfiguration;
import com.qfs.msg.csv.IFileInfo;
import com.qfs.msg.csv.ILineReader;
import com.qfs.msg.csv.impl.CSVSource;
import com.qfs.msg.csv.impl.Parser;
import com.qfs.msg.csv.impl.ParserContext;

public class CustomCSVSource extends CSVSource {

    private CustomParserContext currentParserContext = null;

    private StopParsingListener stopParsingListener;

    public CustomCSVSource(StopParsingListener stopParsingListener) {
        super();
        this.stopParsingListener = stopParsingListener;
    }

    @Override
    protected ParserContext createParserContext(
            ICSVParserConfiguration cfg,
            IMessageChannel<IFileInfo, ILineReader> messageChannel) {

        final CustomParserContext parserContext =
                new CustomParserContext(this, cfg, this.threadPool, messageChannel, stopParsingListener);

        this.currentParserContext = parserContext;
        return parserContext;
    }

    public long getCurrentReadSize() {
        if(currentParserContext!=null) {
            return currentParserContext.getReadSize();
        }
        return 0;
    }

}
