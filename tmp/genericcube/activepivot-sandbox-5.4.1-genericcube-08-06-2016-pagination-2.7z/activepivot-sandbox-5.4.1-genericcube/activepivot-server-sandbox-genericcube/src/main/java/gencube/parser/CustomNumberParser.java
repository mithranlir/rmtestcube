package gencube.parser;

import com.quartetfs.fwk.format.IParser;
import com.quartetfs.fwk.types.impl.PluginValue;
import org.springframework.util.StringUtils;
import rmlib.typevalidator.helper.NumberParsingHelper;

import java.util.Locale;

public abstract class CustomNumberParser<T> extends PluginValue implements IParser<T> {

    private String format = null;
    private IParser<T> defaultParser;

    public CustomNumberParser(String format, IParser<T> defaultParser) {
        this.format = format;
        this.defaultParser = defaultParser;
    }

    protected String normalizeValue(String value) {
        return value;
    }

    @Override
    public T parse(CharSequence sequence) throws NumberFormatException {

        if(format == null) {
            return defaultParser.parse(sequence);
        }
        
        String columnValue = sequence.toString();
        if (StringUtils.isEmpty(columnValue)) {
            return defaultValue();
        }

        columnValue = normalizeValue(columnValue);

        return parseValue(columnValue);
    }

    protected abstract T parseValue(String value);

    protected String normalizeValueIfFrenchSep(String value) {
        if(NumberParsingHelper.containsFrenchSep(value)) {
            value = NumberParsingHelper.replaceFrenchDecimalSepWithDecimalSep(value);
        }
        return value;
    }

    protected abstract T defaultValue();

}
