package gencube.web.form;

public class OrderCtx {

    private String lastDimName = null;
    private int currentDimOrder = 0;
    private int currentHierOrder = 0;

    public int getCurrentHierOrder() {
        return currentHierOrder;
    }

    public int incHierOrder() {
        return ++currentHierOrder;
    }

    public void setCurrentHierOrder(int currentHierOrder) {
        this.currentHierOrder = currentHierOrder;
    }

    public String getLastDimName() {
        return lastDimName;
    }

    public void setLastDimName(String lastDimName) {
        this.lastDimName = lastDimName;
    }

    public int getCurrentDimOrder() {
        return currentDimOrder;
    }

    public int incDimOrder() {
        return ++currentDimOrder;
    }

    public void setCurrentDimOrder(int currentDimOrder) {
        this.currentDimOrder = currentDimOrder;
    }


}
