package gencube.csv;


public interface StopParsingListener {
    void onMaxParsingErrorReached(String fileName);
    boolean isStopParsingRequested();
}
