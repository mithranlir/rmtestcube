package gencube.web.combo;

import gencube.web.combo.select.AbstractSelectValueBuilder;
import gencube.web.combo.select.ISelectValue;

import java.util.List;

public class StringKeySelectValueBuilder extends AbstractSelectValueBuilder<String> {

    public StringKeySelectValueBuilder(List<String> values) {
        super(values);
    }

    @Override
    protected ISelectValue<String> createSelectValue(String value) {
        return new StringKeySelectValue(value);
    }
}
