package gencube.loadingprogress;

import gencube.loadinghistory.FileLoading;
import gencube.web.form.FileLoadingProgress;

public class LoadingProgressHelper {

    public static FileLoadingProgress createFileLoadingProgress(FileLoading fileLoading) {
        final FileLoadingProgress result = new FileLoadingProgress();
        result.setTotalSize(fileLoading.getTotalSize());
        result.setCurrentReadSize(fileLoading.getCurrentReadSize());
        result.setStopProgress(fileLoading.isFinished());
        return result;
    }
}
