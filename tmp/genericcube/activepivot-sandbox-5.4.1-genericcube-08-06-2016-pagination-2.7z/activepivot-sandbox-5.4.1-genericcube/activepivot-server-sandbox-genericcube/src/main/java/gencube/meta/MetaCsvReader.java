package gencube.meta;

import com.qfs.logging.MessagesSandbox;
import com.quartetfs.fwk.QuartetRuntimeException;
import gencube.csv.CsvConfigHelper;
import gencube.meta.model.HierarchyData;
import gencube.meta.model.MetaData;
import gencube.meta.model.MetaDataColumn;
import rmlib.typevalidator.model.CubeTypes;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MetaCsvReader {

    public static final String SKIPLINES_DEF = "SKIPLINES_DEF";
    public static final String DATA_SEP_DEF = "DATA_SEP_DEF";
    public static final String FIELD_DEF = "FIELD_DEF";
    public static final String HIERARCHY_DEF = "HIERARCHY_DEF";
    public static final String DATA_WITH_EMPTY_SEP = "DATA_SEP_DEF||";

    protected static Logger LOGGER = MessagesSandbox.getLogger(MetaCsvReader.class);

    private void addLengthError(int nbColumnFound, int nbColumnExpected, String line, List<String> errors) {
        final String msg = "incorrect nb of columns : " + nbColumnFound + "(" + nbColumnExpected + " expected) in line : " + line;
        LOGGER.log(Level.SEVERE, msg);
        errors.add(msg);
    }

    private void addFieldTypeError(String typeFound, String line, List<String> errors) {
        final String msg = "Error with type=" + typeFound + " in line " + line;
        LOGGER.log(Level.SEVERE, msg);
        errors.add(msg);
    }

    private void addLineTypeError(String lineTypeFound, String line, List<String> errors) {
        final String msg = "Error (unknownLineType) with line=" + line;
        LOGGER.log(Level.SEVERE, msg);
        errors.add(msg);
    }

    public MetaData readMetaData(String filePath) {

        final Path path = resolvePath(filePath);
        final MetaData metaData = new MetaData();

        BufferedReader br = null;
        final String cvsSplitBy = "\\" + CsvConfigHelper.CSV_SEPARATOR;

        final List<String> errorsFound = new ArrayList<>();

        try {
            String line;
            br = new BufferedReader(new FileReader(path.toFile().getAbsoluteFile()));
            while ((line = br.readLine()) != null) {

                if(!line.startsWith("#")) {
                    final String[] values = line.split(cvsSplitBy);


                    final String lineType = values[0];

                    if(FIELD_DEF.equals(lineType)) {
                        final int expectedColumnNb = 7;
                        if(values.length >= expectedColumnNb) {
                            final MetaDataColumn metaDataColumn = new MetaDataColumn();
                            fillColumnWithFieldInfo(values, metaDataColumn);
                            if(CubeTypes.TYPES.contains(metaDataColumn.getType())) {
                                metaData.addColumn(metaDataColumn);
                            }
                            else {
                                addFieldTypeError(metaDataColumn.getType(), line, errorsFound);
                            }
                        }
                        else {
                            addLengthError(values.length , expectedColumnNb, line, errorsFound);
                        }
                    }
                    else if(HIERARCHY_DEF.equals(lineType)) {
                        final int expectedColumnNb = 5;
                        if(values.length >= expectedColumnNb) {
                            final HierarchyData hierarchyData = new HierarchyData();
                            fillColumnWithHierarchyInfo(values, hierarchyData);
                            metaData.addHierarchy(hierarchyData);
                        }
                        else {
                            addLengthError(values.length, expectedColumnNb, line, errorsFound);
                        }
                    }
                    else if(SKIPLINES_DEF.equals(lineType)) {
                        final int expectedColumnNb = 2;
                        if(sameLength(values, expectedColumnNb)) {
                            fillMetaWithLinesToSkip(metaData, values[1]);
                        }
                        else {
                            addLengthError(values.length , expectedColumnNb, line, errorsFound);
                        }
                    }
                    else if(DATA_SEP_DEF.equals(lineType)) {

                        final int expectedColumnNb = 2;
                        if(DATA_WITH_EMPTY_SEP.equals(line)) {
                            // special case
                            fillMetaWithDataSep(metaData, "|");
                        }
                        else if(sameLength(values, expectedColumnNb)) {
                            fillMetaWithDataSep(metaData, values[1]);
                        }
                        else {
                            addLengthError(values.length , expectedColumnNb, line, errorsFound);
                        }
                    }
                    else {
                        addLineTypeError(lineType, line, errorsFound);
                    }
                }
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        if(errorsFound.size()>0) {
            throw new BadMetaDataException("File " + filePath + " has bad configuration", errorsFound);
        }

        return metaData;
    }

    private void fillMetaWithDataSep(MetaData metaData, String value) {
        //DATA_SEP_DEF|char
        metaData.setDataSeparator(value);
    }

    private void fillMetaWithLinesToSkip(MetaData metaData, String value) {
        //SKIPLINES_DEF|nbSkipLines
        metaData.setLinesToSkip(Integer.parseInt(value));
    }

    private void fillColumnWithHierarchyInfo(String[] values, HierarchyData hierarchyData) {
        //HIERARCHY_DEF|dimensionName|hierarchyName|defaultHierarchy|hierarchyFolder|field list separated by comma...
        hierarchyData.setDimensionName(values[1]);
        hierarchyData.setHierarchyName(values[2]);
        hierarchyData.setDefaultHierarchy("true".equalsIgnoreCase(values[3]));
        hierarchyData.setHierarchyFolder(values[4]);
        hierarchyData.setLevelNames(Arrays.asList(values[5].split(",")));
    }

    private void fillColumnWithFieldInfo(String[] values, MetaDataColumn metaDataColumn) {
        // FIELD_DEF|levelName|type|format|displayFormat|isMeasure|allMembersEnabled(if not measure)
        metaDataColumn.setLevelName(values[1]);
        metaDataColumn.setType(values[2]);
        metaDataColumn.setFormat(values[3]);
        metaDataColumn.setDisplayFormat(values[4]);
        metaDataColumn.setMeasure("true".equalsIgnoreCase(values[5]));
        metaDataColumn.setAllMembersEnabled("true".equalsIgnoreCase(values[6]));
    }

    private boolean sameLength(String[] values, int expectedColumnNb) {
        return values.length == expectedColumnNb;
    }

    protected Path resolvePath(String path) {
        URL url = this.getClass().getClassLoader().getResource(path);
        Path p;
        if(url != null) {
            p = Paths.get(URI.create(url.toExternalForm()));
            if(p != null) {
                return p;
            }
        }

        p = Paths.get(path, new String[0]);
        if(p != null) {
            return p;
        } else {
            throw new QuartetRuntimeException("Cannot resolve path: " + path);
        }
    }
}
