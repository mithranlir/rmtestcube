package gencube.stream;

import com.qfs.logging.MessagesServer;
import com.quartetfs.biz.pivot.dto.CellSetDTO;
import com.quartetfs.biz.pivot.query.IMDXQuery;
import com.quartetfs.biz.pivot.security.IContextValueManager;
import com.quartetfs.biz.pivot.streaming.IMdxStreamIdentifier;
import com.quartetfs.biz.pivot.streaming.impl.MdxStream;
import com.quartetfs.biz.pivot.streaming.impl.MdxStreamHelper;
import com.quartetfs.fwk.QuartetException;
import com.quartetfs.pivot.mdx.result.impl.MdxCellSet;
import com.quartetfs.tech.streaming.IStreamProperties;
import com.quartetfs.tech.streaming.IStreamPublisher;

import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomMdxStream extends MdxStream {

    private static Logger logger = MessagesServer.getLogger(CustomMdxStream.class);

    public final static String PLUGIN_KEY = "MDX";

    private CellSetDTOReducer cellSetDTOReducer;

    public CustomMdxStream(IMDXQuery mdxQuery, IStreamProperties properties, IStreamPublisher publisher) {
        super(mdxQuery, properties, publisher);
        cellSetDTOReducer = new CellSetDTOReducer();
    }

    public void setContextValueManager(IContextValueManager contextValueManager) {
        this.cellSetDTOReducer.setContextValueManager(contextValueManager);
    }

    @Override
    protected synchronized void restart(State streamState, IMDXQuery previousQuery) throws QuartetException {
        if(streamState != State.PAUSED && streamState != State.STARTED) {
            throw new QuartetException("activepivot-server", "EXC_UNEXP_STATE", new Object[]{streamState});
        } else {
            this.unsubscribe();
            long start = System.nanoTime();
            if((this.query).getContent() != null && (this.query).getContent().length() > 0) {
                final IMdxStreamIdentifier duration = this.getOrCreateIdentifier();
                if(streamState == State.STARTED) {
                    this.pivot = duration.getContinuouslyQueryable();
                    this.mdxStreamRegister.subscribe(this);
                }
                else {
                    final MdxCellSet cellSet = MdxStreamHelper.executeContextually(this.activePivotManager, this.query, duration);
                    if(cellSet != null) {
                        this.pivot = this.activePivotManager.getActivePivots().get(cellSet.getCube());
                        final CellSetDTO cellSetDTO = MdxStreamHelper.convertToCellSetDTOAndUpdate(cellSet, ((IMDXQuery) this.query).getCellsOnly(), this.cellsState);
                        final CellSetDTO limitedCellSetDTO = cellSetDTOReducer.getLimitedCellSetDTO(cellSetDTO, this.query);
                        this.publishCellSetDTO(cellSet.getEpoch(), limitedCellSetDTO, this.pivot.getId());
                    }
                }
            }

            if(logger.isLoggable(Level.FINEST)) {
                long duration1 = System.nanoTime() - start;
                double elapseInMSeconds = (double)duration1 / 1000000.0D;
                String queryString = (this.query).toString().replace(System.lineSeparator(), " ");
                logger.log(Level.FINEST, "DEB_RESTART_TIME", new Object[]{this, Double.valueOf(elapseInMSeconds), queryString});
            }
        }
    }

}
