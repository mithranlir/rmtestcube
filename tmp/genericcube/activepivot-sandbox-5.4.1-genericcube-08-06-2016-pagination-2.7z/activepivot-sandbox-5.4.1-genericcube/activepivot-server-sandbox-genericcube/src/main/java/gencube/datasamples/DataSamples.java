package gencube.datasamples;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataSamples {

    private Map<Integer, List<String>> samplesMap = new HashMap<>();
    private boolean separatorError;

    public Map<Integer, List<String>> getSamplesMap() {
        return samplesMap;
    }

    public void setSamplesMap(Map<Integer, List<String>> samplesMap) {
        this.samplesMap = samplesMap;
    }

    public boolean isSeparatorError() {
        return separatorError;
    }

    public void setSeparatorError(boolean separatorError) {
        this.separatorError = separatorError;
    }
}
