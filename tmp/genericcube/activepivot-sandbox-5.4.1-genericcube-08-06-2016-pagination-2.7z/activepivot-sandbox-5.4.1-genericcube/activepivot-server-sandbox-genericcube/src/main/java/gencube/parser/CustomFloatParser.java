package gencube.parser;

import com.quartetfs.fwk.format.impl.FloatParser;
import javolution.text.TypeFormat;

import java.util.Locale;

public class CustomFloatParser extends CustomNumberParser<Float>  {

    public static final String KEY = "CustomFloat";

    public CustomFloatParser(String format) {
        super(format, new FloatParser());
    }

    @Override
    public String description() {
        return "Custom Float Parser";
    }

    @Override
    public Object key() {
        return KEY;
    }

    @Override
    protected Float defaultValue() {
        return new Float(0);
    }

    @Override
    protected Float parseValue(String value) {
        return TypeFormat.parseFloat(value);
    }

    @Override
    protected String normalizeValue(String value) {
        return normalizeValueIfFrenchSep(value);
    }

}
