package gencube.web.combo;

import gencube.web.combo.select.AbstractSelectValue;

public class StringKeySelectValue extends AbstractSelectValue<String> {
    public StringKeySelectValue(String value) {
        super(value);
    }
}
