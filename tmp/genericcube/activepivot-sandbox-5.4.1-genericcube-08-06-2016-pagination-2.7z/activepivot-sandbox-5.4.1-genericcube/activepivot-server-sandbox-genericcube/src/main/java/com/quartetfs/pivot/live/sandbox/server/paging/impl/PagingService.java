package com.quartetfs.pivot.live.sandbox.server.paging.impl;

import com.quartetfs.biz.pivot.security.IContextValueManager;
import com.quartetfs.pivot.live.sandbox.server.paging.IPagingService;
import gencube.context.IResultSizeCV;
import gencube.context.impl.ResultSizeCV;

public class PagingService implements IPagingService {

    public static final String RESULT_SIZE_KEY = "resultSize";
    private IContextValueManager contextValueManager;

    public PagingService(IContextValueManager contextValueManager) {
        this.contextValueManager = contextValueManager;
    }

    @Override
    public Long getResultSize() {
        final IResultSizeCV cv = contextValueManager.getContextValue(RESULT_SIZE_KEY, IResultSizeCV.class);
        if(cv == null) {
            return null;
        }
        return cv.getResultSize();
    }


    public void setResultSize(Long resultSize) {
        contextValueManager.setContextValue(RESULT_SIZE_KEY, new ResultSizeCV(resultSize));
    }
}
