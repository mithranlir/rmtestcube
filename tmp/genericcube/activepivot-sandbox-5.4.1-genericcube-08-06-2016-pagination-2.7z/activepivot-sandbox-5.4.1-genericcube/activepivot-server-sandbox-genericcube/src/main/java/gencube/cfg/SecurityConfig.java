/*
 * (C) Quartet FS 2012-2016
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package gencube.cfg;

import com.qfs.content.cfg.impl.ContentServerRestServicesConfig;
import com.qfs.pivot.servlet.impl.ContextValueFilter;
import com.qfs.sandbox.cfg.impl.ASecurityConfig;
import com.qfs.server.cfg.IActivePivotConfig;
import com.qfs.snl.agent.service.ISentinelDaemonActions;
import com.qfs.snl.cfg.activepivot.impl.SentinelAPExtensionServiceConfiguration;
import com.quartetfs.biz.pivot.security.IUserDetailsService;
import com.quartetfs.biz.pivot.security.impl.UserDetailsServiceWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.authentication.switchuser.SwitchUserFilter;

import static com.qfs.server.cfg.impl.ActivePivotRemotingServicesConfig.*;
import static com.qfs.server.cfg.impl.ActivePivotRestServicesConfig.REST_API_URL_PREFIX;
import static com.qfs.server.cfg.impl.ActivePivotServicesConfig.*;
import static com.qfs.server.cfg.impl.CxfServletConfig.CXF_WEB_SERVICES;

/**
 * Spring configuration fragment for security.
 *
 * @author Quartet FS
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends ASecurityConfig {

	public static final String COOKIE_NAME = "AP_JSESSIONID";

	/**
	 * User details service wrapped into a Quartet interface.
	 * <p>
	 * This bean is used by {@link SentinelAPExtensionServiceConfiguration}
	 *
	 * @return a user details service
	 */
	@Bean
	public IUserDetailsService qfsUserDetailsService() {
		return new UserDetailsServiceWrapper(userDetailsService());
	}

	/**
	 * To expose the login page of Live 4.
	 */
	@Configuration
	@Order(1)
	// Must be done before ActivePivotSecurityConfigurer (because they match common URLs)
	public static class LiveSecurityConfigurer extends AWebSecurityConfigurer {

		@Override
		protected void doConfigure(HttpSecurity http) throws Exception {
			final String url = "/live/**";

			http
					// Only theses URLs must by handled by this HttpSecurity
					.antMatcher(url)
					.authorizeRequests()
					// The order of the matchers matters
					.antMatchers(HttpMethod.OPTIONS, url).permitAll()
					.antMatchers(HttpMethod.GET, url).permitAll();

			// Authorizing pages to be embedded in iframes to have ActivePivot Live in Sentinel UI
			http.headers().frameOptions().disable();
		}

	}

	/**
	 * Only required if Live 4 use the embedded content server.
	 * <p>
	 * Separated from {@link ActivePivotSecurityConfigurer} to skip the {@link ContextValueFilter}.
	 */
	@Configuration
	@Order(2)
	// Must be done before ActivePivotSecurityConfigurer (because they match common URLs)
	public static class JwtSecurityConfigurer extends AJwtSecurityConfigurer {
	}

	@Configuration
	@Order(3)
	// Must be done before ActivePivotSecurityConfigurer (because they match common URLs)
	public static class ContentServerSecurityConfigurer extends AWebSecurityConfigurer {

		@Override
		protected void doConfigure(HttpSecurity http) throws Exception {

			final String url = ContentServerRestServicesConfig.NAMESPACE;

			http
					// Only theses URLs must by handled by this HttpSecurity
					.antMatcher(url + "/**")
					.authorizeRequests()
					// The order of the matchers matters
					.antMatchers(HttpMethod.OPTIONS, ContentServerRestServicesConfig.REST_API_URL_PREFIX + "/**").permitAll()
					.antMatchers(url + "/**").hasAuthority(ROLE_USER)
					.and().httpBasic();
		}
	}

	@Configuration
	public static class ActivePivotSecurityConfigurer extends AWebSecurityConfigurer {

		@Autowired
		protected IActivePivotConfig activePivotConfig;

		public ActivePivotSecurityConfigurer() {
			super(COOKIE_NAME);
		}

		@Override
		protected void doConfigure(HttpSecurity http) throws Exception {

			//http.headers().defaultsDisabled().addHeaderWriter(createFrameAllow()).and()
			configureFrameAllow(http.headers()).and()
					.authorizeRequests()
					// The order of the matchers matters
					.antMatchers(HttpMethod.OPTIONS, REST_API_URL_PREFIX + "/**").permitAll()
					// Web services used by AP live 3.4
					.antMatchers(CXF_WEB_SERVICES + '/' + ID_GENERATOR_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					.antMatchers(CXF_WEB_SERVICES + '/' + LONG_POLLING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					.antMatchers(CXF_WEB_SERVICES + '/' + LICENSING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					// Spring remoting services used by AP live 3.4
					.antMatchers(ID_GENERATOR_REMOTING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					.antMatchers(LONG_POLLING_REMOTING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					.antMatchers(LICENSING_REMOTING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					// REST services
					.antMatchers(REST_API_URL_PREFIX + "/**").hasAnyAuthority(ROLE_USER, ISentinelDaemonActions.SENTINEL_ROLE)
					// One has to be a user for all the other URLs
					.antMatchers("/**").hasAuthority(ROLE_USER)
					.and().httpBasic()
					// SwitchUserFilter is the last filter in the chain. See FilterComparator class.
					.and().addFilterAfter(activePivotConfig.contextValueFilter(), SwitchUserFilter.class);
		}

		@Bean(name = BeanIds.AUTHENTICATION_MANAGER)
		@Override
		public AuthenticationManager authenticationManagerBean() throws Exception {
			return super.authenticationManagerBean();
		}

	}

}
