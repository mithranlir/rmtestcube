package gencube.loadinghistory;

import gencube.csv.CustomCSVSource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class FileLoadingHistoryService {

    private Map<String, LoadingErrorLogWriter> loadingLoadingErrorLogWriterMap = new HashMap<>();
    private Map<String, LoadingProgressReader> loadingProgressReaderMap = new HashMap<>();
    private CopyOnWriteArrayList<FileLoading> fileLoadingHistory = new CopyOnWriteArrayList<>();

    public void start(final FileLoading fileLoading, String logFileDir, CustomCSVSource csvSource) {

        final LoadingErrorLogWriter loadingErrorLogWriter = new LoadingErrorLogWriter(fileLoading, logFileDir);
        loadingErrorLogWriter.start();
        loadingLoadingErrorLogWriterMap.put(fileLoading.getDataFileName(), loadingErrorLogWriter);

        final LoadingProgressReader loadingProgressReader = new LoadingProgressReader(fileLoading, csvSource);
        loadingProgressReaderMap.put(fileLoading.getDataFileName(), loadingProgressReader);

        fileLoadingHistory.add(0, fileLoading); // descendant order...
    }

    public void addError(FileLoadingError fileLoadingError) {
        final LoadingErrorLogWriter loadingErrorLogWriter = loadingLoadingErrorLogWriterMap.get(fileLoadingError.getFileName());
        loadingErrorLogWriter.addError(fileLoadingError);
    }

    public void stop(final FileLoading fileLoading) {

        final LoadingErrorLogWriter loadingErrorLogWriter = loadingLoadingErrorLogWriterMap.get(fileLoading.getDataFileName());
        loadingErrorLogWriter.stop();
        loadingLoadingErrorLogWriterMap.remove(fileLoading.getDataFileName());

        final LoadingProgressReader loadingProgressReader = loadingProgressReaderMap.get(fileLoading.getDataFileName());
        loadingProgressReader.stop();
        loadingProgressReaderMap.remove(fileLoading.getDataFileName());
    }

    public List<FileLoading> getFileLoadingHistory() {
        return fileLoadingHistory;
    }

    public void stopAll() {
        for(LoadingErrorLogWriter writer : loadingLoadingErrorLogWriterMap.values()) {
            writer.stop();
        }
    }

}
