package gencube.web.combo.select;

import java.util.Map;

public interface ISelectValue<T> {
    String getValue();
    Map<T, Boolean> getSelectedMap();
}
