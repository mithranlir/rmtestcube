package gencube.web.helper;

import gencube.meta.model.HierarchyData;
import gencube.meta.model.MetaDataColumn;
import gencube.web.combo.IntKeySelectValue;
import gencube.web.combo.StringKeySelectValue;
import gencube.web.combo.StringKeySelectValueBuilder;
import gencube.web.combo.IntKeySelectValueBuilder;
import gencube.web.combo.select.ISelectValue;
import gencube.web.form.ColumnForm;
import gencube.web.form.HierarchyForm;

import java.util.Arrays;
import java.util.List;

public class ColumnDataSelectHelper {

    public static List<String> getTrueFalseValues() {
        return Arrays.asList("true","false");
    }

    public static List<String> getFalseTrueValues() {
        return Arrays.asList("false", "true");
    }

    public interface ValueGetter<T> {
        String getValue(T column);
    }

    public interface ValueGetter2<T, U> {
        String getValue(T column, U index);
    }

    public static List<ISelectValue<Integer>> getValuesWithIntKey(ColumnForm columnForm, List<String> valueList, ValueGetter<MetaDataColumn> valueGetter) {
        final IntKeySelectValueBuilder selectValueBuilder = new IntKeySelectValueBuilder(valueList);
        if(columnForm!=null) {
            for (int i = 0; i < columnForm.getColumns().size(); i++) {
                final MetaDataColumn column = columnForm.getColumns().get(i);
                selectValueBuilder.add(i, valueGetter.getValue(column));
            }
        }
        return selectValueBuilder.build();
    }

    public static List<ISelectValue<Integer>> getValuesWithIntKey(HierarchyForm hierarchyForm, List<String> valueList, ValueGetter<HierarchyData> valueGetter) {
        final IntKeySelectValueBuilder selectValueBuilder = new IntKeySelectValueBuilder(valueList);
        if(hierarchyForm!=null) {
            for (int i = 0; i < hierarchyForm.getHierarchies().size(); i++) {
                final HierarchyData hierarchy = hierarchyForm.getHierarchies().get(i);
                selectValueBuilder.add(i, valueGetter.getValue(hierarchy));
            }
        }
        return selectValueBuilder.build();
    }

    public static List<ISelectValue<String>> getValuesWithStringKey(HierarchyForm hierarchyForm, List<String> valueList, ValueGetter2<HierarchyData, Integer> valueGetter) {
        final StringKeySelectValueBuilder selectValueBuilder = new StringKeySelectValueBuilder(valueList);
        if(hierarchyForm!=null) {
            for (int i = 0; i < hierarchyForm.getHierarchies().size(); i++) {
                final HierarchyData hierarchy = hierarchyForm.getHierarchies().get(i);
                for (int j = 0; i < hierarchy.getLevelNames().size(); i++) {
                    selectValueBuilder.add(i + "_" + j, valueGetter.getValue(hierarchy, j));
                }
            }
        }
        return selectValueBuilder.build();
    }

    public static List<ISelectValue<String>> getValuesFromStringList(String selectedValue, List<String> valueList) {
        final StringKeySelectValueBuilder selectValueBuilder = new StringKeySelectValueBuilder(valueList);
        if(selectedValue!=null) {
           selectValueBuilder.add("selected", selectedValue);
        }
        return selectValueBuilder.build();
    }

    public static ValueGetter<MetaDataColumn> getValueGetterForFormat() {
        return new ValueGetter<MetaDataColumn>() {
            @Override
            public String getValue(MetaDataColumn column) {
                return column.getFormat();
            }
        };
    }

    public static ValueGetter<MetaDataColumn> getValueGetterForDisplayFormat() {
        return new ValueGetter<MetaDataColumn>() {
            @Override
            public String getValue(MetaDataColumn column) {
                return column.getDisplayFormat();
            }
        };
    }

    public static ValueGetter<MetaDataColumn> getValueGetterForType() {
        return new ValueGetter<MetaDataColumn>() {
            @Override
            public String getValue(MetaDataColumn column) {
                return column.getType();
            }
        };
    }

    public static ValueGetter<MetaDataColumn> getValueGetterForMeasure() {
        return new ValueGetter<MetaDataColumn>() {
            @Override
            public String getValue(MetaDataColumn column) {
                return column.getMeasure() + "";
            }
        };
    }

    public static ValueGetter<MetaDataColumn> getValueGetterForAllMembersEnabled() {
        return new ValueGetter<MetaDataColumn>() {
            @Override
            public String getValue(MetaDataColumn column) {
                return column.getAllMembersEnabled() + "";
            }
        };
    }

    public static ValueGetter<HierarchyData> getValueGetterForDefaultHierarchy() {
        return new ValueGetter<HierarchyData>() {
            @Override
            public String getValue(HierarchyData column) {
                return column.getDefaultHierarchy() + "";
            }
        };
    }

    public static ValueGetter2<HierarchyData, Integer> getValueGetterForLevel() {
        return new ValueGetter2<HierarchyData, Integer>() {
            @Override
            public String getValue(HierarchyData column, Integer index) {
                return column.getLevelNames().get(index);
            }
        };
    }

}
