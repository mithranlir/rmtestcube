package gencube.web.action;

import gencube.meta.model.HierarchyData;
import gencube.web.form.HierarchyForm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HierarchyActionProcessor {

    public static final String ADD_DIM = "addDim";
    public static final String ADD_HIER = "addHier";
    public static final String ADD_LEVEL = "addLevel";
    public static final String DEL_DIM = "delDim";
    public static final String DEL_HIER = "delHier";
    public static final String DEL_LEVEL = "delLevel";
    public static final String MOVE_UP_DIM = "moveUpDim";
    public static final String MOVE_DOWN_DIM = "moveDownDim";
    public static final String MOVE_UP_HIER = "moveUpHier";
    public static final String MOVE_DOWN_HIER = "moveDownHier";

    public void applyAction(HierarchyForm hierarchyForm) {
        if(ADD_DIM.equals(hierarchyForm.getActionName())) {
            final HierarchyData hierarchyData = new HierarchyData();
            hierarchyData.setDimensionName("");
            hierarchyData.setHierarchyName("");
            hierarchyForm.getHierarchies().add(hierarchyData);
        }
        else if(ADD_HIER.equals(hierarchyForm.getActionName())) {
            final int position = Integer.parseInt(hierarchyForm.getPosition());
            final HierarchyData currentHierarchyData = hierarchyForm.getHierarchies().get(position);
            final HierarchyData hierarchyData = new HierarchyData();
            hierarchyData.setDimensionName(currentHierarchyData.getDimensionName());
            hierarchyData.getLevelNames().add("");
            final int positionNewHierarchy = position + 1;
            if(positionNewHierarchy >= hierarchyForm.getHierarchies().size()) {
                hierarchyForm.getHierarchies().add(hierarchyData);
            }
            else {
                hierarchyForm.getHierarchies().add(positionNewHierarchy, hierarchyData);
            }
        }
        else if(ADD_LEVEL.equals(hierarchyForm.getActionName())) {
            final int position = Integer.parseInt(hierarchyForm.getPosition());
            final HierarchyData currentHierarchyData = hierarchyForm.getHierarchies().get(position);
            currentHierarchyData.getLevelNames().add("");
        }
        else if(DEL_DIM.equals(hierarchyForm.getActionName())) {
            final int position = Integer.parseInt(hierarchyForm.getPosition());
            final int nbLinesWithSameDim = getNbLinesWithSameDim(position, hierarchyForm);
            for(int i=0; i<nbLinesWithSameDim && position<hierarchyForm.getHierarchies().size(); i++) {
                hierarchyForm.getHierarchies().remove(position);
            }
        }
        else if(DEL_HIER.equals(hierarchyForm.getActionName())) {
            final int position = Integer.parseInt(hierarchyForm.getPosition());
            hierarchyForm.getHierarchies().remove(position);
        }
        else if(DEL_LEVEL.equals(hierarchyForm.getActionName())) {
            final int position = Integer.parseInt(hierarchyForm.getPosition());
            final HierarchyData currentHierarchyData = hierarchyForm.getHierarchies().get(position);
            currentHierarchyData.getLevelNames().remove(currentHierarchyData.getLevelNames().size() - 1);
        }
        else if(MOVE_UP_DIM.equals(hierarchyForm.getActionName())) {
            final int position = Integer.parseInt(hierarchyForm.getPosition());
            final int nbLinesWithSameDim = getNbLinesWithSameDim(position, hierarchyForm);
            final List<HierarchyData> movedDataList =
                    removeDataFromList(hierarchyForm, position, nbLinesWithSameDim);
            final int firstPositionfPreviousDim =
                    getFirstPositionOfPreviousDim(position, hierarchyForm);
            insertDataInList(hierarchyForm, movedDataList, firstPositionfPreviousDim);
        }
        else if(MOVE_DOWN_DIM.equals(hierarchyForm.getActionName())) {
            final int position = Integer.parseInt(hierarchyForm.getPosition());
            final int nbLinesWithSameDim = getNbLinesWithSameDim(position, hierarchyForm);
            final List<HierarchyData> movedDataList =
                    removeDataFromList(hierarchyForm, position, nbLinesWithSameDim);
            final int nbLinesWithSameNextDim =
                    getNbLinesWithSameDim(position, hierarchyForm);
            final int nextNextDimensionPosition = position + nbLinesWithSameNextDim;
            insertDataInList(hierarchyForm, movedDataList, nextNextDimensionPosition);
        }
        else if(MOVE_UP_HIER.equals(hierarchyForm.getActionName())) {
            final int position = Integer.parseInt(hierarchyForm.getPosition());
            final int previousPosition = position - 1;
            Collections.swap(hierarchyForm.getHierarchies(), position, previousPosition);
        }
        else if(MOVE_DOWN_HIER.equals(hierarchyForm.getActionName())) {
            final int position = Integer.parseInt(hierarchyForm.getPosition());
            final int nextPosition = position + 1;
            Collections.swap(hierarchyForm.getHierarchies(), position, nextPosition);
        }
    }

    private void insertDataInList(HierarchyForm hierarchyForm, List<HierarchyData> movedDataList, int position) {
        Collections.reverse(movedDataList);
        for(HierarchyData dataToInsert : movedDataList) {
            hierarchyForm.getHierarchies().add(position, dataToInsert);
        }
    }

    private List<HierarchyData> removeDataFromList(HierarchyForm hierarchyForm, int position, int nbLinesWithSameDim) {
        final List<HierarchyData> movedDataList = new ArrayList<>();
        for(int i=0; i<nbLinesWithSameDim && position<hierarchyForm.getHierarchies().size(); i++) {
            final HierarchyData movedData = hierarchyForm.getHierarchies().remove(position);
            movedDataList.add(movedData);
        }
        return movedDataList;
    }

    private int getFirstPositionOfPreviousDim(int currentPosition, HierarchyForm hierarchyForm) {
        boolean previousDimNameFound = false;
        String previousDimName = null;
        int previousDimPos = 0;
        for(int i=currentPosition-1; i>=0; i--) {
            final HierarchyData hierarchyData = hierarchyForm.getHierarchies().get(i);
            if(!previousDimNameFound) {
                previousDimNameFound = true;
                previousDimName = hierarchyData.getDimensionName();
            }
            else if(previousDimNameFound && hierarchyData.getDimensionName().equals(previousDimName)) {
                previousDimPos = i;
            }
            else {
                break;
            }
        }
        return previousDimPos;
    }

    private int getNbLinesWithSameDim(int currentPosition, HierarchyForm hierarchyForm) {
        final HierarchyData currentHierarchyData = hierarchyForm.getHierarchies().get(currentPosition);
        int cpt = 1;
        for(int i = currentPosition+1; i<hierarchyForm.getHierarchies().size(); i++) {
            final HierarchyData hierarchyData = hierarchyForm.getHierarchies().get(i);
            if(currentHierarchyData.getDimensionName().equals(hierarchyData.getDimensionName())) {
                cpt++;
            }
            else {
                break;
            }
        }
        return cpt;
    }
}
