package gencube.cfg;

import com.qfs.pivot.servlet.impl.ContextValueFilter;
import com.qfs.sandbox.cfg.impl.ASecurityConfig;
import com.qfs.security.cfg.ICorsFilterConfig;
import com.qfs.server.cfg.impl.JwtRestServiceConfig;
import com.qfs.snl.agent.service.ISentinelDaemonActions;
import com.quartetfs.biz.pivot.security.IUserDetailsService;
import com.quartetfs.biz.pivot.security.impl.UserDetailsServiceWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.authentication.switchuser.SwitchUserFilter;
import org.springframework.security.web.context.SecurityContextPersistenceFilter;

import javax.servlet.Filter;

import static com.qfs.server.cfg.impl.ActivePivotRemotingServicesConfig.*;
import static com.qfs.server.cfg.impl.ActivePivotRestServicesConfig.REST_API_URL_PREFIX;
import static com.qfs.server.cfg.impl.ActivePivotServicesConfig.*;
import static com.qfs.server.cfg.impl.CxfServletConfig.CXF_WEB_SERVICES;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends ASecurityConfig {

	public static final String COOKIE_NAME = "AP_JSESSIONID";

	public static boolean disableDefaults = false;

	@Bean
	public IUserDetailsService qfsUserDetailsService() {
		return new UserDetailsServiceWrapper(userDetailsService());
	}

	/**
	 * To expose the login page of Live 4.
	 */
	@Configuration
	@Order(1)
	// Must be done before ActivePivotSecurityConfigurer (because they match common URLs)
	public static class LiveSecurityConfigurer extends AWebSecurityConfigurer {

		public LiveSecurityConfigurer() {
			super(disableDefaults);
		}

		@Override
		protected void doConfigure(HttpSecurity http) throws Exception {
			final String url = "/live/**";

			http
					.headers().frameOptions().sameOrigin().and()

					// Only theses URLs must by handled by this HttpSecurity
					.antMatcher(url)

					.authorizeRequests()

					// The order of the matchers matters
					.antMatchers(HttpMethod.OPTIONS, url).permitAll()
					.antMatchers(HttpMethod.GET, url).permitAll();

			// Authorizing pages to be embedded in iframes to have ActivePivot Live in Sentinel UI
			//http.headers().frameOptions().disable();
		}
	}

	/**
	 * Only required if Live 4 use the embedded content server.
	 * <p>
	 * Separated from {@link ActivePivotSecurityConfigurer} to skip the ContextValueFilter.
	 */
	@Configuration
	@Order(2)
	// Must be done before ActivePivotSecurityConfigurer (because they match common URLs)
	public static class JwtSecurityConfigurer extends AJwtSecurityConfigurer {

		public JwtSecurityConfigurer() {
			super(disableDefaults);
		}

		@Override
		protected void configure(HttpSecurity http) throws Exception {

			final Filter corsFilter = context.getBean(ICorsFilterConfig.class).corsFilter();

			http
					.headers().frameOptions().sameOrigin()
					.and()

					.antMatcher(JwtRestServiceConfig.NAMESPACE + "/**")
					// As of Spring Security 4.0, CSRF protection is enabled by default.
					.csrf().disable()

					// Configure CORS
					.addFilterBefore(corsFilter, SecurityContextPersistenceFilter.class)

					.authorizeRequests()
					.antMatchers(HttpMethod.OPTIONS, "/**").permitAll()
					.antMatchers("/**").hasAnyAuthority(ROLE_USER)
					.and()
					.httpBasic();
		}
	}

	@Configuration
	public static class ActivePivotSecurityConfigurer extends AWebSecurityConfigurer {

		@Autowired
		public ContextValueFilter contextValueFilter;

		public ActivePivotSecurityConfigurer() {
			super(COOKIE_NAME, disableDefaults);
		}

		@Override
		protected void doConfigure(HttpSecurity http) throws Exception {
			http
					.authorizeRequests()
					// The order of the matchers matters
					.antMatchers(HttpMethod.OPTIONS, REST_API_URL_PREFIX + "/**").permitAll()
					// Web services used by AP live 3.4
					.antMatchers(CXF_WEB_SERVICES + '/' + ID_GENERATOR_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					.antMatchers(CXF_WEB_SERVICES + '/' + LONG_POLLING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					.antMatchers(CXF_WEB_SERVICES + '/' + LICENSING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					// Spring remoting services used by AP live 3.4
					.antMatchers(ID_GENERATOR_REMOTING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					.antMatchers(LONG_POLLING_REMOTING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					.antMatchers(LICENSING_REMOTING_SERVICE + "/**").hasAnyAuthority(ROLE_USER, ROLE_TECH)
					// REST services
					.antMatchers(REST_API_URL_PREFIX + "/**").hasAnyAuthority(ROLE_USER, ISentinelDaemonActions.SENTINEL_ROLE)
					// One has to be a user for all the other URLs
					.antMatchers("/**").hasAuthority(ROLE_USER)
					.and()
					.httpBasic()

					// SwitchUserFilter is the last filter in the chain. See FilterComparator class.
					.and().addFilterAfter(contextValueFilter, SwitchUserFilter.class);
		}

		@Bean(name = BeanIds.AUTHENTICATION_MANAGER)
		@Override
		public AuthenticationManager authenticationManagerBean() throws Exception {
			return super.authenticationManagerBean();
		}

	}


}
