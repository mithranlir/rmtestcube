

http://localhost:8080/manager/html/list
tomcat
tomcat

http://localhost:8080/aplive/ActivePivotLiveDesktop.html

http://localhost:8080/upload/welcome

-------

jetty server

http://localhost:9090/upload/welcome



http://localhost:9090/onthefly/welcome?user=user1&token=12341234