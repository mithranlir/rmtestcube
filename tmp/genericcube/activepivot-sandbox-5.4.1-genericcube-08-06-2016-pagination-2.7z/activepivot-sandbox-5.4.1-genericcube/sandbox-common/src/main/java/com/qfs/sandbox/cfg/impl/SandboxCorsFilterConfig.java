/*
 * (C) Quartet FS 2015
 * ALL RIGHTS RESERVED. This material is the CONFIDENTIAL and PROPRIETARY
 * property of Quartet Financial Systems Limited. Any unauthorized use,
 * reproduction or transfer of this material is strictly prohibited
 */
package com.qfs.sandbox.cfg.impl;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.annotation.Configuration;

import com.qfs.security.cfg.impl.ACorsFilterConfig;

/**
 * @author Quartet FS
 */
@Configuration
public class SandboxCorsFilterConfig extends ACorsFilterConfig {

	protected Set<String> getAllowedHeaders() {
		HashSet headers = new HashSet();
		headers.add("X-ActivePivot-Live-Version");
		headers.add("X-Frame-Options");
		if(this.getAllowCredentials()) {
			headers.addAll(Arrays.asList("Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers".split(",")));
			headers.add("Authorization");
		}

		return headers;
	}

	@Override
	public List<String> getAllowedOrigins() {
		// Should not be empty in production. Empty means allow all origins.
		// You should put the url(s) of JavaScript code which must access to ActivePivot REST services
		return Arrays.asList();
	}

}
