package org.lanyonm.playground.persistence;

import java.util.List;

import org.apache.ibatis.annotations.*;
import org.lanyonm.playground.domain.User;

@Mapper
public interface UserMapper {

	@Results({
			@Result(property = "firstName", column = "firstName"),
			@Result(property = "lastName", column = "lastName"),
			@Result(property = "email", column = "email")
	})
	@Select("SELECT id, firstName, lastName, email FROM users")
	public List<User> getAllUsers();

	@Insert("INSERT INTO users (firstName, lastName, email)  VALUES (#{firstName}, #{lastName}, #{email})")
	public int insertUser(User user);

	@Update("UPDATE users SET firstName = #{firstName}, lastName = #{lastName}, email = #{email} WHERE ID = #{id}")
	public int updateUser(User user);
}
