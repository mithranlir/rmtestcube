package org.lanyonm.playground.service;

public interface ExceptionService {

	public void startThrowingExceptions();
	public void stopThrowingExceptions();
}
