package rmlib.typevalidator;

import org.junit.Before;
import org.junit.Test;
import rmlib.typevalidator.model.CubeTypes;
import rmlib.typevalidator.model.TypeValidatorResult;
import rmlib.typevalidator.model.TypeValidatorValidResult;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static org.assertj.core.api.Assertions.assertThat;

public class TypeValidatorTest {

    private TypeValidator typeValidator;

    @Before
    public void before() throws IOException, URISyntaxException {
        typeValidator = new TypeValidator();
    }

    @Test
    public void testFindFloat() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("1000.1", "15444.1");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.FLOAT);
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDouble() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-1.7976931348623157E308", "15444.1");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DOUBLE);
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDoubleFrenchDecimal() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-1,7976931348623157E308", "15444.1");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DOUBLE);
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isTrue();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindSpaceErrorWithDouble() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-1.7976931348623157E308 ", "15444.1");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isNull();
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isTrue();
    }

    @Test
    public void testFindInt() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-1000", "15444");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.INT);
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindLong() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-104445555500", "154440000000644");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.LONG);
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindSpaceErrorWithLong() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-104445555500 ", "154440000000644");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isNull();
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isTrue();
    }

    @Test
    public void testFindString() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-10444aaaa5555500", "154440bbbb000000644");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isNull();
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindNothingBecauseString() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-10", "154440bbbb000000644");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isNull();
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindIntegerWithOneEmptyValue() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-10", "");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.INT);
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindIntgerWithOneNullValue() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-10", null);

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.INT);
        assertThat(result.getFormat()).isNull();
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }


    private void displayExample(String pattern) {
        final Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        System.out.println(sdf.format(date));
    }

    @Test
    public void testFindDate() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("2014-10-01");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo("yyyy-MM-dd");
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate2() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("2014 10 01");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo("yyyy MM dd");
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate3() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("2014/10/01");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo("yyyy/MM/dd");
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate4() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("01/10/2014");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo("dd/MM/yyyy");
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate5() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("01-10-2014");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo("dd-MM-yyyy");
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate6() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("01 10 2014");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo("dd MM yyyy");
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate7() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("23:01:10");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo("HH:mm:ss");
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate8() throws IOException, URISyntaxException, ParseException {

        final String pattern = "HH:mm:ss.SSSZ";
        displayExample(pattern);

        final List<String> values = Arrays.asList("23:01:10.259+0100");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo(pattern);
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }


    @Test
    public void testFindDate9() throws IOException, URISyntaxException, ParseException {

        final String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        displayExample(pattern);

        final List<String> values = Arrays.asList("Fri Apr 29 22:20:35 CEST 2016");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo(pattern);
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate10() throws IOException, URISyntaxException, ParseException {

        final String pattern = "EEE, dd MMM yyyy HH:mm:ss z";
        displayExample(pattern);

        final List<String> values = Arrays.asList("Fri, 29 Apr 2016 22:31:08 CEST");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo(pattern);
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate11() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ssz";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-29T22:31:54CEST");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo(pattern);
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate12() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ss";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-29T22:32:20");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo(pattern);
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate13() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-01T10:01:15.123CEST");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo(pattern);
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate14() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-29T22:32:57.418");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo(pattern);
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testFindDate15() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-29T22:34:32.772+02:00");

        final TypeValidatorResult result = typeValidator.findType(values);

        assertThat(result.getTypeFound()).isEqualTo(CubeTypes.DATE);
        assertThat(result.getFormat()).isEqualTo(pattern);
        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
    }

    @Test
    public void testValidateInteger() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-10");
        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.INT, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateFloat() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("1000.1", "15444.1");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.FLOAT, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateFloatFrenchDecimal() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("1000,1", "15444.1");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.FLOAT, null);

        assertThat(result.isDecimalSeparatorWarning()).isTrue();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDouble() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-1.7976931348623157E308", "15444.1");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DOUBLE, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateSpaceErrorWithDouble() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-1.7976931348623157E308 ", "15444.1");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DOUBLE, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isTrue();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateInteger2() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-1000", "15444");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.INT, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateLong() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-104445555500", "154440000000644");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.LONG, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateSpaceErrorWithLong() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-104445555500 ", "154440000000644");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.LONG, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isTrue();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateString() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-10444aaaa5555500", "154440bbbb000000644");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.STRING, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateString2() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-10", "154440bbbb000000644");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.STRING, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateIntegerWithOneEmptyValue() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-10", "");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.INT, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateIntegerWithOneNullValue() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("-10", null);

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.INT, null);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDate() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("2014-10-01");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, "yyyy-MM-dd");

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDateBadDate() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("2014-10/01");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, "yyyy-MM-dd");

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isTrue();
    }

    @Test
    public void testValidateDate2() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("2014 10 01");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, "yyyy MM dd");

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDate3() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("2014/10/01");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, "yyyy/MM/dd");

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDate4() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("01/10/2014");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, "dd/MM/yyyy");

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDate5() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("01-10-2014");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, "dd-MM-yyyy");

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDate6() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("01 10 2014");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, "dd MM yyyy");

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDate7() throws IOException, URISyntaxException, ParseException {

        final List<String> values = Arrays.asList("23:01:10");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, "HH:mm:ss");

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDate8() throws IOException, URISyntaxException, ParseException {

        final String pattern = "HH:mm:ss.SSSZ";
        displayExample(pattern);

        final List<String> values = Arrays.asList("23:01:10.259+0100");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, pattern);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }


    @Test
    public void testValidateDate9() throws IOException, URISyntaxException, ParseException {

        final String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        displayExample(pattern);

        final List<String> values = Arrays.asList("Fri Apr 29 22:20:35 CEST 2016");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, pattern);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();

    }

    @Test
    public void testValidateDate10() throws IOException, URISyntaxException, ParseException {

        final String pattern = "EEE, dd MMM yyyy HH:mm:ss z";
        displayExample(pattern);

        final List<String> values = Arrays.asList("Fri, 29 Apr 2016 22:31:08 CEST");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, pattern);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDate11() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ssz";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-29T22:31:54CEST");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, pattern);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();
    }

    @Test
    public void testValidateDate12() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ss";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-29T22:32:20");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, pattern);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();

    }

    @Test
    public void testValidateDate13() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-01T10:01:15.123CEST");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, pattern);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();

    }

    @Test
    public void testValidateDate14() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-29T22:32:57.418");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, pattern);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();

    }

    @Test
    public void testValidateDate15() throws IOException, URISyntaxException, ParseException {

        final String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
        displayExample(pattern);

        final List<String> values = Arrays.asList("2016-04-29T22:34:32.772+02:00");

        final TypeValidatorValidResult result = typeValidator.valid(values, CubeTypes.DATE, pattern);

        assertThat(result.isDecimalSeparatorWarning()).isFalse();
        assertThat(result.isSpaceFoundError()).isFalse();
        assertThat(result.isInvalidDateFormat()).isFalse();

    }

}