package rmlib.typevalidator.model;

import com.google.common.collect.ImmutableList;

import java.util.List;

public class CubeTypes {

    public static final String STRING = "string";
    public static final String BOOLEAN = "boolean";
    public static final String INT = "int";
    public static final String LONG = "long";
    public static final String DOUBLE = "double";
    public static final String FLOAT = "float";
    public static final String DATE = "date";

    public static List<String> TYPES = ImmutableList.of(STRING, BOOLEAN, INT, LONG, DOUBLE, FLOAT, DATE);

    public static List<String> NUMBER_TYPES = ImmutableList.of(INT, LONG, DOUBLE, FLOAT);

    public static List<String> DECIMAL_TYPES = ImmutableList.of(DOUBLE, FLOAT);


}
