package rmlib.typevalidator.helper;

import rmlib.typevalidator.model.CubeTypes;

public class TypePriorityHelper {

    public static String chooseBetweenTypes(String type1, String type2) {
        if(TypePriorityHelper.getPriority(type1) > TypePriorityHelper.getPriority(type2)) {
            return type1;
        }
        return type2;
    }


    public static int getPriority(String type) {
        if(CubeTypes.LONG.equals(type)) {
            return 4;
        }
        else if(CubeTypes.INT.equals(type)) {
            return 3;
        }
        else if(CubeTypes.DOUBLE.equals(type)) {
            return 2;
        }
        else if(CubeTypes.FLOAT.equals(type)) {
            return 1;
        }
        return 0;
    }
}
