package rmlib.typevalidator.model;


public class TypeValidationCtx {

    private boolean allFoundNumberNotDecimal = true;
    private boolean allFoundNumberDecimal = true;
    private boolean allFoundDate = true;
    private boolean allFoundBoolean = true;

    private String dateFormatFound = null;
    private String decimalType = null;
    private String noDecimalType = null;

    private boolean spaceError = false;
    private boolean decimalSeparatorWarning = false;

    public boolean isAllFoundNumber() {
        return isAllFoundNumberNotDecimal() || isAllFoundNumberDecimal();
    }

    public boolean isAllFoundNumberDecimalAndNotDecimal() {
        return isAllFoundNumberNotDecimal() && isAllFoundNumberDecimal();
    }

    public boolean isAllFoundNumberNotDecimal() {
        return allFoundNumberNotDecimal;
    }

    public void setAllFoundNumberNotDecimal(boolean allFoundNumberNotDecimal) {
        this.allFoundNumberNotDecimal = allFoundNumberNotDecimal;
    }

    public boolean isAllFoundNumberDecimal() {
        return allFoundNumberDecimal;
    }

    public void setAllFoundNumberDecimal(boolean allFoundNumberDecimal) {
        this.allFoundNumberDecimal = allFoundNumberDecimal;
    }

    public boolean isAllFoundDate() {
        return allFoundDate;
    }

    public void setAllFoundDate(boolean allFoundDate) {
        this.allFoundDate = allFoundDate;
    }


    public boolean isAllFoundBoolean() {
        return allFoundBoolean;
    }

    public void setAllFoundBoolean(boolean allFoundBoolean) {
        this.allFoundBoolean = allFoundBoolean;
    }

    public String getDateFormatFound() {
        return dateFormatFound;
    }

    public void setDateFormatFound(String dateFormatFound) {
        this.dateFormatFound = dateFormatFound;
    }

    public String getDecimalType() {
        return decimalType;
    }

    public void setDecimalType(String decimalType) {
        this.decimalType = decimalType;
    }

    public String getNoDecimalType() {
        return noDecimalType;
    }

    public void setNoDecimalType(String noDecimalType) {
        this.noDecimalType = noDecimalType;
    }

    public boolean isSpaceError() {
        return spaceError;
    }

    public void setSpaceError(boolean spaceError) {
        this.spaceError = spaceError;
    }

    public boolean isDecimalSeparatorWarning() {
        return decimalSeparatorWarning;
    }

    public void setDecimalSeparatorWarning(boolean decimalSeparatorWarning) {
        this.decimalSeparatorWarning = decimalSeparatorWarning;
    }

}
