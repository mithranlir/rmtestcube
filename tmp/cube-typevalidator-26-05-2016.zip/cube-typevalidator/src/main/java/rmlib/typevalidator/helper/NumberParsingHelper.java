package rmlib.typevalidator.helper;

import javolution.text.TypeFormat;
import org.apache.commons.validator.GenericTypeValidator;
import org.apache.commons.validator.GenericValidator;

import java.util.Locale;

public class NumberParsingHelper {

    public static final String DECIMAL_SEP = ".";
    public static final String FRENCH_DECIMAL_SEP = ",";
    public static final String NUMBER_SPACE_REGEX = "(\\-?)[0-9E\\" + DECIMAL_SEP + " ]+";

    public static boolean isNumberWithSpace(String value) {
        return value.matches(NUMBER_SPACE_REGEX);
    }

    public static String replaceFrenchDecimalSepWithDecimalSep(String value) {
        return value.replaceAll(FRENCH_DECIMAL_SEP, DECIMAL_SEP);
    }

    public static boolean containsFrenchSep(String value) {
        return value.contains(FRENCH_DECIMAL_SEP);
    }

    public static String removeSpace(String value) {
        return value.replaceAll(" ", "");
    }

    public static boolean isInteger(String value) {
        try {
            TypeFormat.parseInt(value);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static boolean isLong(String value) {
        try {
            TypeFormat.parseLong(value);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static boolean isDouble(String value) {
        try {
            TypeFormat.parseDouble(value);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static boolean isFloat(String value) {
        boolean isDouble = isDouble(value);
        if(isDouble && GenericTypeValidator.formatFloat(value, Locale.US)!=null) { // because TypeFormat.parseFloat is a double value casted to float
            return true;
        }
        return false;
    }

    public static boolean isFrenchDouble(String value) {
        if (containsFrenchSep(value)) {
            value = replaceFrenchDecimalSepWithDecimalSep(value);
            return isDouble(value);
        }
        return false;
    }

    public static boolean isFrenchFloat(String value) {
        if (containsFrenchSep(value)) {
            value = replaceFrenchDecimalSepWithDecimalSep(value);
            return isFloat(value);
        }
        return false;
    }


}