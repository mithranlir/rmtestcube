package rmlib.typevalidator.subvalidator;

import rmlib.typevalidator.helper.SimpleLocaleFinder;
import rmlib.typevalidator.model.DateFormatResult;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DateFormatValidator {

    // fixed locale... must be reviewed later...
    private Locale locale = Locale.US;

    protected final List<String> formatList ;
    protected SimpleLocaleFinder localeFinder;

    public DateFormatValidator() throws IOException, URISyntaxException {
        localeFinder = new SimpleLocaleFinder();
        formatList = convert(readLines("dateformat.txt"));
    }

    public List<String> getFormatList() {
        return formatList;
    }

    public DateFormatResult isFormatValid(String value) {
        final DateFormatResult result = new DateFormatResult();
        for(String format : formatList) {
            if(isFormatValid(value, format)) {
                result.setValid(true);
                result.setFormat(format);
                break;
            }
        }
        return result;
    }

    public boolean isFormatValid(String value, String format) {
        try {
            parseDateStrictly(value, locale, format);
            return true;
        }
        catch(Exception e) {
        }
        return false;
    }


    public static Date parseDateStrictly(String str, Locale locale, String... parsePatterns) throws ParseException {
        return parseDateWithLeniency(str, locale, parsePatterns, false);
    }

    // taken from DateUtils.parseDateWithLeniency because private method and local not set with DateUtils.parseDateStrictly
    private static Date parseDateWithLeniency(String str, Locale locale, String[] parsePatterns, boolean lenient) throws ParseException {
        if(str != null && parsePatterns != null) {
            SimpleDateFormat parser;
            if(locale == null) {
                parser = new SimpleDateFormat();
            } else {
                parser = new SimpleDateFormat("", locale);
            }

            parser.setLenient(lenient);
            ParsePosition pos = new ParsePosition(0);
            String[] arr$ = parsePatterns;
            int len$ = parsePatterns.length;

            for(int i$ = 0; i$ < len$; ++i$) {
                String parsePattern = arr$[i$];
                String pattern = parsePattern;
                if(parsePattern.endsWith("ZZ")) {
                    pattern = parsePattern.substring(0, parsePattern.length() - 1);
                }

                parser.applyPattern(pattern);
                pos.setIndex(0);
                String str2 = str;
                if(parsePattern.endsWith("ZZ")) {
                    str2 = str.replaceAll("([-+][0-9][0-9]):([0-9][0-9])$", "$1$2");
                }

                Date date = parser.parse(str2, pos);
                if(date != null && pos.getIndex() == str2.length()) {
                    return date;
                }
            }

            throw new ParseException("Unable to parse the date: " + str, -1);
        } else {
            throw new IllegalArgumentException("Date and Patterns must not be null");
        }
    }

    protected List<String> readLines(String dateFormatFileName) {
        final List<String> lines = new ArrayList<>();
        InputStream is = null;
        BufferedReader br = null;
        InputStreamReader isr = null;
        try {
            is = this.getClass().getResourceAsStream ("/" + dateFormatFileName);
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);
            String strLine;
            while ((strLine = br.readLine()) != null) {
                lines.add(strLine);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {

            if(br!=null) {
                try {
                    br.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(isr!=null) {
                try {
                    isr.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(is!=null) {
                try {
                    is.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return lines;
    }

    protected List<String> convert(List<String> lines) {
        final List<String> formats = new ArrayList<>();
        if(lines!=null) {
            for (String line : lines) {
                final String[] values = line.split("\\|");
                formats.add(values[0]);
            }
        }
        return formats;
    }

}
