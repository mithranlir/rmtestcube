package rmlib.typevalidator.model;

public class TypeValidatorResult {

    private String typeFound;
    private String format; // for date
    private boolean decimalSeparatorWarning;
    private boolean spaceFoundError;

    public String getTypeFound() {
        return typeFound;
    }

    public void setTypeFound(String typeFound) {
        this.typeFound = typeFound;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public boolean isDecimalSeparatorWarning() {
        return decimalSeparatorWarning;
    }

    public void setDecimalSeparatorWarning(boolean decimalSeparatorWarning) {
        this.decimalSeparatorWarning = decimalSeparatorWarning;
    }

    public boolean isSpaceFoundError() {
        return spaceFoundError;
    }

    public void setSpaceFoundError(boolean spaceFoundError) {
        this.spaceFoundError = spaceFoundError;
    }
}
