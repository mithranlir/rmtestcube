package rmlib.typevalidator.helper;

import com.google.common.collect.ImmutableMap;

import java.util.Locale;
import java.util.Map;

public class SimpleLocaleFinder {

    private Map<String, Locale> constantLocaleMap;

    public SimpleLocaleFinder() {
        constantLocaleMap = ImmutableMap.<String, Locale>builder()
                .put("us", Locale.US)
                .put("fr", Locale.FRANCE)
                .build();
    }

    public Locale findLocaleConstant(String language) {
        return constantLocaleMap.get(language);
    }

}
