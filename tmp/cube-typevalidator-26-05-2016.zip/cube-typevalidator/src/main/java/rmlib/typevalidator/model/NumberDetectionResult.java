package rmlib.typevalidator.model;

public class NumberDetectionResult {

    private String decimalType;
    private String noDecimalType;
    private boolean spaceError;
    private boolean decimalSeparatorWarning;

    public String getDecimalType() {
        return decimalType;
    }

    public void setDecimalType(String decimalType) {
        this.decimalType = decimalType;
    }

    public String getNoDecimalType() {
        return noDecimalType;
    }

    public void setNoDecimalType(String noDecimalType) {
        this.noDecimalType = noDecimalType;
    }

    public boolean hasFoundATypeAsLeast() {
        return decimalType!=null || noDecimalType!=null;
    }

    public boolean isSpaceError() {
        return spaceError;
    }

    public void setSpaceError(boolean spaceError) {
        this.spaceError = spaceError;
    }

    public boolean isDecimalSeparatorWarning() {
        return decimalSeparatorWarning;
    }

    public void setDecimalSeparatorWarning(boolean decimalSeparatorWarning) {
        this.decimalSeparatorWarning = decimalSeparatorWarning;
    }
}
