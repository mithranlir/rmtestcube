package rmlib.typevalidator;

import org.apache.commons.lang3.StringUtils;
import rmlib.typevalidator.helper.TypePriorityHelper;
import rmlib.typevalidator.model.*;
import rmlib.typevalidator.subvalidator.BooleanFormatValidator;
import rmlib.typevalidator.subvalidator.DateFormatValidator;
import rmlib.typevalidator.subvalidator.NumberFormatValidator;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

import static rmlib.typevalidator.helper.TypePriorityHelper.chooseBetweenTypes;

public class TypeValidator {

    private NumberFormatValidator numberFormatValidator;
    private DateFormatValidator dateFormatValidator;
    private BooleanFormatValidator booleanFormatValidator;

    public TypeValidator() throws IOException, URISyntaxException {
        numberFormatValidator = new NumberFormatValidator();
        dateFormatValidator = new DateFormatValidator();
        booleanFormatValidator = new BooleanFormatValidator();
    }

    public TypeValidatorResult findType(List<String> sampleValues) {
        final TypeValidatorResult result = new TypeValidatorResult();
        final TypeValidationCtx ctx = new TypeValidationCtx();
        for(String sampleValue : sampleValues) {
            if(!StringUtils.isEmpty(sampleValue)) {
                processDateIfFound(sampleValue, ctx);
                processNumberIfFound(sampleValue, ctx);
                processBooleanIfFound(sampleValue, ctx);
            }
        }
        processResult(result, ctx);
        return result;
    }

    public TypeValidatorValidResult valid(List<String> sampleValues, String type, String format) {
        final TypeValidatorValidResult result = new TypeValidatorValidResult();
        if(CubeTypes.STRING.equals(format)) {
            return result;
        }
        else {
            for (String sampleValue : sampleValues) {
                if (!StringUtils.isEmpty(sampleValue)) {
                    if (CubeTypes.NUMBER_TYPES.contains(type)) {
                        processIfValueIsValidAsNumber(sampleValue, type, result);
                    }
                    else if (CubeTypes.DATE.equals(type)) {
                        processIfValueIsValidAsDate(sampleValue, format, result);
                    }
                    else if (CubeTypes.BOOLEAN.equals(type)) {
                        processIfValueIsValidAsBoolean(sampleValue, result);
                    }
                    if (hasError(result)) {
                        result.setErrorSample(sampleValue);
                        break;
                    }
                }
            }
        }
        return result;
    }

    public List<String> getDateFormatList() {
        return dateFormatValidator.getFormatList();
    }

    private boolean hasError(TypeValidatorValidResult result) {
        if(result.isSpaceFoundError()) {
            return true;
        }
        else if(result.isInvalidDateFormat()) {
            return true;
        }
        else if(result.isInvalidBooleanFormat()) {
            return true;
        }
        return false;
    }

    private void processIfValueIsValidAsDate(String sampleValue, String format, TypeValidatorValidResult result) {
        if(!dateFormatValidator.isFormatValid(sampleValue, format)) {
            result.setInvalidDateFormat(true);
        }
    }

    private void processIfValueIsValidAsBoolean(String sampleValue, TypeValidatorValidResult result) {
        if(!booleanFormatValidator.isFormatValid(sampleValue)) {
            result.setInvalidBooleanFormat(true);
        }
    }

    private void processIfValueIsValidAsNumber(String sampleValue, String type, TypeValidatorValidResult result) {
        final NumberDetectionResult numberDetectionResult =
                numberFormatValidator.isValidWithType(sampleValue, type);
        if(!numberDetectionResult.hasFoundATypeAsLeast()) {
            if(numberDetectionResult.isSpaceError()) {
                result.setSpaceFoundError(true);
            }
        }
        if(numberDetectionResult.isDecimalSeparatorWarning()) {
            result.setDecimalSeparatorWarning(true);
        }
    }

    private void processDateIfFound(String sampleValue, TypeValidationCtx validationCtx) {
        if(validationCtx.isAllFoundDate()) {
            final DateFormatResult dateFormatResult = dateFormatValidator.isFormatValid(sampleValue);
            if (!dateFormatResult.isValid()) {
                validationCtx.setAllFoundDate(false);
            }
            else {
                validationCtx.setDateFormatFound(dateFormatResult.getFormat());
            }
        }
    }

    private void processBooleanIfFound(String sampleValue, TypeValidationCtx validationCtx) {
        if(validationCtx.isAllFoundBoolean()) {
            final boolean valid = booleanFormatValidator.isFormatValid(sampleValue);
            if (!valid) {
                validationCtx.setAllFoundBoolean(false);
            }
        }
    }

    private void processNumberIfFound(String sampleValue, TypeValidationCtx validationCtx) {
        if(validationCtx.isAllFoundNumber()) {
            final NumberDetectionResult sampleResult = numberFormatValidator.findType(sampleValue);
            processWarningAndError(validationCtx, sampleResult);
            processNumberDecimal(validationCtx, sampleResult);
            processNumberNotDecimal(validationCtx, sampleResult);
        }

    }

    private void processWarningAndError(TypeValidationCtx validationCtx, NumberDetectionResult result) {
        if(result.isSpaceError()) {
            validationCtx.setSpaceError(true);
        }

        if(result.isDecimalSeparatorWarning()) {
            validationCtx.setDecimalSeparatorWarning(true);
        }
    }

    private void processNumberDecimal(TypeValidationCtx validationCtx, NumberDetectionResult result) {
        if (result.getDecimalType() == null) {
            validationCtx.setAllFoundNumberDecimal(false);
        }
        else {
            validationCtx.setDecimalType(
                    chooseBetweenTypes(
                            result.getDecimalType(), validationCtx.getDecimalType()));
        }
    }

    private void processNumberNotDecimal(TypeValidationCtx validationCtx, NumberDetectionResult result) {
        if (result.getNoDecimalType() == null) {
            validationCtx.setAllFoundNumberNotDecimal(false);
        }
        else {
            validationCtx.setNoDecimalType(
                    chooseBetweenTypes(
                            result.getNoDecimalType(), validationCtx.getNoDecimalType()));
        }
    }

    private void processResult(TypeValidatorResult result, TypeValidationCtx validationCtx) {
        if(validationCtx.isAllFoundNumber()) {
            configureWithNumberWarning(validationCtx.isDecimalSeparatorWarning(), result);
            final String numberTypeFound = getNumberTypeFound(validationCtx);
            result.setTypeFound(numberTypeFound);
        }
        else if(validationCtx.isAllFoundDate()) {
            result.setTypeFound(CubeTypes.DATE);
            result.setFormat(validationCtx.getDateFormatFound());
        }
        else if(validationCtx.isAllFoundBoolean()) {
            result.setTypeFound(CubeTypes.BOOLEAN);
        }
        else {
            // no type found...
            configureWithSpaceError(validationCtx.isSpaceError(), result);
        }
    }

    private String getNumberTypeFound(TypeValidationCtx validationCtx) {
        if (validationCtx.isAllFoundNumberDecimalAndNotDecimal()) {
           return TypePriorityHelper.chooseBetweenTypes(
                   validationCtx.getDecimalType(), validationCtx.getNoDecimalType());
        }
        else if (validationCtx.isAllFoundNumberNotDecimal()) {
            return validationCtx.getNoDecimalType();
        }
        else if(validationCtx.isAllFoundNumberDecimal()) {
            return validationCtx.getDecimalType();
        }
        return null;
    }

    private void configureWithNumberWarning(boolean decimalSeparatorWarning, TypeValidatorResult result) {
        if(decimalSeparatorWarning) {
            result.setDecimalSeparatorWarning(true);
        }
    }

    private void configureWithSpaceError(boolean spaceError, TypeValidatorResult result) {
        if(spaceError) {
            result.setSpaceFoundError(true);
        }
    }

}
