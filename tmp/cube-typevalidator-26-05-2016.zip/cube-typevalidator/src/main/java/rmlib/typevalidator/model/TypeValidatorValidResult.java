package rmlib.typevalidator.model;

public class TypeValidatorValidResult {

    private boolean decimalSeparatorWarning;
    private boolean spaceFoundError;
    private boolean invalidDateFormat;
    private boolean invalidBooleanFormat;
    private String errorSample;

    public boolean isValid() {
        return !invalidDateFormat && !spaceFoundError;
    }

    public boolean isDecimalSeparatorWarning() {
        return decimalSeparatorWarning;
    }

    public void setDecimalSeparatorWarning(boolean decimalSeparatorWarning) {
        this.decimalSeparatorWarning = decimalSeparatorWarning;
    }

    public boolean isSpaceFoundError() {
        return spaceFoundError;
    }

    public void setSpaceFoundError(boolean spaceFoundError) {
        this.spaceFoundError = spaceFoundError;
    }

    public boolean isInvalidDateFormat() {
        return invalidDateFormat;
    }

    public void setInvalidDateFormat(boolean invalidDateFormat) {
        this.invalidDateFormat = invalidDateFormat;
    }

    public boolean isInvalidBooleanFormat() {
        return invalidBooleanFormat;
    }

    public void setInvalidBooleanFormat(boolean invalidBooleanFormat) {
        this.invalidBooleanFormat = invalidBooleanFormat;
    }

    public String getErrorSample() {
        return errorSample;
    }

    public void setErrorSample(String errorSample) {
        this.errorSample = errorSample;
    }

}
