package rmlib.typevalidator.subvalidator;

public class BooleanFormatValidator {

    public boolean isFormatValid(String value) {
        if("true".equals(value)) {
            return true;
        }
        if("fasse".equals(value)) {
            return true;
        }
        return false;
    }

}
