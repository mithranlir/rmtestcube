package rmlib.typevalidator.subvalidator;

import rmlib.typevalidator.model.CubeTypes;
import rmlib.typevalidator.model.NumberDetectionResult;

import static rmlib.typevalidator.helper.NumberParsingHelper.*;

public class NumberFormatValidator {

    public NumberDetectionResult findType(String value) {
        final NumberDetectionResult result = computeTypeDetection(value);
        if(hasNoTypeAndHasSpaceInNumber(result, value)) {
            final String modified = removeSpace(value);
            final NumberDetectionResult tmpResult = computeTypeDetection(modified);
            if(tmpResult.hasFoundATypeAsLeast()) {
                result.setSpaceError(true);
            }
        }
        return result;
    }

    public NumberDetectionResult isValidWithType(String value, String type) {
        final NumberDetectionResult result = validateValueWithType(value, type);
        if(hasNoTypeAndHasSpaceInNumber(result, value)) {
            final String modified = removeSpace(value);
            final NumberDetectionResult tmpResult = validateValueWithType(modified, type);
            if(tmpResult.hasFoundATypeAsLeast()) {
                result.setSpaceError(true);
            }
        }
        return result;
    }


    private boolean hasNoTypeAndHasSpaceInNumber(NumberDetectionResult result, String value) {
        return !result.hasFoundATypeAsLeast() && isNumberWithSpace(value);
    }

    private NumberDetectionResult validateValueWithType(String value, String type) {
        final NumberDetectionResult result = new NumberDetectionResult();
        if(CubeTypes.FLOAT.equals(type)) {
            if(isFloat(value)) {
                setDecimalType(CubeTypes.FLOAT, result, false);
            }
            else if(isFrenchFloat(value)) {
                setDecimalType(CubeTypes.FLOAT, result, true);
            }
        }
        else if(CubeTypes.DOUBLE.equals(type)) {
            if(isDouble(value)) {
                setDecimalType(CubeTypes.DOUBLE, result, false);
            }
            else if(isFrenchDouble(value)) {
                setDecimalType(CubeTypes.DOUBLE, result, true);
            }
        }
        else if(CubeTypes.INT.equals(type)) {
            if(isInteger(value)) {
                result.setNoDecimalType(CubeTypes.INT);
            }
        }
        else if(CubeTypes.LONG.equals(type)) {
            if (isLong(value)) {
                result.setNoDecimalType(CubeTypes.LONG);
            }
        }

        return result;
    }

    private NumberDetectionResult computeTypeDetection(String value) {
        final NumberDetectionResult result = new NumberDetectionResult();
        fillDecimalDetection(value, result);
        fillNoDecimalDetection(value, result);
        return result;
    }

    private void fillNoDecimalDetection(String value, NumberDetectionResult result) {
        if(isInteger(value)) {
            result.setNoDecimalType(CubeTypes.INT);
        }
        else if(isLong(value)) {
            result.setNoDecimalType(CubeTypes.LONG);
        }
    }

    private void fillDecimalDetection(String value, NumberDetectionResult result) {
        if(isFloat(value)) {
            setDecimalType(CubeTypes.FLOAT, result, false);
        }
        else if(isFrenchFloat(value)) {
            setDecimalType(CubeTypes.FLOAT, result, true);
        }
        else if(isDouble(value)) {
            setDecimalType(CubeTypes.DOUBLE, result, false);
        }
        else if(isFrenchDouble(value)) {
            setDecimalType(CubeTypes.DOUBLE, result, true);
        }
    }

    private void setDecimalType(String type, NumberDetectionResult result, boolean hasDecimalSeparatorWarning) {
        result.setDecimalType(type);
        if(hasDecimalSeparatorWarning) {
            result.setDecimalSeparatorWarning(true);
        }
    }


}
