package my.web.project.dto;

public class ExtractDataRow {

    private String gop;
    private String indicator;
    private double ytd;

    public ExtractDataRow() {
    }

    public ExtractDataRow(String gop, String indicator, double ytd) {
        this.gop = gop;
        this.indicator = indicator;
        this.ytd = ytd;
    }

    public String getGop() {
        return gop;
    }

    public void setGop(String gop) {
        this.gop = gop;
    }

    public String getIndicator() {
        return indicator;
    }

    public void setIndicator(String indicator) {
        this.indicator = indicator;
    }

    public double getYtd() {
        return ytd;
    }

    public void setYtd(double ytd) {
        this.ytd = ytd;
    }

}
