package my.web.project.dto.push;

public class UserMessage {

    private String content;

    public UserMessage() {
    }

    public UserMessage(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
