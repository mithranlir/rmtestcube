package my.web.project.service;

import my.web.project.dto.push.UserMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import static my.web.project.rest.websocket.PushMessageController.QUEUE_PERSONALWARNING;

@Service
public class PersonalServiceImpl {

    private final SimpMessagingTemplate messagingTemplate;

    @Autowired
    public PersonalServiceImpl(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    public void notifyUser(String msg, String userName) {
        this.messagingTemplate.convertAndSendToUser(userName, QUEUE_PERSONALWARNING, new UserMessage(msg));
    }
}
