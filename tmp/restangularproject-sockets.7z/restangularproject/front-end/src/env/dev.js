//development setup
var config = {
	host:'localhost'
}
