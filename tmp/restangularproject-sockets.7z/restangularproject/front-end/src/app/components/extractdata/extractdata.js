angular.module('myApp.extractdata', ['agGrid', 'ngResource'])
	.controller('extractDataCtrl',['$scope', '$resource', function($scope,  $resource) {

		var columnDefs = [
			{ headerName: "gop", field: "gop" },
			{ headerName: "indicator", field: "indicator" },
			{ headerName: "ytd", field: "ytd" }
		];

		var fakeRowData = [
			{gop: "Toyota", indicator: "Celica", ytd: 35000},
			{gop: "Ford", indicator: "Mondeo", ytd: 32000},
			{gop: "Porsche", indicator: "Boxter", ytd: 72000}
		];


		$scope.gridOptions = {
			columnDefs: columnDefs,
			rowData: []
		};

		$resource('/extractdata/list', {}).get({}, function(result){
			//$scope.gridOptions.api.setRowData(angular.copy(fakeRowData));
			$scope.gridOptions.api.setRowData(angular.copy(result.rows));
		});
	}]);
