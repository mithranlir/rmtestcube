angular.module('myApp.about', [])
.controller('aboutCtrl',[function(){
	this.aboutText = 'This is the about component!';
}]);
