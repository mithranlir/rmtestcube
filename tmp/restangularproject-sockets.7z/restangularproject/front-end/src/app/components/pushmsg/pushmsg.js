angular.module('myApp.pushmsg', ['ngStomp'])
	.controller('pushMsgCtrl', ['$stomp', '$scope', function ($stomp, $scope) {

		console.log("pushMsgCtrl executed...");

		$scope.targetUserName = 'user1';

		$stomp.setDebug(function (args) {
			console.log(args);
		});

		$scope.connected = false;
		$scope.subscription = null;
		$scope.subscriptionPersonal = null;

		$scope.connectMe = function() {
			console.log("connectMe");
			var url = '/message-websocket';
			$stomp
				.connect(url, {}, function (error) {
					console.error(error);
				})
				.then(function (frame) {
					if(angular.isDefined(frame) && angular.isDefined(frame.headers)) {
						$scope.currentUserName = frame.headers['user-name'];
					}
					$scope.connected = true;
				}, function(error){
					console.error(error);
				});
		};

		$scope.subscribeMe = function() {
			var url = '/topic/messages';
			$scope.subscription = $stomp.subscribe(url, function (payload, headers, res) {
				if(angular.isDefined(payload) && payload !== null) {
					$scope.result = payload.content;
					console.log("subscribe received : " + $scope.result);
				}
				else {
					console.log("subscribe received by payload is null");
				}
			}, {});
		}

		$scope.sendMsg = function() {
			console.log("sendMsg");
			var url = '/app/chat';
			if($scope.connected) {
				$stomp.send(url, {
					content: 'coucou'
				}, {
					priority: 9,
					custom: 42 // Custom Headers
				}).then(function () {
					console.log("sendMsg done");
				}, function (reason) {
					console.log("error " + reason);
				});
			}
		};

		$scope.unsubscribeMe = function() {
			console.log("unsubscribeMe");
			if($scope.subscription !== null) {
				$scope.subscription.unsubscribe();
			}
		};

		$scope.subscribeMePersonal = function() {
			console.log("subscribeMePersonal");
			var url = '/user/queue/personalwarning';
			$scope.subscription = $stomp.subscribe(url, function (payload, headers, res) {
				if(angular.isDefined(payload) && payload !== null) {
					$scope.result = payload.content;
					console.log("subscribe received");
				}
				else {
					console.log("subscribe received by payload is null");
				}
			}, {});
		};

		$scope.sendMsgPersonal = function() {
			console.log("sendPersonalMsg");
			var targetUser = $scope.targetUserName;
			var url = '/user/' + targetUser + '/queue/personalwarning';
			console.log("url=" + url);
			if($scope.connected) {
				$stomp.send(url, {
					content: 'coucou ' + targetUser + ' de la part de ' + $scope.currentUserName
				}, {
					priority: 9,
					custom: 42 // Custom Headers
				}).then(function () {
					console.log("sendMsg done");
				}, function (reason) {
					console.log("error " + reason);
				});
			}
		};

		$scope.unsubscribeMePersonal = function() {
			console.log("unsubscribeMePersonal");
			if($scope.subscriptionPersonal !== null) {
				$scope.subscriptionPersonal.unsubscribe();
			}
		};

		$scope.disconnectMe = function() {
			console.log("disconnectMe");
			if($scope.connected) {
				$stomp.disconnect().then(function () {
					console.log("disconnected");
				}, function (reason) {
					console.log("error " + reason);
				});
			}
		};
	}]);
