angular.module('myApp.testauth', ['base64'])
.controller('testAuthCtrl',['$http', '$base64', function($http, $base64){
	var auth = $base64.encode("user1:user1");
	var url = '/hello-world';
	var headers = {"Authorization": "Basic " + auth};
	$http.get(url, {headers: headers})
		.then(function (response) {
			console.log('OK=' + JSON.stringify(response));
		}, function(response){
			console.log('ERROR=' + JSON.stringify(response));
		});
}]);
