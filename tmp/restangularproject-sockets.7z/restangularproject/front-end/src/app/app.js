require('angular');
require('angular-ui-router');
require('angular-aria');
require('angular-animate');
require('angular-material');
require('angular-resource');
require('angular-base64');
require('ng-stomp');
require('./shared/header/header.js');
require('./components/home/home.js');
require('./components/about/about.js');
require('./components/testauth/testauth.js');
require('./components/extractdata/extractdata.js');
require('./components/pushmsg/pushmsg.js');

var agGrid = require('ag-grid');
agGrid.initialiseAgGridWithAngular1(angular);

var baseDevUrl = "http://localhost:8080";

angular.module('myApp.extractdata').constant('APP_CONST', {
    baseUrl : baseDevUrl }
);

angular.module('myApp.testauth').constant('APP_CONST', {
    baseUrl : baseDevUrl }
);

var app = angular.module('myApp', ['ui.router','ngMaterial','ngResource', 'myApp.home','myApp.about','myApp.extractdata', 'myApp.testauth', 'myApp.pushmsg']);

app.config(function($stateProvider, $urlRouterProvider) {
   
    $urlRouterProvider.otherwise("/");
   
    $stateProvider
    .state('home', {
        url: "/",
        views : {
            "" : {
                templateUrl:"app/components/home/home.html"
            },
            "header@home":{
                templateUrl:"app/shared/header/header.html"
            }
        }
    })
    .state('about', {
        url: "/about",
        views : {
            "" : {
                templateUrl:"app/components/about/about.html"
            },
            "header@about":{
                templateUrl:"app/shared/header/header.html"
            }
        }
    })
    .state('testauth', {
        url: "/testauth",
        views : {
            "" : {
                templateUrl:"app/components/testauth/testauth.html"
            },
            "header@testauth":{
                templateUrl:"app/shared/header/header.html"
            }
        }
    })
    .state('extractdata', {
        url: "/extractdata",
        views : {
            "" : {
                templateUrl:"app/components/extractdata/extractdata.html"
            },
            "header@extractdata":{
                templateUrl:"app/shared/header/header.html"
            }
        }
    })
    .state('pushmsg', {
        url: "/pushmsg",
        views : {
            "" : {
                templateUrl:"app/components/pushmsg/pushmsg.html"
            },
            "header@pushmsg":{
                templateUrl:"app/shared/header/header.html"
            }
        }
    })
    ;
});
