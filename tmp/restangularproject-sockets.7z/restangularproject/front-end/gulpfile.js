var gulp = require('gulp');
var browserify = require('browserify');
var source = require('vinyl-source-stream');
var jshint = require('gulp-jshint');
var browserSync = require('browser-sync').create();
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');
var environments = require('gulp-environments');

var development = environments.development;
var production = environments.production;
/** load config file based on enviroment */
var configFile = production() ? "./src/env/prod.js" : "./src/env/dev.js";
var httpProxy = require('http-proxy');

gulp.task('lint', function() {
  gulp.src('./src/app/**/*.js')
    .pipe(jshint())
    .pipe(jshint.reporter('default'));
});

gulp.task('scripts', function(){
    gulp.src([
                './src/assets/**/*.js',
                configFile
            ])
            .pipe(uglify())
            .pipe(concat('vendor.min.js'))
            .pipe(gulp.dest('./public/'));
});

gulp.task('browserify', function() {
    // Grabs the app.js file
    browserify([
            './src/app/app.js'
        ])
        // bundles it and creates a file called main.js
        .bundle()
        .pipe(source('main.js'))
        .pipe(gulp.dest('./public/'));
});

gulp.task('copy', ['browserify'], function() {
    gulp.src(['./src/**/*.html'])
        .pipe(gulp.dest('./public'))
        .pipe(browserSync.stream())
});

gulp.task('css', function() {
    gulp.src(
        [
            './src/assets/**/*.css',
            'node_modules/angular-material/**/*.css',
            'node_modules/ag-grid/dist/styles/*.css'
        ])
        .pipe(concat('style.css'))
        .pipe(gulp.dest('./public/'));
});

gulp.task('build',['lint', 'copy', 'scripts', 'css']);

var localServerUrl = 'http://localhost:8080/';

var proxy = httpProxy.createProxyServer({
    target: localServerUrl
});

var startsWith = function(value, str) {
    return value.substring( 0, str.length ) === str;
}

var endsWith = function(value, str) {
    return value.substring( value.length - str.length, value.length ) === str;
}

var proxyMiddleware = function(req, res, next) {
    if(req.url == '/' || startsWith(req.url, '/app/')) {
        console.log("no proxy for " + req.url);
        next();
    }
    else if(req.url == '/style.css' || req.url == '/vendor.min.js' || req.url == '/main.js') {
        console.log("no proxy for " + req.url);
        next();
    }
    else {
        console.log("proxy for " + req.url);
        proxy.web(req, res);
    }
};

gulp.task('browser-sync', ['build'], function() {
    browserSync.init({
        server: {
            baseDir: "./public",
            middleware: proxyMiddleware
        },
        browser:"firefox"
    });
});

gulp.task('default', ['browser-sync'], function(){
    gulp.watch("./src/**/*.*", ["build"]);
    gulp.watch("./public/**/*.*").on('change', browserSync.reload);
})



